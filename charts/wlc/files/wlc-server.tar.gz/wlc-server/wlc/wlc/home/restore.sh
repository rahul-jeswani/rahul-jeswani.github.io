#!/bin/sh

BACKUP_PART=$1
BACKUPFILE=$2
BACKUP_RPT_FILE=""

usage() {
	echo "Usage: $0 {db|files} <backupfile-name>"
	exit 0
};

set -a
. wlc_backup.int.env


RSTRDIR=/tmp/$$.rstr

if [ "${BACKUPFILE}" = "" ]
then
	echo "No backupfile specified".
	usage
	exit 0
fi

if [ ! -f "${BACKUPFILE}" ]
then
	echo "${BACKUPFILE} does not exist. "
	usage
	exit 0
fi


trap "rm -rf ${RSTRDIR}" 0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15
mkdir ${RSTRDIR}
if [ $? -ne 0 ]
then
	echo "Unable to create intermediate artefacts for restore"
	exit 0
fi

## Check if the file is a tar file.

tar tvf ${BACKUPFILE} > ${RSTRDIR}/a.lst 2> ${RSTRDIR}/a.err
if [ $? -ne 0 ]
then
	echo "Error extracting artefacts from backup file ${BACKUPFILE}"
	exit 0
fi

if [ "${BACKUP_PART}" = "db" ]
then
	backupfiles="db.data"
else
	backupfiles="ooe.tar od.tar ${BACKUP_RPT_FILE}"

	if [ ! -d /opt/opennms/etc -o ! -d /opennms-data -o [ "${BACKUP_RPT_FILE}" ! = "" -a ! -d /home/wlcapp/reports ] ]
	then
		echo "Some of the restore destinations are not available"
		exit 0
	fi
fi

## Check contents of tar file
cat ${BACKUPFILE} | tar tf - ${backupfiles} > /dev/null 2>&1
if [ $? -ne 0 ]
then
	echo "Error locating artefacts from backup file ${BACKUPFILE}"
	exit 0
fi

cat ${BACKUPFILE} | (cd ${RSTRDIR}; tar xf -)
cd ${RSTRDIR}

for a in ${backupfiles}
do
	if [  ! -f $a ]
	then
		echo "Some artefacts are missing in the backup file"
		exit 0
	fi
	md5sum -c $a.md5 > /dev/null 2>&1
	if [ $? -ne 0 ]
	then
		echo "One or more artefacts in the backup file is corrupted"
		exit 0
	fi
done


## TODO Should we ensure there is nothing else in the backup?

if [ "${BACKUP_PART}" = "db" ]
then
	export PGPASSWORD=${BACKUP_DBADMINPASS}
	psql -h ${BACKUP_DBHOST} -p ${BACKUP_DBPORT} -U ${BACKUP_DBADMINUSER} -f ${BACKUPDIR}/db.data
else

	echo 'cat ${RSTRDIR}/ooe.tar | (cd /; tar xf - )'
	echo 'cat ${RSTRDIR}/od.tar | (cd /; tar xf - )'
	if [ "${BACKUP_RPT_FILE}" ! = "" ]
	then
		echo 'cat ${RSTRDIR}/${BACKUP_RPT_FILE} | (cd /; tar xf - )'
	fi
fi



echo "Restore done from ${BACKUPFILE}"
