#!/bin/bash

# This script is used to return the tags to be used for an AP with OpenWISP and the WLC to which the AP must connect.
# The AP_LOCATION_MAP_FILE, a csv file, which is available at AP_LOCATION_MAP_PATH is used to get the AP location details to construct the tags
# The environment variables AP_LOCATION_MAP_PATH and AP_LOCATION_MAP_FILE must be set to point to the csv file
# The MAC address of the AP is taken as an input
# The script outputs two lines to stdout - the first line contains tags, the second line has the WLC id.
# If no matching AP is found in the csv file, the script exits with -1 as the return code
# If no csv file is found, the script exits with -2 as the return code
# 

function getmac {
	echo $1 | sed -e 's/[:\-]//g' -e 's/\(.*\)/\L\1/'
}

if [ "$1" == "" ]
then
	echo "Usage : $0 <AP-MAC-Address>" 1>&2;
	exit -1 
fi

INPUT_FILE=${AP_LOCATION_MAP_PATH}/${AP_LOCATION_MAP_FILE}

if [ ! -f "$INPUT_FILE" ]
then
	echo "Could not access $INPUT_FILE" 1>&2;
	exit -2 
fi

inputmac=$1
#02:42:AC:13:00:17,UHN30013120ISC003,R1A1312000377-F01-ISC003,F01,R1A1313000377,Site1,WLC1
apmac=`getmac $inputmac`

IFS=','

while read AP_MAC_ID AP_Hostname AP_Friendlyname AP_Floor AP_Building AP_Site AP_WLCID
do
     
    mac=`getmac $AP_MAC_ID`
#echo $mac
    if [ "$apmac" == "$mac" ]
    then
#       echo "$AP_Site $AP_Site.$AP_Building $AP_Site.$AP_Building.$AP_Floor $AP_Hostname"
       echo "$AP_Building $AP_Building.$AP_Floor $AP_Hostname"
       echo "$AP_WLCID"
       exit 0
    fi
done < <(tail -n +2 $INPUT_FILE)

echo "Could not find AP ($inputmac) details in $INPUT_FILE" 1>&2;
exit -1
