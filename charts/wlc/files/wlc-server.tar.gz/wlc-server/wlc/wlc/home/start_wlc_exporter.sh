#!/usr/bin/bash

trap "exit;" 0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15

function logmessage {
   echo "`date +'%Y-%m-%dT%H:%M:%S%Z%z'` $1 [WLC: `basename $0`] $2"
}


while [ true ]
do
    curl -s -o /dev/null http://localhost/basic_status
    if [ $? -eq 0 ]
    then
        logmessage "info" "(re)Starting WLC exporter"
        /home/wlc/nginx-prometheus-exporter
        logmessage "error" "WLC exporter exited"
    else
        logmessage "info" "Waiting for WLC App to start .."
    fi    
    sleep 30
done

 
