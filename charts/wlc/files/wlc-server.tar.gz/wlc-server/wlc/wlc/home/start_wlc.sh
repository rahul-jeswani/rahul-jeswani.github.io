#!/bin/bash

set -a
. /home/wlc/wlcobs.int.env
. /home/wlc/wlc.int.env

bash /home/wlc/start_wlc_exporter.sh &

[ -f /home/wlc/prestart_wlc.sh ] && bash /home/wlc/prestart_wlc.sh

[ -f /home/wlc/get_tags.sh ] && cp /home/wlc/get_tags.sh /usr/local/sbin
[ -f /home/wlc/pnpd_server ] && /home/wlc/pnpd_server -p 11111


for tgtfile in stream.conf proxy.conf
do
sed \
	-e 's/OPENNMS_IP/'$OPENNMS_IP'/' \
	-e 's/OPENWISP_IP/'$OPENWISP_IP'/' \
	-e 's/WLCAPP_IP/'$WLCAPP_IP'/' \
	-e 's/GRAFANA_IP/'$GRAFANA_IP'/' \
	-e 's/WLC_IP/'$WLC_IP'/' \
	-e 's/LOGSTASH_IP/'$LOGSTASH_IP'/' \
	-e 's/COLLECTD_IP/'$COLLECTD_IP'/' \
	< /home/wlc/$tgtfile.tmpl > /home/wlc/$tgtfile 
done

/usr/sbin/nginx -c /home/wlc/nginx.conf -g "daemon off;"

