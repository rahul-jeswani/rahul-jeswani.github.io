#!/usr/bin/bash

[ -d /home/wlc/conf ] && cp -r /home/wlc/conf/* /etc/nginx

exit 0
