#!/bin/sh

BACKUP_PART=$1
BACKUPFILE=$2
BACKUP_RPT_FILE=""
BACKUPDIR=/tmp/$$.bkup

usage() {
	echo "Usage: $0 {db|files} <backupfile-name>"
	exit 0
};
set -a
. wlc_backup.int.env

if [ "${BACKUP_PART}" != "db" -o "${BACKUP_PART}" != "files" ]
then
	echo "Invalid parameter"
	usage
	exit 0
fi

if [ "${BACKUPFILE}" = "" ]
then
	echo "No backupfile specified".
	usage
	exit 0
fi

if [ -f "${BACKUPFILE}" ]
then
	echo "A ${BACKUPFILE} exists already. Please provide another file name"
	usage
	exit 0
fi
mkdir ${BACKUPDIR}
if [ $? -ne 0 ]
then
	echo "Unable to create intermediate artefacts for backup"
	exit 0
fi

trap "rm -rf ${BACKUPDIR}" 0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15

touch ${BACKUPFILE}
if [ $? -ne 0 ]
then
	echo "Unable to create ${BACKUPFILE}. No backup done."
	
	exit 0
fi

if [ "${BACKUP_PART}" = "db"]
then
	backupfiles="db.data"

	export PGPASSWORD=${BACKUP_DBADMINPASS}
	pg_dumpall -h ${BACKUP_DBHOST} -p ${BACKUP_DBPORT} -U ${BACKUP_DBADMINUSER} > ${BACKUPDIR}/db.data;

else
	backupfiles="ooe.tar od.tar"

	(cd /; \
		tar cf ${BACKUPDIR}/ooe.tar opt/opennms/etc; \
		tar cf ${BACKUPDIR}/od.tar opennms-data;  \
	)
	if [ "${BACKUP_RPT_FILE}" != "" ]
	then
		(cd /; \
       			tar cf ${BACKUPDIR}/${BACKUP_RPT_FILE} wlcapp/reports; \
		)
	fi
fi

for a in ${backupfiles}
do
	(cd ${BACKUPDIR}; md5sum $a > $a.md5  2>/dev/null)
done

(cd ${BACKUPDIR}; tar cf backup ${backupfiles} *.md5 )
mv ${BACKUPDIR}/backup ${BACKUPFILE}
echo "Backup done to file ${BACKUPFILE}"
