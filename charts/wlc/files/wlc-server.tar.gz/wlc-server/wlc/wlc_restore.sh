#!/bin/bash

# Script to restore WLC and NE data from a backup

BACKUPFILE=$1

if [ "${BACKUPFILE}" = "" ]
then
	echo "No backupfile specified".
	exit 0
fi

if [ ! -f "${BACKUPFILE}" ]
then
	echo "${BACKUPFILE} does not exist. "
	exit 0
fi


WLC_COMPONENTS="opennms openwisp grafana wlcapp"

echo "Stopping WLC components before restore"

docker stop ${WLC_COMPONENTS} 

docker exec wlc sh /home/wlc/restore.sh ${BACKUPFILE}

docker start ${WLC_COMPONENTS}
