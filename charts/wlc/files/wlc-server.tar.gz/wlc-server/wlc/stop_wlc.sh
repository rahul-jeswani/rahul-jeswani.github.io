docker-compose -f wlcprom-compose.yml down
docker-compose -f wlc-compose.yml down
docker-compose -f stolon-compose.yml down
