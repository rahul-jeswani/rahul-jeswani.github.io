#!/bin/sh

mkdir -p /home/wlcprom
cp -r /home/wlcprom.h/* /home/wlcprom
chown -R nobody:nogroup /home/wlcprom/*
chmod -R go-w /home/wlcprom/*
chmod -R -x /home/wlcprom/*.*

/bin/sh /home/wlcprom/start_wlcprom.sh

