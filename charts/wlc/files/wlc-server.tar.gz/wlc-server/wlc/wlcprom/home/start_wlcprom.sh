#!/bin/sh


tgtfile=wlcprom.yml
sed \
	-e 's/WLC_IP/'$WLC_IP'/' \
	-e 's/WLCAM_IP/'$WLCAM_IP'/' \
	-e 's/WLCAPP_IP/'$WLCAPP_IP'/' \
	-e 's/DATABASE_IP/'$DATABASE_IP'/' \
	-e 's/OPENNMS_IP/'$OPENNMS_IP'/' \
	-e 's/OPENWISP_IP/'$OPENWISP_IP'/' \
	-e 's/LOGSTASH_IP/'$LOGSTASH_IP'/' \
	-e 's/COLLECTD_IP/'$COLLECTD_IP'/' \
	-e 's/RD_IP/'$RD_IP'/' \
	< /home/wlcprom/$tgtfile.tmpl > /home/wlcprom/$tgtfile


/bin/prometheus --config.file=/home/wlcprom/wlcprom.yml --storage.tsdb.path=/prometheus/prom --web.console.libraries=/usr/share/prometheus/console_libraries --web.console.templates=/usr/share/prometheus/consoles
