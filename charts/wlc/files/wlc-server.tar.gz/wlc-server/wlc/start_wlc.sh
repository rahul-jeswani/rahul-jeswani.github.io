
export COMPOSE_HTTP_TIMEOUT=200
docker-compose -f stolon-compose.yml up -d
docker-compose -f wlc-compose.yml up -d
docker-compose -f wlcprom-compose.yml up -d

