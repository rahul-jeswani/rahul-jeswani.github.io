#!/usr/bin/bash

cat /proc/net/tcp6 /proc/net/tcp | egrep '(0)+:(2328 )(0)+:(0000) (0A)' > /dev/null
