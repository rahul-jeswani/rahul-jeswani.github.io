
docker volume rm wlc_opennms.data  wlc_opennms.etc wlc_psql.data wlc_etcd.data

