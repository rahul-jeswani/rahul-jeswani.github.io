#!/usr/bin/bash

function logmessage {
   echo "`date +'%Y-%m-%dT%H:%M:%S%Z%z'` $1 [WLC Report Server App: `basename $0`] $2"
}

cd /home/wlcapp
[ -f /home/wlcapp/reportServer.js ] && cp /home/wlcapp/reportServer.js /opt/app-root/src/reportServer.js
cd /opt/app-root/src

while [ true ]
do
        logmessage "info" "(re)Starting Report Server"

        node reportServer.js

        logmessage "error" "Report Server exited"
    sleep 30
done

 
