#!/bin/bash

cp -r /home/wlcapp.h/* /home/wlcapp
chown -R wlcapp:wlcapp /home/wlcapp/*
chmod -R go-w /home/wlcapp/*
chmod -R -x /home/wlcapp/*.*



/opt/jetty/bin/jetty.sh start 
sleep 10

rm -rf /opt/app-root/src/reports/templates/*.jrxml
cp -r /home/wlcapp/reports/* /opt/app-root/src/reports
mkdir -p /opt/app-root/src/reports/generated

chown -R wlcapp:wlcapp /opt/app-root/src/reports

bash /home/wlcapp/wlc_restore.sh
bash /home/wlcapp/create_wlcappdbs.sh
bash /home/wlcapp/wlcbackup_restore.sh period &
su wlcapp -p /home/wlcapp/start_wlcapp.sh
