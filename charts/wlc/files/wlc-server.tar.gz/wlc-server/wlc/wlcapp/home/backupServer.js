const express = require('express');
const cors = require('cors');
const app = express();
const winston = require('winston');
var parserJson = require('xml2js');
const backupDir = '/home/dbbackup';
require('winston-syslog').Syslog;
const { exec } = require('child_process');

sslogformat = winston.format.printf(({ level, message, label, timestamp }) => {
  return `${timestamp} ${level} [${label}] ${message}`;
});

var logger = winston.createLogger({
  format: winston.format.combine(
    winston.format.label({ label: 'WLC Backup Server' }),
    winston.format.timestamp(),
    sslogformat
  ),
  levels: winston.config.syslog.levels,
  transports: [
    new winston.transports.Console(),
  ]
});

app.listen(process.env.WLCBACKUPAPPPORT, () => {
  logger.info('Backup Server started!...') ;
})

app.use(cors(corsOptions));
app.set('json spaces', 40);

app.use(express.static('/opt/app-root/html/'));
var fs = require('fs');
var errCode = null;
var errMsg = "";
var debug = true;
var enhancedlog = false;

if (debug) { logger['level'] = 'debug'; };
if (debug) { enhancedlog = true; };

const prom_client = require('prom-client');
const collectDefaultMetrics = prom_client.collectDefaultMetrics;
collectDefaultMetrics({ timeout: 5000 });


const register = require('prom-client/lib/registry').globalRegistry;

app.get(process.env.WLCAPPMETRICSURI, (req, res) => {
	res.set('Content-Type', register.contentType);
	res.end(register.metrics());
});

var conn = null;
var connId = null;
var connObjectLatest = null;
var corsOptions = {
  origin: '*',
  optionsSuccessStatus: 200 // some legacy browsers (IE11, various SmartTVs) choke on 204 
}

const url = require('url');
const bodyParser = require('body-parser')
app.use(bodyParser.json())

function catch_all_handler(err, req, res, next) {
  res.status(500);
  logger.error("catchall exception :" + err);    
}
app.use(catch_all_handler)

app.route('/wlcapp/api/backup/initiate', cors(corsOptions)).post((req, res) => {
if (debug) logger.info('Backup Initiated');
exec('bash /home/wlcapp/wlcbackup_restore.sh Adhoc',
	(error, stdout, stderr) => {            
		if (error !== null) {
			if (debug) logger.error(error);
			res.status(320).json({ error: `${error}` });
		}else{
			if (debug) logger.info('Backup Started');
			res.status(200).json({ bkpStatus: "Started" });
		}
	});
})

app.route('/wlcapp/api/backup/restore', cors(corsOptions)).post((req, res) => {
if (debug) logger.info('Restore Validation Initiated');
	exec("bash /home/wlcapp/wlcbackup_restore.sh valrestore "+req.body.backupDetails,
	(error, stdout, stderr) => {
		if (error !== null) {
			if (debug) logger.error(error);
			res.status(320).json({ error: `${error}` });
		}else{
			if (debug) logger.info('Restore Validated');
			res.status(200).json({ bkpStatus: stdout });
		}
	});
})

app.route('/wlcapp/api/backup/status', cors(corsOptions)).post((req, res) => {
    template = [];
	fs.readdir(backupDir , (errReadDir, files) => {
		if(files){
				if (debug) logger.info(files);
				var ExecUpdateAsync = new Promise((resolve, reject) => {
				  files.forEach(function (readCompletedFolder) {
						var dirPath = backupDir+'/'+readCompletedFolder;
						if(fs.existsSync(dirPath) && fs.lstatSync(dirPath).isDirectory()){                       
							readCompletedFile = readCompletedFolder.split('-')[1]; 
							createDate = readCompletedFile.split("_")[0][0]+''+readCompletedFile.split("_")[0][1]+''+readCompletedFile.split("_")[0][2]+''+readCompletedFile.split("_")[0][3]+'-'+readCompletedFile.split("_")[0][4]+''+readCompletedFile.split("_")[0][5]+'-'+readCompletedFile.split("_")[0][6]+''+readCompletedFile.split("_")[0][7]+' '+readCompletedFile.split("_")[1][0]+''+readCompletedFile.split("_")[1][1]+':'+readCompletedFile.split("_")[1][2]+''+readCompletedFile.split("_")[1][3]+':'+readCompletedFile.split("_")[1][4]+''+readCompletedFile.split("_")[1][5]; 				
							var bkpType = readCompletedFolder.split('-')[0];
							let detail = {
								'name': readCompletedFolder,
								'timeValue': readCompletedFolder.split('-')[1],
								'timestamp': createDate,
								'type': bkpType
								}
							template.push(detail);
							resolve();
						}
				  });
				});
				ExecUpdateAsync.then(() => {
					if(typeof template !== 'undefined' && template.length>0){
						template.sort((a,b)=>(a.timeValue) < (b.timeValue) ? 1 : -1);
						let folderName = template[0].name;
						let fileName = template[0].timeValue;
						if(fs.existsSync(backupDir+'/'+folderName+'/'+folderName+'.status')){
							filePath = backupDir+'/'+folderName+'/'+folderName+'.status';
						}else if(!fs.existsSync(backupDir+'/'+folderName+'/'+folderName+'.status')){
							res.status(200).json({ file: 'Not exist' });
						}else{
							filePath = backupDir+'/'+folderName+'/'+folderName+'.status';
						}
						fs.readFile( filePath,{encoding: 'utf-8'}, function(errReadTemplate, data) {
							if(errReadTemplate){
								res.status(320).json({ error: errReadTemplate });									
							}else{
								res.status(200).json({ bkpStatus: data });										
							}
						})                                        
						}else if(typeof template !== 'undefined' && template.length==0){
								res.status(200).json({ bkpStatus: "None" });
						}else{
								res.status(320).json({ error: "Failed to fetch details from DB" });
						}
				});
		}else{
			if (debug) logger.error(errReadDir);
			res.status(320).json({ error: errReadDir });
		}

	});
})

app.route('/wlcapp/api/backup/list', cors(corsOptions)).post((req, res) => {	
	template = [];	
 	let filesCount = getDirectories(backupDir).length;
	var getRestoreDetailSync = new Promise((resolve, reject) => {
		fs.readFile( backupDir+'/Validate-Restore.status',{encoding: 'utf-8'}, function(errReadValidation, dataValidation) {
			if(errReadValidation){
				if (debug) logger.error(errReadValidation);
				let restore = {
						'status': 'ENOENT'
					}
				resolve(restore);
			}else{
			let backupCount = 0;
			for(let i=0;i<getDirectories(backupDir).length;i++){
				element = getDirectories(backupDir)[i];
				++backupCount;
				if(dataValidation.includes(element)){
					var readRestoreValidSync = new Promise((readRestoreValidSyncResolve, reject) => {
						fs.readFile( backupDir+'/'+element+'/Restore-'+element+'.status',{encoding: 'utf-8'}, function(errReadRestoreStatus, dataRestoreStatus) {
							let restore = {
								'folder': element,					
							}
							if(dataValidation.includes('Validation failed')){
								restore.status = 'Failed';
								restore.msg = 'Validation Failed';
							}else if(dataValidation.includes('Ready to Restore')){
								restore.status = 'Success';
								restore.msg = 'Ready to Restore';
							}
							if(errReadRestoreStatus){
								if (debug) logger.error('The Restore Status File is not found : ',errReadRestoreStatus);
								readRestoreValidSyncResolve(restore);
							}else{
								if(dataRestoreStatus.includes('Database Restore Completed') && dataRestoreStatus.includes('Volumes Restore Completed')){
									restore.status = 'Success';
									restore.msg = 'Database & Volumes Restore Completed';
								}else if(dataRestoreStatus.includes('Database Restore Failed') && dataRestoreStatus.includes('Volumes Restore Failed')){
									restore.status = 'Failed';
									restore.msg = 'Database & Volumes Restore Failed';
								}else if(dataRestoreStatus.includes('Database Restore Failed') && dataRestoreStatus.includes('Volumes Restore Completed')){
									restore.status = 'Partial';
									restore.msg = 'Volumes Restore Completed & Database Restore Failed';
								}else if(dataRestoreStatus.includes('Database Restore Failed') && dataRestoreStatus.includes('Volumes Restore Completed')){
									restore.status = 'Partial';
									restore.msg = 'Volumes Restore Completed & Database Restore Failed';
								}
								readRestoreValidSyncResolve(restore);
							}
						})
					})
					readRestoreValidSync.then((restoreValidSyncResponse) => {
						resolve(restoreValidSyncResponse);						
					})
					break;
				}else{
					if(backupCount >= getDirectories(backupDir).length){
						let restore = {
							'status': 'ENOENT'
						}
						resolve(restore);
					}
				}
			}
		}
		})
	})
	getRestoreDetailSync.then((restoreSyncResponse) => {
		let restoreInitBkp = null;
		if(restoreSyncResponse.status != 'ENOENT'){      
			restoreInitBkp = restoreSyncResponse.folder;
		}
		fs.readdir(backupDir , (errReadDir, files) => {	
			if(files){	
				if (debug) logger.info(files);
				let readCompleted = 0;
				var readFilesSync = new Promise((resolve, reject) => {	
				  files.forEach(function (readCompletedFolder) {
					var dirPath = backupDir+'/'+readCompletedFolder;				
					if(fs.existsSync(dirPath) && fs.lstatSync(dirPath).isDirectory()){						
						fs.readFile( backupDir+'/'+readCompletedFolder+'/'+readCompletedFolder+'.status',{encoding: 'utf-8'}, function(errReadStatus, data) {
							readCompleted++;
							readCompletedFile = readCompletedFolder.split('-')[1];
							createDate = readCompletedFile.split("_")[0][0]+''+readCompletedFile.split("_")[0][1]+''+readCompletedFile.split("_")[0][2]+''+readCompletedFile.split("_")[0][3]+'-'+readCompletedFile.split("_")[0][4]+''+readCompletedFile.split("_")[0][5]+'-'+readCompletedFile.split("_")[0][6]+''+readCompletedFile.split("_")[0][7]+' '+readCompletedFile.split("_")[1][0]+''+readCompletedFile.split("_")[1][1]+':'+readCompletedFile.split("_")[1][2]+''+readCompletedFile.split("_")[1][3]+':'+readCompletedFile.split("_")[1][4]+''+readCompletedFile.split("_")[1][5];
							var bkpType = readCompletedFolder.split('-')[0];
							let detail = {
									'name': readCompletedFile,
									'timestamp': createDate,
									'type': bkpType
									}
							if(errReadStatus){
								if (debug) logger.error('Error ', errReadStatus,' in Backup ',readCompletedFolder);
							}else{
								if(data.includes('Volumes Backup Completed for '+readCompletedFolder)){
									detail.volumeBkp  = "Completed";
								}else{
									detail.volumeBkp = "Failed";
								}
								if(data.includes('Database Backup Completed for '+readCompletedFolder)){
										detail.dbBkp  = "Completed";
								}else{
										detail.dbBkp = "Failed";
								}
							}
							if(restoreInitBkp != null && restoreInitBkp == readCompletedFolder){
								detail.resStatus = restoreSyncResponse.status;
								detail.resMsg = restoreSyncResponse.msg;
							}
							template.push(detail);					
							if(readCompleted >= filesCount){
								resolve();
							}
						})
					}
				  });	
				});	
				readFilesSync.then(() => {	
				  template.sort((a,b)=>(a.name) < (b.name) ? 1 : -1);
				  if(typeof template !== 'undefined' && template.length>0){	
						sendBackResult = {};	
						sendBackResult['templates'] = template;	
						res.status(200).json({ reportList: sendBackResult });	
					}else if(typeof template !== 'undefined' && template.length==0){	
						res.status(200).json({ reportList: "None" });	
					}else{	
						res.status(320).json({ error: "Failed to fetch details" });	
					}	
				});		
			}else{	
				if (debug) logger.error(errReadDir);	
				res.status(320).json({ error: errReadDir });	
			}	
			
		});
	})	
})

function getDirectories(path){ 
  return fs.readdirSync(path).filter(function (file) {
    return fs.statSync(path+'/'+file).isDirectory();
  });
}
