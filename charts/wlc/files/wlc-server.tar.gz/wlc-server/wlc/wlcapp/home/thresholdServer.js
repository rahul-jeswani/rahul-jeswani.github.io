const express = require('express');
const cors = require('cors');
const app = express();
const winston = require('winston');
const reportsDir = '/opt/app-root/src/reports';
require('winston-syslog').Syslog;

sslogformat = winston.format.printf(({ level, message, label, timestamp }) => {
  return `${timestamp} ${level} [${label}] ${message}`;
});

syslogTransportOption = {
	host : process.env.OPENNMS_IP,
	port : process.env.OPENNMS_SYSLOG_PORT,
	protocol : 'udp'
}

var logger = winston.createLogger({
  format: winston.format.combine(
    winston.format.label({ label: 'WLC Threshold Server' }),
    winston.format.timestamp(),
    sslogformat
  ),
  levels: winston.config.syslog.levels,
  transports: [
    new winston.transports.Console(),
  ]
});

  var loggerToOpenNMS = winston.createLogger({
	  format: winston.format.combine(
		winston.format.label({ label: 'WLC Threshold Server AP Classification' }),
		winston.format.timestamp(),
		sslogformat
	  ),
	  levels: winston.config.syslog.levels,
	  transports: [new winston.transports.Syslog(syslogTransportOption)]
  });

app.listen(process.env.WLCTHRESHOLDAPPPORT, () => {
  logger.info('Server started!...') ;
})

app.use(cors(corsOptions));
app.set('json spaces', 40);

app.use(express.static('/opt/app-root/html/'));
var JDBC = require('jdbc');
var jinst = require('jdbc/lib/jinst');
var asyncjs = require('async');
var util = require('util');
var Poolap = require('jdbc/lib/pool');
var redis = require('redis');
var client = redis.createClient(process.env.REDISPORT,process.env.REDISSERVER);
const csv = require('fast-csv');
var fs = require('fs');
var errCode = null;
var errMsg = "";
var redisConnection = false;
var phoenixConnection = false;
var debug = true;
var enhancedlog = false;
const RedisSentinel = require("ioredis");
var redisSentinel = new RedisSentinel({
  sentinels: [{ host: process.env.REDISSERVER, port: process.env.REDISPORT_PRIMARY }, 
			  { host: process.env.REDISSERVER_SECONDARY, port: process.env.REDISPORT_SECONDARY }, 
			  { host: process.env.REDISSERVER_TERTIARY, port: process.env.REDISPORT_TERTIARY }],
  name: 'mymaster'
});

if (debug) { logger['level'] = 'debug'; };
if (debug) { enhancedlog = true; };

const prom_client = require('prom-client');
const collectDefaultMetrics = prom_client.collectDefaultMetrics;
collectDefaultMetrics({ timeout: 5000 });


const register = require('prom-client/lib/registry').globalRegistry;

app.get(process.env.WLCAPPMETRICSURI, (req, res) => {
	res.set('Content-Type', register.contentType);
	res.end(register.metrics());
});



const parser = csv.parse();
client.on('connect', function() {
  try {
    if(debug) logger.info('Redis client connected');
    redisConnection = true;
    if(!phoenixConnection){
        establishConnection();
    }    
  }
  catch(err) {
    logger.error("catchall exception :" + err);    
  }
});

client.on('error', function (err) {
  try {
    logger.error('Something went wrong ' + err);
    errCode = 310;
    errMsg = "Redis doesn't connect";
    redisConnection = false;
    connId = null;
    if(phoenixConnection){
        phoenixConnection = false;
    }
  }
  catch(err) {
    logger.error("catchall exception :" + err);    
  }
});
if (!jinst.isJvmCreated()) {
  jinst.addOption('-Xrs')
  jinst.setupClasspath([  
    '/opt/app-root/src/appheonixplugin/hadoopjars/*',
    '/opt/app-root/src/appheonixplugin/hbasejars/*',    
    '/opt/app-root/src/appheonixplugin/',
    '/opt/app-root/src/appheonixplugin/phoenix-4.7.0.2.6.5.0-292-client.jar',
        '/opt/app-root/src/pglibs/postgresql-42.2.8.jar',
        '/opt/app-root/src/jasperlibs/jasperreports-5.6.0.jar',
        '/opt/app-root/src/jasperlibs/commons-beanutils-1.9.4.jar',
        '/opt/app-root/src/jasperlibs/jackson-databind-2.10.1.jar',
        '/opt/app-root/src/jasperlibs/jackson-core-2.10.1.jar',
        '/opt/app-root/src/jasperlibs/commons-collections4-4.0.jar',
        '/opt/app-root/src/jasperlibs/commons-collections-3.2.1.jar',
        '/opt/app-root/src/jasperlibs/commons-digester-2.1.jar',
        '/opt/app-root/src/jasperlibs/itext-2.1.7.jar'   
          ])
}

//        '/opt/app-root/src/jasperlibs/groovy-all-2.2.1.jar',

var config = {
  drivername: 'org.apache.phoenix.jdbc.PhoenixDriver',
  url: 'jdbc:phoenix:' + process.env.PHOENIXSERVERS + ':/hbase-unsecure',
  user: '',
  password: '',
  minpoolsize:2,
  maxpoolsize: 100,
  maxidle:30000
 
}

var hsqldb = new JDBC(config);
try {
    hsqldb.initialize(function(err) {    
          if (err) {
            logger.error(err);
            errCode = 300;
            errMsg = "DB doesn't connect";
          } else {
          if (debug) logger.info("Initialized");      
        }
    });
}
catch(err) {
  logger.error("catchall exception :" + err);    
}

var conn = null;
var connId = null;
var connObjectLatest = null;
var corsOptions = {
  origin: '*',
  optionsSuccessStatus: 200 // some legacy browsers (IE11, various SmartTVs) choke on 204 
}

async function connect() {
    if (debug) logger.info("connect...");
    return new Promise((resolve, reject) => {
        const poolPromise = reserveDBConnection();
        poolPromise
            .then(pool => {
                if (debug) logger.info("connected");
                phoenixConnection = true;                
                resolve(pool);
            })
            .catch(err => {
                reject(err);
            });
    });
}

async function establishConnection() {
     if (debug) logger.info("establishConnection...");
     var a = connect();
     a.then(a => { if (debug) logger.info("success") } )
    .catch(err => {
        logger.error("Retrying",a);
		setTimeout(establishConnection, 5000);
	});
};

async function reserveDBConnection(){
	hsqldb.reserve(function(err, connObj) {
	  if (connObj) {
		connObjectLatest = connObj;
		conn = connObj.conn;
		connId = connObj.uuid;
	 
		asyncjs.series([
		  function(callback) {
			conn.setAutoCommit(false, function(err) {
			  if (err) {
				errCode = 301;
				errMsg = "DB doesn't commit";
				if (debug) logger.info("not committed");
			  } else {
				if (debug) logger.info("committed");
				callback(null);
			  }
			});
		  },
		  function(callback) {
			conn.setSchema("analytics", function(err) {
			  if (err) {
				callback(err);
				errCode = 302;
				errMsg = "Schema doesn't set";
			  } else {
				if (debug) logger.info("schema set");
				callback(null);
			  }
			});
		  }
		], function(err, results) {
		});		 
	  }else if(err){
		logger.error(err.message);  
	  }  
	});
}

async function releaseConnection(connObjectNew) {
    if(!(connObjectNew == null)){
      hsqldb.release(connObjectNew, function(err) {
        if (err) {
          logger.error(err.message);
        }
      });
    }
	connId = null;
	connObjectLatest = null;
}
const url = require('url');
const myURL = url.parse(config.url);


const bodyParser = require('body-parser')
app.use(bodyParser.json())

function catch_all_handler(err, req, res, next) {
  res.status(500);
  logger.error("catchall exception :" + err);    
}
app.use(catch_all_handler)

var users = [];
var Request = require("request");

app.route('/wlcapp/api/threshold/list', cors(corsOptions)).post((req, res) => {
    if (enhancedlog) logger.debug(JSON.stringify(req.headers));    
    if (!connId) { 
       establishConnection(); 
    }
		
    if(connId){
        conn.createStatement(function(errCreateStatement, statement) {
          if (errCreateStatement) {
            res.status(errCode).json({ error: errMsg });
          } else {
            statement.setFetchSize(100, function(errFetchingSize) {
              if (errFetchingSize) {
                res.status(303).json({ error: errFetchingSize });
              } else {                
				let condition = "";
				if(!process.env.WLC_ID){
					res.status(200).json({ thresholdList: "None" });
				}else{
				condition = "where wlc_id = '"+process.env.WLC_ID+"'";
				statement.executeQuery("select * from ap_threshold "+condition,
                   function(errExecQuery, thresholdResult) {
                    if (errExecQuery) {
                    res.status(303).json({ error: "Failed to fetch details from DB" });
                  } else {
                    thresholdResult.toObjArray(function(errToArray, results) {
						if(!errToArray){
							if(results.length >= 1){
								res.status(200).json({ thresholdList: results });
							}else{
								conditionDefault = "where wlc_id = 'DEFAULT'";
								statement.executeQuery("select * from ap_threshold "+conditionDefault,
								   function(errExecQueryDef, thresholdResultDef) {
									if (errExecQueryDef) {
									res.status(303).json({ error: "Failed to fetch details from DB" });
								  } else {
									thresholdResultDef.toObjArray(function(errToArrayDef, resultsDef) {
										if(!errToArrayDef){
											resultsDef[0]['WLC_ID'] = process.env.WLC_ID;
											res.status(200).json({ thresholdList: resultsDef });
										}else{
											res.status(303).json({ error: "Failed to fetch details from DB" });
										}
										
									});
								  }
								});
							}
						}else{
							res.status(303).json({ error: "Failed to fetch details from DB" });
						}
						
					});
                  }
                });
				}
              }
            });
          }
        });
      releaseConnection(connObjectLatest);
    }else{
        errCode = 401;
        errMsg = "Server is not connected.";
        res.status(errCode).json({ error: errMsg });
    }
})

app.route('/wlcapp/api/threshold/updateThreshold', cors(corsOptions)).post((req, res) => {
    if (enhancedlog) logger.debug(JSON.stringify(req.headers));    
    if (!connId) { 
       establishConnection(); 
    }		
    if(connId){        
      conn.setAutoCommit(true, function(errCommit) {
          if (errCommit) {
            errCode = 301;
            errMsg = "DB doesn't commit";
            res.status(errCode).json({ error: errMsg });
          } else {
            if (debug) logger.info("committed");            
            conn.createStatement(function(errCreateStatement, statement) {
              if (errCreateStatement) {
                res.status(errCode).json({ error: errMsg });
              } else {
                let thresholdDetails = req.body.thresholdDetails;
				let queryToPutData;
				queryToPutData = "UPSERT INTO ap_threshold (WLC_ID,EXCESSIVE_ASSOCIATION,HIGH_AP_UTILIZATION,LOW_DATA_RATE,BANDWIDTH_WASTAGE,COMMUNICATION_ERRORS,HIGH_RETRY,lOW_RSSI_CLIENT,LOW_DATA_RATE_CLIENT,FIRMWARE_VERSION) VALUES ('"+thresholdDetails.WLC_ID+"','"+thresholdDetails.EXCESSIVE_ASSOCIATION+"','"+thresholdDetails.HIGH_AP_UTILIZATION+"','"+thresholdDetails.LOW_DATA_RATE+"','"+thresholdDetails.BANDWIDTH_WASTAGE+"','"+thresholdDetails.COMMUNICATION_ERRORS+"','"+thresholdDetails.HIGH_RETRY+"','"+thresholdDetails.LOW_RSSI_CLIENT+"','"+thresholdDetails.LOW_DATA_RATE_CLIENT+"','"+thresholdDetails.FIRMWARE_VERSION+"')";
				if (debug) logger.info(queryToPutData);
				redisSentinel.set('THRSLD_'+thresholdDetails.WLC_ID+'_EXCESSIVE_ASSOCIATIONS', thresholdDetails.EXCESSIVE_ASSOCIATION);
				redisSentinel.set('THRSLD_'+thresholdDetails.WLC_ID+'_HIGH_AP_UTILIZATION', thresholdDetails.HIGH_AP_UTILIZATION);
				redisSentinel.set('THRSLD_'+thresholdDetails.WLC_ID+'_LOW_DATA_RATE', thresholdDetails.LOW_DATA_RATE);
				redisSentinel.set('THRSLD_'+thresholdDetails.WLC_ID+'_BANDWIDTH_WASTAGE', thresholdDetails.BANDWIDTH_WASTAGE);
				redisSentinel.set('THRSLD_'+thresholdDetails.WLC_ID+'_COMMUNICATION_ERRORS', thresholdDetails.COMMUNICATION_ERRORS);
				redisSentinel.set('THRSLD_'+thresholdDetails.WLC_ID+'_HIGH_RETRY', thresholdDetails.HIGH_RETRY);
				redisSentinel.set('THRSLD_'+thresholdDetails.WLC_ID+'_LOW_RSSI_CLIENT', thresholdDetails.LOW_RSSI_CLIENT);
				redisSentinel.set('THRSLD_'+thresholdDetails.WLC_ID+'_LOW_DATA_RATE_CLIENT', thresholdDetails.LOW_DATA_RATE_CLIENT);
				redisSentinel.set('THRSLD_'+thresholdDetails.WLC_ID+'_FIRMWARE_VERSION', thresholdDetails.FIRMWARE_VERSION);
				statement.executeUpdate(queryToPutData,
					function(errthreshold, count) {
                                                if (errthreshold) {
														if (debug) logger.error(errthreshold);
                                                        res.status(303).json({ error: "Update failed." });
                                                   } else {
                                                        if (debug) logger.info(null, count);
                                                        message = "Updated Successfully";
                                                        res.status(200).json({ success: message });
                                                  }
                                        })
                }
            });    
            }
        });
	  releaseConnection(connObjectLatest);
    }else{
        errCode = 401;
        errMsg = "Server is not connected.";
        res.status(errCode).json({ error: errMsg });
    }
})

app.route('/wlcapp/api/threshold/apclassification', cors(corsOptions)).post((req, res) => {
    if (enhancedlog) logger.debug(JSON.stringify(req.headers));
    if (!connId) {
       establishConnection();
    }
	if(connId){
        conn.createStatement(function(errCreateStatement, statement) {
          if (errCreateStatement) {
            res.status(errCode).json({ error: errMsg });
          } else {
            statement.setFetchSize(100, function(errFetchingSize) {
              if (errFetchingSize) {
                res.status(303).json({ error: errFetchingSize });
              } else {
				   statement.executeQuery("select max(TIME) AS TIME,LAST_VALUE(RSSI) WITHIN GROUP (ORDER BY TIME ASC) AS RSSI,LAST_VALUE(CLASSIFICATION) WITHIN GROUP (ORDER BY TIME ASC) AS CLASSIFICATION,SENSOR_MAC_ID,DETECTED_MAC_ID,SENSOR_AP_HOST_NAME,DETECTED_AP_HOST_NAME,SSID,SECURITY,PROTOCOL,FREQUENCY,analytics.ap_security_classification.WLC_ID AS WLC_ID,analytics.ap_location.SITE AS SITE,analytics.ap_location.BUILDING AS BUILDING,analytics.ap_location.FLOOR AS FLOOR from analytics.ap_security_classification inner join analytics.ap_location on analytics.ap_location.AP_HOST_NAME = analytics.ap_security_classification.SENSOR_AP_HOST_NAME group by analytics.ap_security_classification.WLC_ID,analytics.ap_security_classification.SENSOR_MAC_ID,analytics.ap_security_classification.DETECTED_MAC_ID,analytics.ap_security_classification.SENSOR_AP_HOST_NAME,analytics.ap_security_classification.DETECTED_AP_HOST_NAME,analytics.ap_security_classification.SSID,analytics.ap_security_classification.SECURITY,analytics.ap_security_classification.PROTOCOL,analytics.ap_security_classification.FREQUENCY,analytics.ap_location.SITE,analytics.ap_location.BUILDING,analytics.ap_location.FLOOR",
				   function(errExecQuery, classifcationResult) {
                    if (errExecQuery) {
					if (debug) logger.error(errExecQuery);
                    res.status(303).json({ error: "Failed to fetch details from DB" });
                  } else {
                    classifcationResult.toObjArray(function(errToArray, results) {
						if(!errToArray){
							sendBackResult = {};
							sendBackResult['list'] = results;
							sendBackResult['classificationOptions'] = process.env.AP_CLASSIFICATION;
							res.status(200).json({ classificationList: sendBackResult });
						}else{
							res.status(303).json({ error: "Failed to fetch details from DB" });
						}
					});
                  }
                });
              }
            });
          }
        });
      releaseConnection(connObjectLatest);
    }else{
        errCode = 401;
        errMsg = "Server is not connected.";
        res.status(errCode).json({ error: errMsg });
    }
})

app.route('/wlcapp/api/threshold/updateAPClassify', cors(corsOptions)).post((req, res) => {
    if (enhancedlog) logger.debug(JSON.stringify(req.headers));    
    if (!connId) { 
       establishConnection(); 
    }		
    if(connId){        
      updateAPClassify(req.body.scannedAPs, req.body.changeClassify, function(errUpdateAPClassify,resultUpdateAPClassify){
		if(errUpdateAPClassify){
			errCode = 303;
			if (debug) logger.error(errUpdateAPClassify);
			res.status(errCode).json({ error: errUpdateAPClassify });
		}else{
			if (debug) logger.info(resultUpdateAPClassify);
			res.status(200).json({ success: resultUpdateAPClassify });
		}
	})
	  releaseConnection(connObjectLatest);
    }else{
        errCode = 401;
        errMsg = "Server is not connected.";
        res.status(errCode).json({ error: errMsg });
    }
})

function updateAPClassify(scannedAPList,changeClassify,callback){
	conn.setAutoCommit(true, function(errCommit) {
	  if (errCommit) {
		errCode = 301;
		errMsg = "DB doesn't commit";
		return callback(errMsg, null);
	  } else {
		if (debug) logger.info("committed");            
		conn.createStatement(function(errCreateStatement, statement) {
		  if (errCreateStatement) {
			return callback(errMsg, null);
		  } else {				  
			let resultCount = 0;
			let errorCount = 0;
			let actualCount = 0;
			var ExecUpdateAsync = new Promise((resolve, reject) => {
				scannedAPList.forEach(element => {
					let queryToPutData;
					actualCount++;
					var keysFromElement = Object.keys(element);
					keysFromElement.forEach(key => {
						if(element[key]=='null' || !Boolean(element[key])){
							element[key] = '';
						}
					});
					queryToPutData = "UPSERT INTO analytics.ap_security_classification(TIME,WLC_ID,SENSOR_MAC_ID,DETECTED_AP_HOST_NAME,DETECTED_MAC_ID,SSID,RSSI,CLASSIFICATION,SECURITY,PROTOCOL,SENSOR_AP_HOST_NAME,FREQUENCY) VALUES (current_date(),'"+element.WLC_ID+"','"+element.SENSOR_MAC_ID+"','"+element.DETECTED_AP_HOST_NAME+"','"+element.DETECTED_MAC_ID+"','"+element.SSID+"','"+element.RSSI+"','"+changeClassify+"','"+element.SECURITY+"','"+element.PROTOCOL+"','"+element.SENSOR_AP_HOST_NAME+"','"+element.FREQUENCY+"')";
					redisSentinel.set('CLASSIFICATION_'+element.WLC_ID+'_'+element.DETECTED_MAC_ID, changeClassify);
					loggerToOpenNMS.info('DETECTED_MAC_ID : '+element.DETECTED_MAC_ID+' updated with Classification : '+changeClassify);
					statement.executeUpdate(queryToPutData,
						function(errExecQuery, apClassifyUpsertResult) {
							if (errExecQuery) {
								if (debug) logger.info(queryToPutData);
								if (debug) logger.error(errExecQuery);
								errorCount++;								
						    } else {								
								resultCount++;
								if (debug) logger.info(apClassifyUpsertResult);
						    }
							if(actualCount == scannedAPList.length){
								resolve('success');
							}else if(errorCount == scannedAPList.length) {
								reject('error');
							}
						})
					});
	            });
				ExecUpdateAsync.then((responseAsync) => {
					if(responseAsync == 'success'){
						if(!actualCount == 0 && resultCount > 0){
						return callback(null, 'Updated Successfully');
						}else if(errorCount > 0 && actualCount > 0) {
							return callback(null, 'Updated partially. Please retry the update');
						}else if(actualCount == errorCount) {
							return callback('Update failed.', null);
						}else{
							return callback('Update failed.', null);
						}
					}else{
						return callback('Update failed.', null);
					}
				});
			}
		});    
		}
	});
}

