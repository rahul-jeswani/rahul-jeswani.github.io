const express = require('express');
const cors = require('cors');
const app = express();
const winston = require('winston');

require('winston-syslog').Syslog;

sslogformat = winston.format.printf(({ level, message, label, timestamp }) => {
  return `${timestamp} ${level} [${label}] ${message}`;
});


var logger = winston.createLogger({
  format: winston.format.combine(
    winston.format.label({ label: 'WLC Main Server App' }),
    winston.format.timestamp(),
    sslogformat
  ),
  levels: winston.config.syslog.levels,
  transports: [
    new winston.transports.Console(),
  ]
});


app.listen(process.env.WLCAPPPORT, () => {
  logger.info('Server started!...') ;
})

app.use(cors(corsOptions));
app.set('json spaces', 40);

app.use(express.static('/opt/app-root/html/'));
const csv = require('fast-csv');
var fs = require('fs');
var errCode = null;
var errMsg = "";
var debug = true;
var enhancedlog = false;
var parserJson = require('xml2js');

if (debug) { logger['level'] = 'debug'; };
if (debug) { enhancedlog = true; };

const prom_client = require('prom-client');
const collectDefaultMetrics = prom_client.collectDefaultMetrics;
collectDefaultMetrics({ timeout: 5000 });


const register = require('prom-client/lib/registry').globalRegistry;

app.get(process.env.WLCAPPMETRICSURI, (req, res) => {
	res.set('Content-Type', register.contentType);
	res.end(register.metrics());
});



const parser = csv.parse();

var conn = null;
var connId = null;
var connObjectLatest = null;
var corsOptions = {
  origin: '*',
  optionsSuccessStatus: 200 // some legacy browsers (IE11, various SmartTVs) choke on 204 
}


const bodyParser = require('body-parser')
app.use(bodyParser.json())

function catch_all_handler(err, req, res, next) {
  res.status(500);
  logger.error("catchall exception :" + err);    
}
app.use(catch_all_handler)

app.route('/wlcapp/api/clientDeviceList/:name').post((req, res) => {
  if (enhancedlog) logger.debug(JSON.stringify(req.headers));    
  const requestedDeviceName = req.params['name']
  res.status(200).json({ test: requestedDeviceName });
})


var users = [];

app.route('/owsso/:username', cors(corsOptions)).get((req, res) => {
    if (enhancedlog) logger.debug(JSON.stringify(req.headers));    
    if (debug) logger.debug("received owsso/:username");
    let user = users.find(function(item) { return item.username == req.params.username});
    res.status(200).json({"user": user});
})

app.route('/owsso', cors(corsOptions)).post((req, res) => {
    if (enhancedlog) logger.debug(JSON.stringify(req.headers));    
    if (debug) logger.debug("received owsso/");
    let temp = users;
    if(temp.length == 0) {
        users.push(req.body);
        res.status(200).json({"users": users});
    } else {
        temp = temp.filter(function(item) {
            return item.username != req.body.username;
        });
        users = temp.length == 0 ? [] : temp;
        users.push(req.body);
        res.status(200).json({"users": users});
    }
})


app.route('/wlcapp/api/wlcstatus', cors(corsOptions)).get((req, res) => {
    if (enhancedlog) logger.debug(JSON.stringify(req.headers));    
    res.status(200).json({ wlcstatus: "Up" });
})


var Request = require("request");

app.route('/releases', cors(corsOptions)).get((req, res) => {
    Request.get("http://wlc/swupgrade/release.json", (error, response, body) => {
      if(error) {
        res.status(404).json({ "body": "No releases found"});
      }
      res.status(200).json({ "body": JSON.parse(body.toString())});
    })
})




