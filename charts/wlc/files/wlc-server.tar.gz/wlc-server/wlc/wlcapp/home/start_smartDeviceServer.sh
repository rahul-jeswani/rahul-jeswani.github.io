#!/usr/bin/bash

function logmessage {
   echo "`date +'%Y-%m-%dT%H:%M:%S%Z%z'` $1 [WLC SmartDevice Server App: `basename $0`] $2"
}

cd /home/wlcapp
[ -f /home/wlcapp/smartDeviceServer.js ] && cp /home/wlcapp/smartDeviceServer.js /opt/app-root/src/smartDeviceServer.js
cd /opt/app-root/src

while [ true ]
do
        logmessage "info" "(re)Starting SmartDevice Server"

        node smartDeviceServer.js

        logmessage "error" "SmartDevice Server exited"
    sleep 30
done

 
