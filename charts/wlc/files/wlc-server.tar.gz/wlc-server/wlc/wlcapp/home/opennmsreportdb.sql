--
-- PostgreSQL database dump
--

-- Dumped from database version 10.8 (Debian 10.8-1.pgdg90+1)
-- Dumped by pg_dump version 10.8 (Debian 10.8-1.pgdg90+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: report_saved; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.report_saved (
    id integer NOT NULL,
    report_name text NOT NULL,
    created_at timestamp without time zone,
    schedule_id integer
);


ALTER TABLE public.report_saved OWNER TO postgres;

--
-- Name: report_saved_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.report_saved_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.report_saved_id_seq OWNER TO postgres;

--
-- Name: report_saved_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.report_saved_id_seq OWNED BY public.report_saved.id;


--
-- Name: report_schedule; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.report_schedule (
    id integer NOT NULL,
    cron_schedule_string text NOT NULL,
    template_name text NOT NULL,
    start_at timestamp without time zone,
    end_to timestamp without time zone,
    created_at timestamp without time zone,
    save_report boolean,
    save_report_as character varying(20),
    send_report boolean
);


ALTER TABLE public.report_schedule OWNER TO postgres;

--
-- Name: report_schedule_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.report_schedule_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.report_schedule_id_seq OWNER TO postgres;

--
-- Name: report_schedule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.report_schedule_id_seq OWNED BY public.report_schedule.id;


--
-- Name: report_sent_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.report_sent_logs (
    id integer NOT NULL,
    sent boolean NOT NULL,
    details json,
    report_saved_id integer,
    report_tosend_id integer,
    created_at timestamp without time zone
);


ALTER TABLE public.report_sent_logs OWNER TO postgres;

--
-- Name: report_sent_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.report_sent_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.report_sent_logs_id_seq OWNER TO postgres;

--
-- Name: report_sent_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.report_sent_logs_id_seq OWNED BY public.report_sent_logs.id;


--
-- Name: report_tosend; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.report_tosend (
    id integer NOT NULL,
    email_id text NOT NULL,
    created_at timestamp without time zone,
    report_id integer
);


ALTER TABLE public.report_tosend OWNER TO postgres;

--
-- Name: report_tosend_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.report_tosend_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.report_tosend_id_seq OWNER TO postgres;

--
-- Name: report_tosend_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.report_tosend_id_seq OWNED BY public.report_tosend.id;


--
-- Name: report_saved id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.report_saved ALTER COLUMN id SET DEFAULT nextval('public.report_saved_id_seq'::regclass);


--
-- Name: report_schedule id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.report_schedule ALTER COLUMN id SET DEFAULT nextval('public.report_schedule_id_seq'::regclass);


--
-- Name: report_sent_logs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.report_sent_logs ALTER COLUMN id SET DEFAULT nextval('public.report_sent_logs_id_seq'::regclass);


--
-- Name: report_tosend id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.report_tosend ALTER COLUMN id SET DEFAULT nextval('public.report_tosend_id_seq'::regclass);


--
-- Data for Name: report_saved; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.report_saved (id, report_name, created_at, schedule_id) FROM stdin;
\.


--
-- Data for Name: report_schedule; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.report_schedule (id, cron_schedule_string, template_name, start_at, end_to, created_at, save_report, save_report_as, send_report) FROM stdin;
30	0 * * * *	OpenNMS-Report	2020-03-20 12:00:00	2020-03-31 12:00:00	2020-03-13 19:35:15.214	t	pdf	t
\.


--
-- Data for Name: report_sent_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.report_sent_logs (id, sent, details, report_saved_id, report_tosend_id, created_at) FROM stdin;
\.


--
-- Data for Name: report_tosend; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.report_tosend (id, email_id, created_at, report_id) FROM stdin;
26	prakal@mail.com	\N	30
27	test@mail.com	\N	30
\.


--
-- Name: report_saved_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.report_saved_id_seq', 1, false);


--
-- Name: report_schedule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.report_schedule_id_seq', 30, true);


--
-- Name: report_sent_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.report_sent_logs_id_seq', 1, false);


--
-- Name: report_tosend_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.report_tosend_id_seq', 27, true);


--
-- Name: report_saved report_saved_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.report_saved
    ADD CONSTRAINT report_saved_pkey PRIMARY KEY (id);


--
-- Name: report_saved report_saved_report_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.report_saved
    ADD CONSTRAINT report_saved_report_name_key UNIQUE (report_name);


--
-- Name: report_schedule report_schedule_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.report_schedule
    ADD CONSTRAINT report_schedule_pkey PRIMARY KEY (id);


--
-- Name: report_sent_logs report_sent_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.report_sent_logs
    ADD CONSTRAINT report_sent_logs_pkey PRIMARY KEY (id);


--
-- Name: report_tosend report_tosend_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.report_tosend
    ADD CONSTRAINT report_tosend_pkey PRIMARY KEY (id);


--
-- Name: report_saved report_saved_schedule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.report_saved
    ADD CONSTRAINT report_saved_schedule_id_fkey FOREIGN KEY (schedule_id) REFERENCES public.report_schedule(id);


--
-- Name: report_sent_logs report_sent_logs_report_saved_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.report_sent_logs
    ADD CONSTRAINT report_sent_logs_report_saved_id_fkey FOREIGN KEY (report_saved_id) REFERENCES public.report_saved(id);


--
-- Name: report_sent_logs report_sent_logs_report_tosend_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.report_sent_logs
    ADD CONSTRAINT report_sent_logs_report_tosend_id_fkey FOREIGN KEY (report_tosend_id) REFERENCES public.report_tosend(id);


--
-- Name: report_tosend report_tosend_report_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.report_tosend
    ADD CONSTRAINT report_tosend_report_id_fkey FOREIGN KEY (report_id) REFERENCES public.report_schedule(id);


--
-- PostgreSQL database dump complete
--
