#!/bin/bash

function logmessage {
   echo "`date +'%Y-%m-%dT%H:%M:%S%Z%z'` $1 [OpenWISP: `basename $0`] $2"
}

set -a
. /home/wlcapp/reportdb.int.env
. /home/wlcapp/topologydb.int.env

export PGPASSWORD=$POSTGRES_PASSWORD
export PGPASSWORD=$REPORT_DBPASS
if [ "$( psql -X -A -U $POSTGRES_USER -h $REPORT_DBHOST -d $POSTGRES_DB -p $REPORT_DBPORT -t -c "SELECT 1 FROM pg_database WHERE datname='$REPORT_DBNAME';" )" = '1' ]
then
    logmessage "info" "Report Database already exists"
    psql -X -A -U $POSTGRES_USER -h $REPORT_DBHOST -d $REPORT_DBNAME -p $REPORT_DBPORT -t -c "drop database $REPORT_DBNAME;" 2>/dev/null
fi

logmessage "info" "Reports Database being reloaded"
psql -X -A -U $POSTGRES_USER -h $REPORT_DBHOST -d $POSTGRES_DB -p $REPORT_DBPORT -t -c "create database $REPORT_DBNAME;"
psql -X -A -U $POSTGRES_USER -h $REPORT_DBHOST -d $REPORT_DBNAME -p $REPORT_DBPORT < /home/wlcapp/opennmsreportdb.sql
if [ "$( psql -X -A -U $POSTGRES_USER -h $TOPOLOGY_DBHOST -d $POSTGRES_DB -p $TOPOLOGY_DBPORT -t -c "SELECT 1 FROM pg_database WHERE datname='$TOPOLOGY_DBNAME';" )" = '1' ]
then
    logmessage "info" "Topology Database already exists"
else
    logmessage "info" "Topology Database need to be created"
    psql -X -A -U $POSTGRES_USER -h $TOPOLOGY_DBHOST -d $POSTGRES_DB -p $TOPOLOGY_DBPORT -t -c "create database $TOPOLOGY_DBNAME;"
fi
