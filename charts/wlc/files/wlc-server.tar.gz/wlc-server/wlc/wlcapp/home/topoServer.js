const express = require('express');
const cors = require('cors');
const app = express();
const winston = require('winston');

require('winston-syslog').Syslog;

sslogformat = winston.format.printf(({ level, message, label, timestamp }) => {
  return `${timestamp} ${level} [${label}] ${message}`;
});


var logger = winston.createLogger({
  format: winston.format.combine(
    winston.format.label({ label: 'WLC Topology Server App' }),
    winston.format.timestamp(),
    sslogformat
  ),
  levels: winston.config.syslog.levels,
  transports: [
    new winston.transports.Console(),
  ]
});



app.listen(process.env.WLCTOPOAPPPORT, () => {
  logger.info('Server started!...') ;
})

var multer = require('multer');
var path = require('path');

const { Sequelize, DataTypes, Model } = require('sequelize');
//databasetype://dbuser:dbpassword@dbhost:dbport/dbname
const sequelize = new Sequelize(`postgres://${process.env.TOPOLOGY_DBUSER}:${process.env.TOPOLOGY_DBPASS}@${process.env.TOPOLOGY_DBHOST}:${process.env.TOPOLOGY_DBPORT}/${process.env.TOPOLOGY_DBNAME}`);

let FloorImageMapping = {};
let FloorApDetails = {};
try {
    sequelize.authenticate()
        .then(res => logger.info('Connection has been established successfully.'))
        .catch(err => logger.error('Unable to connect to the database:', err));

    FloorImageMapping = sequelize.define('floor_image_mapping', {
        // Model attributes are defined here
        id: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        floor_id: {
            type: DataTypes.STRING,
            allowNull: false
        },
        floor_name: {
            type: DataTypes.STRING,
            allowNull: false
        },
        floor_image_path: {
            type: DataTypes.STRING,
            allowNull: false
        },
        floor_breadth: {
            type: DataTypes.STRING,
            allowNull: false
        },
        floor_length: {
            type: DataTypes.STRING,
            allowNull: false
        }
    }, {
        // Other model options go here
    });

    // FloorImageMapping.drop();

    FloorImageMapping.sync({ force: false })
        .then(res => logger.info('The table for the floor_image_mapping model was just (re)created!'))
        .catch(err => logger.error('The table for the floor_image_mapping model was not (re)created!:', err));


    FloorApDetails = sequelize.define('floor_ap_details', {
        // Model attributes are defined here
        id: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        floor_id: {
            type: DataTypes.STRING,
            allowNull: false
        },
        floor_name: {
            type: DataTypes.STRING,
            allowNull: false
        },
        ap_id: {
            type: DataTypes.STRING,
            allowNull: false
        },
        ap_name: {
            type: DataTypes.STRING,
            allowNull: false
        },
        ap_coordinates: {
            type: DataTypes.STRING,
            allowNull: false
        },
        ap_icon_path: {
            type: DataTypes.STRING,
            allowNull: false
        }
    }, {
        // Other model options go here
    });

    FloorApDetails.sync({ force: false })
        .then(res => logger.info('The table for the floor_ap_details model was just (re)created!'))
        .catch(err => logger.error('The table for the floor_ap_details model was not (re)created!:', err));

} catch (error) {
    logger.error('Unable to connect to the database:', error);
}

var corsOptions = {
  origin: '*',
  optionsSuccessStatus: 200 // some legacy browsers (IE11, various SmartTVs) choke on 204 
}

app.use(cors(corsOptions));
function catch_all_handler(err, req, res, next) {
    res.status(500);
    logger.error("catchall exception :" + err);
}
app.use(catch_all_handler);
app.set('json spaces', 40);

const bodyParser = require('body-parser')
app.use(bodyParser.json())

var storage = multer.diskStorage({
    destination: function (req, file, callback) {
        callback(null, '/home/wlcapp/public/topology/floorimages');
    },
    filename: function (req, file, callback) {
        callback(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname));
    }
});

var upload = multer({ storage: storage, limits: { fileSize: 5000000 } }).single('floorImage');
const serveIndex = require('serve-index');
app.use(express.static('/home/wlcapp/public/'));


/* Pheonix DB connectivity functionality starts */

app.use(express.static('/opt/app-root/html/'));
var JDBC = require('jdbc');
var jinst = require('jdbc/lib/jinst');
var asyncjs = require('async');
var util = require('util');
var Poolap = require('jdbc/lib/pool');
var redis = require('redis');
var client = redis.createClient(process.env.REDISPORT,process.env.REDISSERVER);
const csv = require('fast-csv');
var fs = require('fs');
var errCode = null;
var errMsg = "";
var redisConnection = false;
var phoenixConnection = false;
var debug = true;
var enhancedlog = false;

if (debug) { logger['level'] = 'debug'; };
if (debug) { enhancedlog = true; };
const parser = csv.parse();
client.on('connect', function() {
  try {
    if(debug) logger.info('Redis client connected');
    redisConnection = true;
    if(!phoenixConnection){
        establishConnection();
    }    
  }
  catch(err) {
    logger.error("catchall exception :" + err);    
  }
});

client.on('error', function (err) {
  try {
    logger.error('Something went wrong ' + err);
    errCode = 310;
    errMsg = "Redis doesn't connect";
    redisConnection = false;
    connId = null;
    if(phoenixConnection){
        phoenixConnection = false;
    }
  }
  catch(err) {
    logger.error("catchall exception :" + err);    
  }
});

if (!jinst.isJvmCreated()) {
  jinst.addOption('-Xrs')
  jinst.setupClasspath([  
    '/opt/app-root/src/appheonixplugin/hadoopjars/*',
    '/opt/app-root/src/appheonixplugin/hbasejars/*',    
    '/opt/app-root/src/appheonixplugin/',
    '/opt/app-root/src/appheonixplugin/phoenix-4.7.0.2.6.5.0-292-client.jar',
        '/opt/app-root/src/pglibs/postgresql-42.2.8.jar',
        '/opt/app-root/src/jasperlibs/jasperreports-5.6.0.jar',
        '/opt/app-root/src/jasperlibs/commons-beanutils-1.9.4.jar',
        '/opt/app-root/src/jasperlibs/jackson-databind-2.10.1.jar',
        '/opt/app-root/src/jasperlibs/jackson-core-2.10.1.jar',
        '/opt/app-root/src/jasperlibs/commons-collections4-4.0.jar',
        '/opt/app-root/src/jasperlibs/commons-collections-3.2.1.jar',
        '/opt/app-root/src/jasperlibs/commons-digester-2.1.jar',
        '/opt/app-root/src/jasperlibs/itext-2.1.7.jar'   
          ])
}

//        '/opt/app-root/src/jasperlibs/groovy-all-2.2.1.jar',

var config = {
  drivername: 'org.apache.phoenix.jdbc.PhoenixDriver',
  url: 'jdbc:phoenix:' + process.env.PHOENIXSERVERS + ':/hbase-unsecure',
  user: '',
  password: '',
  minpoolsize:2,
  maxpoolsize: 100,
  maxidle:30000
 
}

var hsqldb = new JDBC(config);
try {
    hsqldb.initialize(function(err) {    
          if (err) {
            logger.error(err);
            errCode = 300;
            errMsg = "DB doesn't connect";
          } else {
          if (debug) logger.info("Initialized");      
        }
    });
}
catch(err) {
  logger.error("catchall exception :" + err);    
}

var conn = null;
var connId = null;
var connObjectLatest = null;

async function connect() {
    if (debug) logger.info("connect...");
    return new Promise((resolve, reject) => {
        const poolPromise = reserveDBConnection();
        poolPromise
            .then(pool => {
                if (debug) logger.info("connected");
                phoenixConnection = true;                
                resolve(pool);
            })
            .catch(err => {
                reject(err);
            });
    });
}

async function establishConnection() {
     if (debug) logger.info("establishConnection...");
     var a = connect();
     a.then(a => { if (debug) logger.info("success") } )
    .catch(err => {
        logger.error("Retrying",a);
		setTimeout(establishConnection, 5000);
	});
};

async function reserveDBConnection(){
	hsqldb.reserve(function(err, connObj) {
	  if (connObj) {
		connObjectLatest = connObj;
		conn = connObj.conn;
		connId = connObj.uuid;
	 
		asyncjs.series([
		  function(callback) {
			conn.setAutoCommit(false, function(err) {
			  if (err) {
				errCode = 301;
				errMsg = "DB doesn't commit";
				if (debug) logger.info("not committed");
			  } else {
				if (debug) logger.info("committed");
				callback(null);
			  }
			});
		  },
		  function(callback) {
			conn.setSchema("analytics", function(err) {
			  if (err) {
				callback(err);
				errCode = 302;
				errMsg = "Schema doesn't set";
			  } else {
				if (debug) logger.info("schema set");
				callback(null);
			  }
			});
		  }
		], function(err, results) {
		});		 
	  }else if(err){
		logger.error(err.message);  
	  }  
	});
}

async function releaseConnection(connObjectNew) {
    if(!(connObjectNew == null)){
      hsqldb.release(connObjectNew, function(err) {
        if (err) {
          logger.error(err.message);
        }
      });
    }
	connId = null;
	connObjectLatest = null;
}

/* Pheonix DB connectivity functionality ends*/

app.post('/topology/api/upload', function (req, res) {
	
	if (enhancedlog) logger.debug(JSON.stringify(req.headers));
    if (debug) logger.debug("received topology/api/upload");
    
    upload(req, res, function (err) {

        let data = JSON.parse(req.body.data);
        if (err) {
            logger.error("/topology/api/upload ", err);
            return res.status(500).send(err.stack);
        }

        for (let i = 0; i < data.ap_data.length; i++) {

            FloorImageMapping.findAll({
                where: {
                    floor_id: data.ap_data[i].floor_id
                }
            }).then(floor => {
                if (floor[0] != undefined) {

                    FloorImageMapping.update({
                        floor_image_path: data.ap_data[i].ap_image_path ? data.ap_data[i].ap_image_path : "/topology/floorimages/" + req.file.filename,
						floor_breadth: data.ap_data[i].floor_breadth,
                        floor_length: data.ap_data[i].floor_length
                    }, {
                        where: {
                            floor_id: data.ap_data[i].floor_id
                        }
                    })
                        .then(resp => {
							if (i == (data.ap_data.length - 1)) {
                                res.status(200).send({ "fileName": "/topology/floorimages/" + req.file.filename })
                            }							
						})
                        .catch(err => {
                            logger.error("/topology/api/upload (Update)", err);
                            res.status(400).send({ "msg": "Image upload failed!..." });
                        });
                } else {
                    FloorImageMapping.create({
                        floor_id: data.ap_data[i].floor_id,
                        floor_name: data.ap_data[i].floor_name,
						floor_breadth: data.ap_data[i].floor_breadth,
                        floor_length: data.ap_data[i].floor_length,
                        floor_image_path: data.ap_data[i].ap_image_path ? data.ap_data[i].ap_image_path : "/topology/floorimages/" + req.file.filename
                        // ap_image_path: "http://localhost:3002/ftp/uploads/floorImage-1581675329586.PNG"

                    })
                        .then(reslt => {
							if (i == (data.ap_data.length - 1)) {
                                res.status(200).send({ "fileName": "/topology/floorimages/" + req.file.filename })
                            }
						})
                        .catch(err => {
							logger.error("/topology/api/upload (Insert)", err);
							res.status(400).send({ "msg": "Image upload failed!..."})
						});
						
                }
            });

        }


    });
});

app.post('/topology/api/updateimage', function (req, res) {

    if (enhancedlog) logger.debug(JSON.stringify(req.headers));
    if (debug) logger.debug("received topology/api/updateimage");

    let data = req.body; 

    for (let i = 0; i < data.ap_data.length; i++) {

        let floor = FloorImageMapping.findAll({
            where: {
                floor_id: data.ap_data[i].floor_id
            }
        })
            .then(floor => {
                if (floor[0] != undefined) {
                    FloorImageMapping.update({
                        floor_image_path: data.ap_data[i].floor_image_path,
						floor_breadth: data.ap_data[i].floor_breadth,
                        floor_length: data.ap_data[i].floor_length
                    }, {
                        where: {
                            floor_id: data.ap_data[i].floor_id
                        }
                    })
                        .then(reslt => {
                            if (i == (data.ap_data.length - 1)) {
                                res.status(200).send({ "fileName": data.ap_data[0].floor_image_path });
                            }
                        })
                        .catch(err => {
                            logger.error("/topology/api/updateimage (Update)", err);
                            res.status(400).send({ "msg": "Image upload failed!..." });
                        });
                } else {
                    FloorImageMapping.create({
                        floor_id: data.ap_data[i].floor_id,
                        floor_name: data.ap_data[i].floor_name,
						floor_breadth: data.ap_data[i].floor_breadth,
                        floor_length: data.ap_data[i].floor_length,
                        floor_image_path: data.ap_data[i].floor_image_path
                    })
                        .then(reslt => {
                            if (i == (data.ap_data.length - 1)) {
                                res.status(200).send({ "fileName": data.ap_data[0].floor_image_path });
                            }
                        })
                        .catch(err => {
                            logger.error("/topology/api/updateimage (Insert)", err);
                            res.status(400).send({ "msg": "Image upload failed!..." });
                        });
                }
            });

    }
    
});


app.post('/topology/api/savefloorconfig', function (req, res) {

    if (enhancedlog) logger.debug(JSON.stringify(req.headers));
    if (debug) logger.debug("received topology/api/savefloorconfig");
    
    let data = req.body;

    for (let i = 0; i < data.ap_data.length; i++) {

        let floor = FloorApDetails.findAll({
            where: {
                floor_id: data.ap_data[i].floor_id,
                ap_id: data.ap_data[i].ap_id
            }
        })
            .then(floor => {
                if (floor[0] != undefined) {
                    FloorApDetails.update({
                        ap_coordinates: data.ap_data[i].ap_coordinates,
                        ap_icon_path: data.ap_data[i].ap_icon_path
                     }, {
                         where: {
                             floor_id: data.ap_data[i].floor_id,
                             ap_id: data.ap_data[i].ap_id
                        }
                    })
                        .then(reslt => {
							res.status(200).send({ "Status": "Floor configuration details are successfully updated" });
						})
                        .catch(err => {
                            logger.error("/topology/api/savefloorconfig (Update)", err);
                            res.status(400).send({ "Status": "Floor configuration details are failed to update"});
                        });
                } else {
                    FloorApDetails.create({
                        floor_id: data.ap_data[i].floor_id,
                        floor_name: data.ap_data[i].floor_name,
                        ap_id: data.ap_data[i].ap_id,
                        ap_name: data.ap_data[i].ap_name,
                        ap_coordinates: data.ap_data[i].ap_coordinates,
                        ap_icon_path: data.ap_data[i].ap_icon_path,
                    })
                        .then(reslt => {
							res.status(200).send({ "Status": "Floor configuration details are successfully inserted" });
						})
                        .catch(err => {
                            logger.error("/topology/api/savefloorconfig (Insert)", err);
                            res.status(400).send({ "Status": "Floor configuration details are failed to insert" });
                        });
                }
            });
    }
    
});
app.get("/topology/api/floorplanimages", (req, res) => {
    
    if (enhancedlog) logger.debug(JSON.stringify(req.headers));
    if (debug) logger.debug("received topology/api/floorplanimages");
    
    FloorImageMapping.findAll()
        .then(images => {
            const imgs = images;
            res.send(imgs);
        })
        .error(err => {
            logger.error("/topology/api/floorplanimages ", err);
            res.status(400).send({ msg: "images are not found" });
        })
});

app.get("/topology/api/floorapdetails/:floor_id", (req, res) => {
    
    if (enhancedlog) logger.debug(JSON.stringify(req.headers));
    if (debug) logger.debug("received topology/api/floordetails/:floor_id");
    
    FloorApDetails.findAll({
        where: {
            floor_id: req.params.floor_id,
        }
    })
        .then(apdeatils => {
            const imgs = apdeatils;
            res.send(imgs);
        })
        .error(err => {
            logger.error("/topology/api/floorapdetails/:floor_id ", err);
            res.status(400).send({ msg: "Floor's AP details are not found" });
        })
});

app.post('/topology/api/deletefloorconfig', function (req, res) {

    if (enhancedlog) logger.debug(JSON.stringify(req.headers));
    if (debug) logger.debug("received topology/api/deletefloorconfig");
    
    let data = req.body;

    FloorApDetails.destroy({
        where: {
            floor_id: data.floor_id,
            ap_id: data.ap_id
        }
    })
        .then(floor => {
            res.status(200).send({ "Status": "Floor configuration detail has successfully deleted" });
        })
        .error(err => {
            logger.error("/topology/api/deletefloorconfig ", err);
            res.status(400).send({ "Status": "Floor configuration detail has failed to delete" });
        });

});


app.post('/topology/api/apcoverage', function (req, res) {

    let arr = req.body.apdata;
    var params = "";
    for (var i = 0; i <= arr.length; i++) {
        params = params + "','" + arr[i];
    }

    if (enhancedlog) logger.debug(JSON.stringify(req.headers));
    if (debug) logger.debug("received topology/api/apcoveage");
    
    if (!connId && phoenixConnection) {
       establishConnection();
    }

        if(connId){
    conn.setAutoCommit(true, function(err1) {
          if (err1) {
            errCode = 301;
            errMsg = "DB doesn't commit";
            logger.error("/topology/api/apcoverage (AutoCommit)", err1);
            res.status(errCode).send({ error: errMsg });
          } else {
            if (debug) logger.info("committed");
            conn.createStatement(function(err2, statement) {
              if (err2) {
                  logger.error("/topology/api/apcoverage (createStatement)", err2);
                  res.status(errCode).send({ error: errMsg });
              } else {
                statement.executeQuery("SELECT * FROM ap_radio WHERE ap_mac_id IN('"+params+"')",
                           function(err3, results) {
                          if (err3) {
                            logger.error("/topology/api/apcoverage (executeQuery)", err3);
                            res.status(400).send({ error: "Data not found" });
                          } else {
                            results.toObjArray(function(err4, results1) {
                              if(err4) { logger.error("/topology/api/apcoverage (toObjArray)", err4); res.status(400).send({error: "Data not found"});}
                              else {
                                  let powerFactor = process.env.POWER_FACTOR ? process.env.POWER_FACTOR : 5;
                                  res.status(200).send({ "powerFactor": powerFactor, "aplist": results1 });
                                  
                              }
                            });

                          }
                        releaseConnection(connObjectLatest);
                       });
                }
            });    
            }
        });
    }else{
        errCode = 401;
        errMsg = "Server is not connected.";
        res.status(errCode).send({ error: errMsg });
    }  
	
});

app.post('/topology/api/apsclientdevices', function (req, res) {

    let arr = req.body.apdata;
    var params = "";
    for (var i = 0; i <= arr.length; i++) {
        params = params + "','" + arr[i];
    }

    if (enhancedlog) logger.debug(JSON.stringify(req.headers));
    if (debug) logger.debug("received topology/api/apsclientdevices");
    
    if (!connId && phoenixConnection) {
       establishConnection();
    }

        if(connId){
    conn.setAutoCommit(true, function(err1) {
          if (err1) {
            errCode = 301;
            errMsg = "DB doesn't commit";
            logger.error("/topology/api/apsclientdevices (AutoCommit)", err1);
            res.status(errCode).send({ error: errMsg });
          } else {
            if (debug) logger.info("committed");
            conn.createStatement(function(err2, statement) {
              if (err2) {
                  logger.error("/topology/api/apsclientdevices (createStatement)", err2);
                  res.status(errCode).send({ error: errMsg });
              } else {
                statement.executeQuery("SELECT * FROM client_rssi WHERE ap_mac_id IN('"+params+"')",
                           function(err3, results) {
                          if (err3) {
                            logger.error("/topology/api/apsclientdevices (executeQuery)", err3);
                            res.status(400).send({ error: "Data not found" });
                          } else {
                            
                            results.toObjArray(function(err4, results1) {
                              if(err4) { logger.error("/topology/api/apsclientdevices (toObjArray)", err4); res.status(400).send({error: "Data not found"});}
                              else {
                                  let timeIntervals = process.env.TIME_INTERVALS ? process.env.TIME_INTERVALS : 300000;
                                  let rssi_cf = process.env.RSSI_CF ? process.env.RSSI_CF : 3.3;
                                  res.status(200).send({ "rssiCF": rssi_cf, "timeIntervals": timeIntervals, "clientlist":results1 });
                                  
                              }
                            });

                          }
                        releaseConnection(connObjectLatest);
                       });
                }
            });    
            }
        });
    }else{
        errCode = 401;
        errMsg = "Server is not connected.";
        res.status(errCode).send({ error: errMsg });
    }  
	
});


app.post('/topology/api/rogueaps', function (req, res) {
    let floor = req.body.floordata;

    if (enhancedlog) logger.debug(JSON.stringify(req.headers));
    if (debug) logger.debug("received topology/api/rogueaps");
    
    if (!connId && phoenixConnection) {
       establishConnection();
    }

        if(connId){
    conn.setAutoCommit(true, function(err1) {
          if (err1) {
            errCode = 301;
            errMsg = "DB doesn't commit";
            logger.error("/topology/api/rogueaps (AutoCommit)", err1);
            res.status(errCode).send({ error: errMsg });
          } else {
            if (debug) logger.info("committed");
            conn.createStatement(function(err2, statement) {
              if (err2) {
                  logger.error("/topology/api/rogueaps (createStatement)", err2);
                  res.status(errCode).send({ error: errMsg });
              } else {
                let sqlq = "select * from ap_security_classification as a left join ap_location as l on a.sensor_mac_id=l.macid where l.floor='"+floor.floor+"' and l.building='"+floor.building+"' and l.site='"+floor.site+"'";
                statement.executeQuery(sqlq,
                           function(err3, results) {
                          if (err3) {
                            logger.error("/topology/api/rogueaps (executeQuery)", err3);
                            res.status(400).send({ error: "Data not found" });
                          } else {
                            
                            results.toObjArray(function(err4, results1) {
                              if(err4) { logger.error("/topology/api/rogueaps (toObjArray)", err4); res.status(400).send({error: "Data not found"});}
                              else {
                                  res.status(200).send(results1);

                              }
                            });

                          }
                        releaseConnection(connObjectLatest);
                       });
                }
            });
	}
        });
    }else{
        errCode = 401;
        errMsg = "Server is not connected.";
        res.status(errCode).send({ error: errMsg });
    }

});



app.post('/topology/wlc-fqdn/femto_stats_request', function (req, res) {


    if (enhancedlog) logger.debug(JSON.stringify(req.headers));
    if (debug) logger.debug("received topology/wlc-fqdn/femto_stats_request");

    if (!req.body['ap'].mac_address) {
        return res.status(400).send({ "result": "Bad inputs : mac_address is mandatory", "status_code": 400 });
    }

    let regex = /^([0-9A-F]{2}[:-]){5}([0-9A-F]{2})$/;
    if (!regex.test(req.body['ap'].mac_address.toUpperCase())) {
        return res.status(400).send({ "result": "Bad inputs : Invalid mac_address", "status_code": 400 });
    }

    if (!req.body['ap'].Params) {
        return res.status(400).send({ "result": "Bad inputs : Params is mandatory", "status_code": 400 });
    }

    if (!req.body['ap'].Params.startTime) {
        return res.status(400).send({ "result": "Bad inputs : startTime is mandatory", "status_code": 400 });
    }

    if (!req.body['ap'].Params.endTime) {
        return res.status(400).send({ "result": "Bad inputs : endTime is mandatory", "status_code": 400 });
    }

    if (!connId && phoenixConnection) {
        establishConnection();
    }

    if (connId) {
        conn.setAutoCommit(true, function (err1) {
            if (err1) {
                errCode = 301;
                errMsg = "DB doesn't commit";
                logger.error("/topology/wlc-fqdn/femto_stats_request (AutoCommit)", err1);
                res.status(errCode).send({ error: errMsg });
            } else {
                if (debug) logger.info("committed");
                conn.createStatement(function (err2, statement) {
                    if (err2) {
                        logger.error("/topology/wlc-fqdn/femto_stats_request (createStatement)", err2);
                        res.status(errCode).send({ "result": "Failed", "status_code": 400 });
                    } else {
                        let apObj = req.body['ap'];
                        let sqlq = "select sum(traffic) as datac from ap_traffic where (time >= TO_TIME('" + apObj.Params.startTime + "') and time <= TO_TIME('" + apObj.Params.endTime + "')) and ap_mac_id = '" + apObj.mac_address.toUpperCase() + "'";
                        statement.executeQuery(sqlq, function (err3, results) {
                            if (err3) {
                                logger.error("/topology/wlc-fqdn/femto_stats_request (executeQuery)", err3);
                                releaseConnection(connObjectLatest);
                                res.status(400).send({ "result": "Failed", "status_code": 400 });
                            } else {
                                let dataConsumed = "";
                                results.toObjArray(function (err4, results1) {
                                    if (err4) {
                                        logger.error("/topology/wlc-fqdn/femto_stats_request (toObjArray)", err4);
                                        res.status(400).send({ "result": "Failed", "status_code": 400 });
                                    } else {
                                        dataConsumed = results1[0]['DATAC'];
                                        let sqlq2 = "select time, client_association_count, ap_mac_id from client_count where (time >= TO_TIME('" + apObj.Params.startTime + "') and time <= TO_TIME('" + apObj.Params.endTime + "')) and ap_mac_id = '" + apObj.mac_address + "' order by time desc limit 1";
                                        statement.executeQuery(sqlq2, function (err5, results2) {
                                            if (err5) {
                                                logger.error("/topology/wlc-fqdn/femto_stats_request (executeQuery)", err5);
                                                res.status(400).send({ "result": "Failed", "status_code": 400 });
                                            } else {

                                                results2.toObjArray(function (err6, results3) {
                                                    if (err6) {
                                                        logger.error("/topology/wlc-fqdn/femto_stats_request (toObjArray)", err6);
                                                        res.status(400).send({ "result": "Failed", "status_code": 400 });
                                                    } else {
                                                        let resObj = { "ap": { "version": apObj.version, "device": apObj.device, "model": apObj.model, "txn_id": apObj.txn_id, "location": apObj.location, "request_type": apObj.request_type, "oss_fdqn": apObj.oss_fdqn, "mac_address": apObj.mac_address, "serial_number": apObj.serial_number, "stats": { "no_of_wifi_clients": results3[0].CLIENT_ASSOCIATION_COUNT, "data_consumption": bytesToSize(dataConsumed), "time": results3[0].TIME }, "result": "Success", "status_code": 200 } };
                                                        res.status(200).send(resObj);
                                                    }
                                                });

                                            }
                                            releaseConnection(connObjectLatest);
                                        });
                                    }
                                });



                            }

                        });
                    }
                });
            }
        });
    }
    else {
        errCode = 401;
        errMsg = "Server is not connected.";
        res.status(errCode).send({ error: errMsg });
    }

});


function bytesToSize(bytes) {
    var sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    if (bytes == 0) return '0Byte';
    if (bytes == 1) return '1Byte';
    var i = parseInt(Math.floor(Math.log(bytes) / Math.log(1024)));
    return Math.round(bytes / Math.pow(1024, i), 2) + '' + sizes[i];
}
