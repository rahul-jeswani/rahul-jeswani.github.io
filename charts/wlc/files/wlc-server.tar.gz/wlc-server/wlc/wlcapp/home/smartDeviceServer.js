const express = require('express');
const cors = require('cors');
const app = express();
const winston = require('winston');

require('winston-syslog').Syslog;

sslogformat = winston.format.printf(({ level, message, label, timestamp }) => {
  return `${timestamp} ${level} [${label}] ${message}`;
});


var logger = winston.createLogger({
  format: winston.format.combine(
    winston.format.label({ label: 'WLC Smart Device Server' }),
    winston.format.timestamp(),
    sslogformat
  ),
  levels: winston.config.syslog.levels,
  transports: [
    new winston.transports.Console(),
  ]
});


app.listen(process.env.WLCSMARTDEVICEAPPPORT, () => {
  logger.info('Server started!...') ;
})

app.use(cors(corsOptions));
app.set('json spaces', 40);

app.use(express.static('/opt/app-root/html/'));
var JDBC = require('jdbc');
var jinst = require('jdbc/lib/jinst');
var asyncjs = require('async');
var util = require('util');
var Poolap = require('jdbc/lib/pool');
var redis = require('redis');
var client = redis.createClient(process.env.REDISPORT,process.env.REDISSERVER);
const csv = require('fast-csv');
var fs = require('fs');
var errCode = null;
var errMsg = "";
var redisConnection = false;
var phoenixConnection = false;
var debug = true;
var enhancedlog = false;
const RedisSentinel = require("ioredis");
var redisSentinel = new RedisSentinel({
  sentinels: [{ host: process.env.REDISSERVER, port: process.env.REDISPORT_PRIMARY }, 
			  { host: process.env.REDISSERVER_SECONDARY, port: process.env.REDISPORT_SECONDARY }, 
			  { host: process.env.REDISSERVER_TERTIARY, port: process.env.REDISPORT_TERTIARY }],
  name: 'mymaster'
});

if (debug) { logger['level'] = 'debug'; };
if (debug) { enhancedlog = true; };

const prom_client = require('prom-client');
const collectDefaultMetrics = prom_client.collectDefaultMetrics;
collectDefaultMetrics({ timeout: 5000 });


const register = require('prom-client/lib/registry').globalRegistry;

app.get(process.env.WLCAPPMETRICSURI, (req, res) => {
	res.set('Content-Type', register.contentType);
	res.end(register.metrics());
});



const parser = csv.parse();
client.on('connect', function() {
  try {
    if(debug) logger.info('Redis client connected');
    redisConnection = true;
    if(!phoenixConnection){
        establishConnection();
    }    
  }
  catch(err) {
    logger.error("catchall exception :" + err);    
  }
});

client.on('error', function (err) {
  try {
    logger.error('Something went wrong ' + err);
    errCode = 310;
    errMsg = "Redis doesn't connect";
    redisConnection = false;
    connId = null;
    if(phoenixConnection){
        phoenixConnection = false;
    }
  }
  catch(err) {
    logger.error("catchall exception :" + err);    
  }
});

if (!jinst.isJvmCreated()) {
  jinst.addOption('-Xrs')
  jinst.setupClasspath([  
    '/opt/app-root/src/appheonixplugin/hadoopjars/*',
    '/opt/app-root/src/appheonixplugin/hbasejars/*',    
    '/opt/app-root/src/appheonixplugin/',
    '/opt/app-root/src/appheonixplugin/phoenix-4.7.0.2.6.5.0-292-client.jar',
        '/opt/app-root/src/pglibs/postgresql-42.2.8.jar',
        '/opt/app-root/src/jasperlibs/jasperreports-5.6.0.jar',
        '/opt/app-root/src/jasperlibs/commons-beanutils-1.9.4.jar',
        '/opt/app-root/src/jasperlibs/jackson-databind-2.10.1.jar',
        '/opt/app-root/src/jasperlibs/jackson-core-2.10.1.jar',
        '/opt/app-root/src/jasperlibs/commons-collections4-4.0.jar',
        '/opt/app-root/src/jasperlibs/commons-collections-3.2.1.jar',
        '/opt/app-root/src/jasperlibs/commons-digester-2.1.jar',
        '/opt/app-root/src/jasperlibs/itext-2.1.7.jar'   
          ])
}

//        '/opt/app-root/src/jasperlibs/groovy-all-2.2.1.jar',

var config = {
  drivername: 'org.apache.phoenix.jdbc.PhoenixDriver',
  url: 'jdbc:phoenix:' + process.env.PHOENIXSERVERS + ':/hbase-unsecure',
  user: '',
  password: '',
  minpoolsize:2,
  maxpoolsize: 100,
  maxidle:30000
 
}

var hsqldb = new JDBC(config);
try {
    hsqldb.initialize(function(err) {    
          if (err) {
            logger.error(err);
            errCode = 300;
            errMsg = "DB doesn't connect";
          } else {
          if (debug) logger.info("Initialized");      
        }
    });
}
catch(err) {
  logger.error("catchall exception :" + err);    
}

var conn = null;
var connId = null;
var connObjectLatest = null;
var corsOptions = {
  origin: '*',
  optionsSuccessStatus: 200 // some legacy browsers (IE11, various SmartTVs) choke on 204 
}

async function connect() {
    if (debug) logger.info("connect...");
    return new Promise((resolve, reject) => {
        const poolPromise = reserveDBConnection();
        poolPromise
            .then(pool => {
                if (debug) logger.info("connected");
                phoenixConnection = true;                
                resolve(pool);
            })
            .catch(err => {
                reject(err);
            });
    });
}

async function establishConnection() {
     if (debug) logger.info("establishConnection...");
     var a = connect();
     a.then(a => { if (debug) logger.info("success") } )
    .catch(err => {
        logger.error("Retrying",a);
		setTimeout(establishConnection, 5000);
	});
};

async function reserveDBConnection(){
	hsqldb.reserve(function(err, connObj) {
	  if (connObj) {
		connObjectLatest = connObj;
		conn = connObj.conn;
		connId = connObj.uuid;
	 
		asyncjs.series([
		  function(callback) {
			conn.setAutoCommit(false, function(err) {
			  if (err) {
				errCode = 301;
				errMsg = "DB doesn't commit";
				if (debug) logger.info("not committed");
			  } else {
				if (debug) logger.info("committed");
				callback(null);
			  }
			});
		  },
		  function(callback) {
			conn.setSchema("analytics", function(err) {
			  if (err) {
				callback(err);
				errCode = 302;
				errMsg = "Schema doesn't set";
			  } else {
				if (debug) logger.info("schema set");
				callback(null);
			  }
			});
		  }
		], function(err, results) {
		});		 
	  }else if(err){
		logger.error(err.message);  
	  }  
	});
}

async function releaseConnection(connObjectNew) {
    if(!(connObjectNew == null)){
      hsqldb.release(connObjectNew, function(err) {
        if (err) {
          logger.error(err.message);
        }
      });
    }
	connId = null;
	connObjectLatest = null;
}
const url = require('url');
const myURL = url.parse(config.url);


const bodyParser = require('body-parser')
app.use(bodyParser.json())

function catch_all_handler(err, req, res, next) {
  res.status(500);
  logger.error("catchall exception :" + err);    
}
app.use(catch_all_handler)

app.route('/wlcapp/api/clientDeviceList', cors(corsOptions)).post((req, res) => {
    if (enhancedlog) logger.debug(JSON.stringify(req.headers));    
    if (!connId && phoenixConnection) { 
       establishConnection(); 
    }
    if(connId){
        conn.createStatement(function(errCreateStatement, statement) {
          if (errCreateStatement) {
			if (debug) logger.error(errCreateStatement);  
            res.status(errCode).json({ error: errMsg });
          } else {
            statement.setFetchSize(100, function(errFetchingSize) {
              if (errFetchingSize) {
				if (debug) logger.error(errFetchingSize);
                res.status(303).json({ error: errFetchingSize });
              } else {
                statement.executeQuery("SELECT * FROM client_smartdevice",
                   function(errExecQuery, resultset) {
                    if (errExecQuery) {
						if (debug) logger.error(errExecQuery);
						res.status(303).json({ error: "Failed to fetch details from DB" });
					  } else {
						resultset.toObjArray(function(errToArray, results) {
							if(!errToArray){
								if (debug) logger.error(errToArray);
								res.status(200).json({ deviceList: results });
							}else{
								res.status(303).json({ error: "Failed to fetch details from DB" });
							}
							
						});
					  }
                });
              }
            });
          }
        });
      releaseConnection(connObjectLatest);
    }else{
        errCode = 401;
        errMsg = "Server is not connected.";
        res.status(errCode).json({ error: errMsg });
    }
})


app.route('/wlcapp/api/clientDeviceList/markSmartDevice', cors(corsOptions)).post((req, res) => {
    if (enhancedlog) logger.debug(JSON.stringify(req.headers));    
    if (!connId && phoenixConnection) {
       establishConnection();    
    }
    if(connId){
    conn.setAutoCommit(true, function(errCommit) {
          if (errCommit) {
			if (debug) logger.error(errCommit);
            errCode = 301;
            errMsg = "DB doesn't commit";
            res.status(errCode).json({ error: errMsg });
          } else {
            if (debug) logger.info("committed");            
            conn.createStatement(function(errCreateStatement, statement) {
              if (errCreateStatement) {
				if (debug) logger.error(errCreateStatement);
                res.status(errCode).json({ error: errMsg });
              } else {
                var markedDeviceList = '';
                if(req.body.markedDevice.length > 0){
                    for(i=0;i<req.body.markedDevice.length;i++){
                            markedDeviceList = markedDeviceList + "','" + req.body.markedDevice[i];
                            if(req.body.smartDevice=="Yes"){
                                redisSentinel.set('CLNT_SMART_MAC_'+req.body.markedDevice[i], req.body.markedDevice[i]);
                            }else{
                                redisSentinel.del('CLNT_SMART_MAC_'+req.body.markedDevice[i]);
                            }
                        }
                        statement.executeUpdate("UPSERT INTO client_smartdevice(CLIENT_MAC,SMART_DEVICE,LAST_UPDATED) SELECT CLIENT_MAC ,'"+req.body.smartDevice+"', CURRENT_Date() FROM client_smartdevice WHERE CLIENT_MAC IN ('"+markedDeviceList+"')",
                           function(errExecQuery, count) {
                          if (errExecQuery) {
							if (debug) logger.error(errExecQuery);
                            res.status(303).json({ error: "Update failed." });
                          } else {
                            if (debug) logger.info(null, count);
                            res.status(200).json({ success: "Updated Successfully" });
                          }
                        releaseConnection(connObjectLatest);
                        });
                    } else {
                    res.status(201).json({ success: "Select Device List to update" });
                  }
                }
            });    
            }
        });
    }else{
        errCode = 401;
        errMsg = "Server is not connected.";
        res.status(errCode).json({ error: errMsg });
    }    
})

