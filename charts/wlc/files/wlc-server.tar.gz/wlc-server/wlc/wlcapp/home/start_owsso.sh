#!/usr/bin/bash

function logmessage {
   echo "`date +'%Y-%m-%dT%H:%M:%S%Z%z'` $1 [WLC SSO Server App: `basename $0`] $2"
}

cd /home/wlcapp
[ -f /home/wlcapp/owsso.js ] && cp /home/wlcapp/owsso.js /opt/app-root/src/owsso.js
cd /opt/app-root/src

while [ true ]
do
        logmessage "info" "(re)Starting SSO Server"

        node owsso.js

        logmessage "error" "SSO Server exited"
    sleep 30
done

 
