#!/usr/bin/bash

function logmessage {
   echo "`date +'%Y-%m-%dT%H:%M:%S%Z%z'` $1 [WLC Backup Server App: `basename $0`] $2"
}

cd /home/wlcapp
[ -f /home/wlcapp/backupServer.js ] && cp /home/wlcapp/backupServer.js /opt/app-root/src/backupServer.js
cd /opt/app-root/src

while [ true ]
do
        logmessage "info" "(re)Starting Backup Server"

        node backupServer.js

        logmessage "error" "Backup Server exited"
    sleep 30
done

 
