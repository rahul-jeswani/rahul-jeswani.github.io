#!/usr/bin/bash

function logmessage {
   echo "`date +'%Y-%m-%dT%H:%M:%S%Z%z'` $1 [ WLC Restore : `basename $0`] $2"
}

set -a
. /home/wlcapp/dbobs.int.env
. /home/wlcapp/stolon.int.env

resfile=${WLC_BACKUP_DIR}/backup-to-restore
resdata=`cat ${resfile}`
if [ "$resdata" = "" ]
then
    logmessage "info" "No Restore specified"
    :
else
    logmessage "info" "Restore started using ${resdata} backup"
    bash /home/wlcapp/wlcbackup_restore.sh restore $resdata
    echo > ${resfile}
fi
