#!/usr/bin/bash

function logmessage {
   echo "`date +'%Y-%m-%dT%H:%M:%S%Z%z'` $1 [WLC App: `basename $0`] $2"
}

cd /home/wlcapp

sed -e 's/OPENNMS_DBHOST/'$OPENNMS_DBHOST'/' \
    -e 's/OPENNMS_DBUSER/'$OPENNMS_DBUSER'/' \
    -e 's/OPENNMS_DBPASS'/$OPENNMS_DBPASS'/' \
    -e 's/OPENNMS_DBPORT'/$OPENNMS_DBPORT'/' \
    -e 's/OPENNMS_DBNAME'/$OPENNMS_DBNAME'/' \
    < treeview.properties.tmpl > treeview.properties

while [ true ]
do
        logmessage "info" "(re)Starting Treeview"

        cd /home/wlcapp
        java -jar treeview.war

        logmessage "error" "Treeview exited"
    sleep 30
done

 
