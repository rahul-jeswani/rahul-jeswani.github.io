#!/usr/bin/bash

function logmessage {
   echo "`date +'%Y-%m-%dT%H:%M:%S%Z%z'` $1 [WLC Topology Server App: `basename $0`] $2"
}

cd /home/wlcapp
[ -f /home/wlcapp/topoServer.js ] && cp /home/wlcapp/topoServer.js /opt/app-root/src/topoServer.js
cd /opt/app-root/src

sequelize db:migrate --url postgres://${TOPOLOGY_DBUSER}:${TOPOLOGY_DBPASS}@${TOPOLOGY_DBHOST}:${TOPOLOGY_DBPORT}/${TOPOLOGY_DBNAME}

while [ true ]
do
        logmessage "info" "(re)Starting Topology Server"

        node topoServer.js

        logmessage "error" "Topology Server exited"
    sleep 30
done

 
