'use strict';
module.exports = {
  up: (queryInterface, Sequelize) => {

    return queryInterface.sequelize.transaction(t => {
      return Promise.all([
        queryInterface.addColumn('floor_image_mappings', 'floor_breadth', {
          type: Sequelize.DataTypes.STRING
        }, { transaction: t }),
        queryInterface.addColumn('floor_image_mappings', 'floor_length', {
          type: Sequelize.DataTypes.STRING,
        }, { transaction: t })
      ]);
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.sequelize.transaction(t => {
      return Promise.all([
        queryInterface.removeColumn('floor_image_mappings', 'floor_breadth', { transaction: t }),
        queryInterface.removeColumn('floor_image_mappings', 'floor_length', { transaction: t })
      ]);
    });
  }
};