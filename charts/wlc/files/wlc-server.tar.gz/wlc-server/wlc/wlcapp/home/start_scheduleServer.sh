#!/usr/bin/bash

function logmessage {
   echo "`date +'%Y-%m-%dT%H:%M:%S%Z%z'` $1 [WLC Schedule Server App: `basename $0`] $2"
}

cd /home/wlcapp
[ -f /home/wlcapp/scheduleServer.js ] && cp /home/wlcapp/scheduleServer.js /opt/app-root/src/scheduleServer.js
cd /opt/app-root/src

while [ true ]
do
        logmessage "info" "(re)Starting Schedule Server"

        node scheduleServer.js

        logmessage "error" "Schedule Server exited"
    sleep 30
done

 
