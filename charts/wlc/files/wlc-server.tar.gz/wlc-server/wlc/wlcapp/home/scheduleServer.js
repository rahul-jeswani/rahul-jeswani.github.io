const express = require('express');
const cors = require('cors');
const app = express();
const winston = require('winston');

require('winston-syslog').Syslog;

sslogformat = winston.format.printf(({ level, message, label, timestamp }) => {
  return `${timestamp} ${level} [${label}] ${message}`;
});


var logger = winston.createLogger({
  format: winston.format.combine(
    winston.format.label({ label: 'WLC Schedule Server App' }),
    winston.format.timestamp(),
    sslogformat
  ),
  levels: winston.config.syslog.levels,
  transports: [
    new winston.transports.Console(),
  ]
});


app.listen(process.env.WLCSCHEDULEAPPPORT, () => {
  logger.info('Server started!...') ;
})

app.use(cors(corsOptions));
app.set('json spaces', 40);

app.use(express.static('/opt/app-root/html/'));
var JDBC = require('jdbc');
var jinst = require('jdbc/lib/jinst');
var Poolap = require('jdbc/lib/pool');
const csv = require('fast-csv');
var fs = require('fs');
var errCode = null;
var errMsg = "";
var debug = true;
var enhancedlog = false;
var parserJson = require('xml2js');
var nodemailer = require('nodemailer');
var schedule = require('node-schedule');
const { Pool, Client } = require('pg');
const reportsDir = '/opt/app-root/src/reports';
var canSendMail = false;
if ( !process.env.MAIL_HOST == null && MAIL_PORT && !MAIL_SERVICE == null && !MAIL_AUTH_USERNAME == null && !MAIL_AUTH_PWD == null ) {
	canSendMail = true; 
}
fs.readdir(reportsDir + '/templates', (err, files) => {
  if (debug) logger.info(files);
});

const connectionString = 'postgres://'+process.env.REPORT_DBUSER+':'+process.env.REPORT_DBPASS+'@'+process.env.REPORT_DBHOST+':'+process.env.REPORT_DBPORT+'/'+process.env.REPORT_DBNAME+'';
const poolPsql = new Pool({
  connectionString: connectionString,
})
if (debug) { logger['level'] = 'debug'; };
if (debug) { enhancedlog = true; };

poolPsql.on('error', (err) => {
	logger.error('An Idle Client has experienced error',err.stack);
})
const prom_client = require('prom-client');
const collectDefaultMetrics = prom_client.collectDefaultMetrics;
collectDefaultMetrics({ timeout: 5000 });


const register = require('prom-client/lib/registry').globalRegistry;

app.get(process.env.WLCAPPMETRICSURI, (req, res) => {
	res.set('Content-Type', register.contentType);
	res.end(register.metrics());
});

if (!jinst.isJvmCreated()) {
  jinst.addOption('-Xrs')
  jinst.setupClasspath([  
    '/opt/app-root/src/appheonixplugin/hadoopjars/*',
    '/opt/app-root/src/appheonixplugin/hbasejars/*',    
    '/opt/app-root/src/appheonixplugin/',
    '/opt/app-root/src/appheonixplugin/phoenix-4.7.0.2.6.5.0-292-client.jar',
        '/opt/app-root/src/pglibs/postgresql-42.2.8.jar',
        '/opt/app-root/src/jasperlibs/jasperreports-5.6.0.jar',
        '/opt/app-root/src/jasperlibs/commons-beanutils-1.9.4.jar',
        '/opt/app-root/src/jasperlibs/jackson-databind-2.10.1.jar',
        '/opt/app-root/src/jasperlibs/jackson-core-2.10.1.jar',
        '/opt/app-root/src/jasperlibs/commons-collections4-4.0.jar',
        '/opt/app-root/src/jasperlibs/commons-collections-3.2.1.jar',
        '/opt/app-root/src/jasperlibs/commons-digester-2.1.jar',
        '/opt/app-root/src/jasperlibs/itext-2.1.7.jar'   
          ])
}

var corsOptions = {
  origin: '*',
  optionsSuccessStatus: 200 // some legacy browsers (IE11, various SmartTVs) choke on 204 
}

var jasperAp = require('node-jasper')({
        path: '/opt/app-root/src/jasperlibs/jasperreports-5.6.0',
        reports: {
             },
            drivers: {
            pg: {
                path: '/opt/app-root/src/appheonixplugin/phoenix-4.7.0.2.6.5.0-292-client.jar',
                class: 'org.apache.phoenix.jdbc.PhoenixDriver',
                type: 'phoenix'
            }
        },
        conns: {
            dbserverAp: {
        host: '',
                port: '',
                dbname: '',
                user: '',
                pass: '',
                jdbc:'jdbc:phoenix:' + process.env.PHOENIXSERVERS + '/hbase-unsecure',
                driver: 'pg'
            }
        },
        defaultConn: 'dbserverAp'
       
});

var jasperpsql = require('node-jasper')({
        path: '/opt/app-root/src/jasperlibs/jasperreports-5.6.0',
        reports:{
        },
        drivers: {
                pgsql: {
                    path: '/opt/app-root/src/pglibs/postgresql-42.2.8.jar',
                    class: 'org.postgresql.Driver',
                    type: 'postgresql'
                }
        },
        conns: {
                dbserverPsql: {
                    host: process.env.OPENNMS_DBHOST,
                    port: process.env.OPENNMS_DBPORT,
                    dbname: process.env.OPENNMS_DBNAME,
                    user: process.env.OPENNMS_DBUSER,
                    pass: process.env.OPENNMS_DBPASS,
                    driver: 'pgsql'
                }
        },
        defaultConn: 'dbserverPsql'
});

const bodyParser = require('body-parser')
app.use(bodyParser.json())

function catch_all_handler(err, req, res, next) {
  res.status(500);
  logger.error("catchall exception :" + err);    
}
app.use(catch_all_handler)

let scheduledJobs = [];

schedule.scheduleJob('*/10 * * * *', function(){
  try {
    if (enhancedlog) logger.info("scheduleJob");    
	let currentTime = (new Date()).toISOString();
    poolPsql.query("SELECT * from report_schedule where start_at < '"+currentTime+"' and end_to > '"+currentTime+"'", (errExecQuery, res) => {
        if(errExecQuery){
            if (debug) logger.error(errExecQuery)  
        }else{
            res['rows'].forEach(function (row) {
                if(!scheduledJobs.includes(row['id'])){
                    scheduledJobs.push(row['id']);
                    schedule.scheduleJob(row['cron_schedule_string'], function(){
						let reportFormat = (row['save_report_as']).split(',');
						reportFormat.forEach(function (format) {
								let testVar = {
									jrxml: reportsDir + '/templates/'+row['template_name']+'.jrxml'
								}
								var report = {
									report: testVar,
									data: {},
									dataset: []
									};
								fs.readFile( reportsDir + '/templates/'+row['template_name']+'.jrxml', function(errReadTemplate, data) {
									parserJson.parseString(data, function (errParse, result) {
									   try{
										result.jasperReport.property.forEach(function (data) {
											if(data.$['name'] == "com.jaspersoft.studio.data.defaultdataadapter"){
												let dataAdapterName = data.$['value'];
												if(dataAdapterName && dataAdapterName == 'phoenix'){
													try {
														var pdf = jasperAp.pdf(report);					
													}catch(errParse) {
														logger.error("catchall exception :" + errParse);    
													}
												}else if(dataAdapterName && dataAdapterName == 'psql') {
													if(format == 'csv'){
														var pdf = jasperpsql.export(
															report,
															'csv'
														);
													}else if(format == 'pdf'){
														var pdf = jasperpsql.pdf(report);
													}
												}
												if(pdf){
													let fileName = row['template_name']+'_'+row['id']+'_'+Date.now();
													if(format == 'csv'){
														fileType = 'csv';
													}else if(format == 'pdf'){
														fileType = 'pdf';
													}
													if(fileType){
													createFile(row,fileType,pdf,fileName, function (errCreateFile, fileCreted) {
														if(errCreateFile){
															logger.error(errCreateFile); 
														}else{
															if(enhancedlog) logger.info(fileCreted);
														}
													});																										
													}
												}
											}
										  });
									   }
									   catch (errReadTemplate) {
										 if (enhancedlog) logger.error(errReadTemplate);
										 logger.error(errReadTemplate);
									   }
									   
									});    
								 });
							});
					});
                }
            });
        }
    })
  }
  catch(err) {
    logger.error("catchall exception :" + err);    
  }
});

function createFile(row,fileType,pdf,fileName,callback){
	fs.writeFile(reportsDir + '/lib/reportTemplate.'+fileType, pdf, function (errWriteFile, data) {												                    
		let timeReportCreated = (new Date()).toISOString();
		fs.copyFile(reportsDir + '/lib/reportTemplate.'+fileType, reportsDir + '/generated/'+fileName+'.'+fileType, (errCopyFile) => {
			if (errCopyFile) {
				return callback(errCopyFile, null);
			}
			if(row['save_report']){
				poolPsql.query("insert into report_saved (report_name , created_at , schedule_id) values ('"+fileName+"', '"+timeReportCreated+"', '"+row['id']+"')", (errExecQuery, logResult) => {
				  if (enhancedlog) logger.error(errExecQuery);                                                  
				})  
			}
			let filePath = reportsDir + '/generated/'+fileName+'.'+fileType;
			if (canSendMail){
				mailToRecipient(filePath,row['id'],row['template_name']).catch(logger.error(error));
			}
			let createdFile = fileName+'.'+fileType+" created successfully";
			return callback(null, createdFile);
		});  
	});
}
function mailToRecipient(filePath,scheduleId,templateName) {		
    let transporter = nodemailer.createTransport({
        host: process.env.MAIL_HOST,
        port: process.env.MAIL_PORT,
        secure: process.env.MAIL_SECURE, 
        service: process.env.MAIL_SERVICE,
        auth: {
          user: process.env.MAIL_AUTH_USERNAME,
          pass: process.env.MAIL_AUTH_PWD
      }
    });
	poolPsql.query('SELECT * from report_tosend where report_id = '+scheduleId, (err, mailAddrResult) => {
		mailAddrResult['rows'].forEach(function (row) {
			let info = transporter.sendMail({
				from: process.env.MAIL_AUTH_USERNAME,
				to: row['email_id'],
				subject: "Jasper Report",
				text: "Report Generated from WLCAPP",
				html: "<b>"+templateName+"</b>",
				attachments: [
					{   
						filename: templateName+'.pdf',
						path: filePath,
						contentType: 'application/pdf'
					}
				]
			});
			if(enhancedlog) logger.info(info.messageId);
		})
	});	
}
