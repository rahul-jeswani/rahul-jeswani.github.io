#!/usr/bin/bash

function logmessage {
   echo "`date +'%Y-%m-%dT%H:%M:%S%Z%z'` $1 [ WLC Backup Restore : `basename $0`] $2"
}

function logstatus {
              echo [`date --utc +"%Y-%m-%d %H:%M:%S"`] : $1
}


cd /home/wlcapp
export PGPASSWORD=${POSTGRES_PASSWORD}
export APPNAME=${APPNAME:-wlc}
export BACKUP_VOLUMES="wlc_wlcapp.reports wlc_wlcapp.topology wlc_opennms.data wlc_opennms.etc"
export BACKUP_VOLPATH=${VOLPATH}
export RESTORE_VOLPATH=${VOLPATH}
##export RESTORE_VOLPATH=${VOLPATH}.res

set -a
. /home/wlcapp/dbobs.int.env
. /home/wlcapp/stolon.int.env


function do_dbvalidate {
    backupname=$1
    statusfile=$2
    dbbackupfile=${WLC_BACKUP_DIR}/${backupname}/${APPNAME}.data.${backupname}
    grep 'PostgreSQL database dump complete' ${dbbackupfile} > /dev/null 2>&1
    stat1=$?
    grep 'PostgreSQL database cluster dump complete' ${dbbackupfile} > /dev/null 2>&1
    stat2=$?
    if [ "$stat1" = "0" -a "$stat2" = "0" ]
    then
        return 0
    else
        return 1
    fi
}


function do_prune {
    find ${WLC_BACKUP_DIR} -type d -name "Periodic*" -mmin +`expr ${BACKUP_INTERVAL} \* ${BACKUP_COUNT} / 60`  -exec rm -rf {} \;
}

function do_volbackup {
    backupname=$1
    statusfile=$2
    retstatus=0
    logstatus "Volumes Backup Started for ${backupname}" >> ${statusfile}
    for volume in ${BACKUP_VOLUMES}
    do
        volbackupfile="${WLC_BACKUP_DIR}/${backupname}/${volume}-${backupname}.tgz"
        chmod 777 ${BACKUP_VOLPATH}
        chmod 777 ${BACKUP_VOLPATH}/${volume}
        tarout=`tar -C ${BACKUP_VOLPATH}/${volume} -zcf ${volbackupfile} .`
        if [ "$tarout" = "" ]
        then
            logmessage "info" "Backup completed for ${volume}"
            logstatus "Volume Backup Completed for ${volume}" >> ${statusfile}
        else
            logmessage "error" "Backup failed for ${volume} : $tarout"
            logstatus "Volume Backup Failed for ${volume}" >> ${statusfile}
            retstatus=1
        fi
    done
    logstatus "Volumes Backup Completed for ${backupname}" >> ${statusfile}
    return ${retstatus}
}

function do_dbbackup {
    backupname=$1
    statusfile=$2
    dbbackupfile=${WLC_BACKUP_DIR}/${backupname}/${APPNAME}.data.${backupname}
    logmessage "info" "Back up of db data to ${dbbackupfile} started"
    pg_dumpall -h ${POSTGRES_HOST} -U ${POSTGRES_USER} -p ${POSTGRES_PORT} >> ${dbbackupfile} 2>&1
    logmessage "info" "Back up of db data to ${dbbackupfile} completed"
}

function do_dbrestore {
    backupname=$1
    statusfile=$2
    retstatus=0
    dbbackupfile=${WLC_BACKUP_DIR}/${backupname}/${APPNAME}.data.${backupname}
    if [ "${dbbackupfile}" = "" ]
    then
        logmessage "error" "No valid backup file found for restore"
        retstatus=1
    else
        logmessage "info" "Restoring data from ${dbbackupfile}"
        psql -h ${POSTGRES_HOST} -U ${POSTGRES_USER} -p ${POSTGRES_PORT} < ${dbbackupfile}
        retstatus=$?
        logmessage "info" "Restoring data from ${dbbackupfile} completed"
    fi
    return ${retstatus}
}

function do_volvalidate {
    backupname=$1
    statusfile=$2
    retstatus=0
    logmessage "info" "Validation started for volume backup for ${backupname}"
    logstatus "Validation start for volume backup for ${backupname}" >> ${statusfile}
    for volume in ${BACKUP_VOLUMES}
    do
        volbackupfile="${WLC_BACKUP_DIR}/${backupname}/${volume}-${backupname}.tgz"
        if [ -f "${volbackupfile}" ]
        then
            tar -ztf ${volbackupfile} > /dev/null 2>&1
            volstatus=$?
            if [ "${volstatus}" = "0" ]
            then
                logmessage "info" "Volume ${volume} backup file validated successfully"
                :
            else
                logmessage "error" "Volume $volume file has corrupted"
                logstatus "backup file for ${volume} has corrupted" >> ${statusfile}
                retstatus=1
            fi
        else
            logmessage "error" "No backup file found for $volume"
            logstatus "No backup file found for ${volume}" >> ${statusfile}
            retstatus=1
        fi
    done
    logstatus "Validation completed for volume backup for ${backupname}" >> ${statusfile}
    return ${retstatus}
}

function do_volrestore {
    backupname=$1
    statusfile=$2
    retstatus=0
    logmessage "info" "Volumes Restore Started on ${backupname}"
    logstatus "Volumes Restore Started to ${backupname}" >> ${statusfile}
    for volume in ${BACKUP_VOLUMES}
    do
        volbackupfile="${WLC_BACKUP_DIR}/${backupname}/${volume}-${backupname}.tgz"
        if [ -f "${volbackupfile}" ]
        then
            logmessage "info" "Volume ${volume} successfully validated with source"
            volpathinfo=$(echo ${RESTORE_VOLPATH}/${volume})
            rm -rf $volpathinfo/*
            delvol=`find $volpathinfo/* 2>&1`
            echo ${delvol} | fgrep "No such file or directory" > /dev/null
            if [ "$?" = "0" ]
            then
                mkdir -p ${volpathinfo} > /dev/null 2>&1
                restore=`tar -C ${volpathinfo} -zxf ${volbackupfile} . 2>&1`
                if [ "$restore" = "" ]
                then
                    logmessage "info" "Volume $volume restore has completed"
                    logstatus "Volume Restore Completed for ${volume}" >> ${statusfile}
                else
                    logmessage "error" "Volume $volume restore has failed - $restore"
                    logstatus "Volume Restore Failed for ${volume} : ${restore}" >> ${statusfile}
                    retstatus=1
                fi
            else
                logmessage "error" "Could not clear volume ${volume}"
                logstatus "Volume Restore Failed for ${volume} : Could not clear volume" >> ${statusfile}
                retstatus=1
            fi
        else
            logmessage "error" "No backup file found for $volume"
            logstatus "Volume Restore Failed to ${volume} : No backup file found" >> ${statusfile}
            retstatus=1
        fi
    done
    logstatus "Volumes Restore Completed to ${backupname}" >> ${statusfile}
    return ${retstatus}
}

function backup_sub {
        backupname=$1
        mkdir -p ${WLC_BACKUP_DIR}/${backupname}
        statusfile=${WLC_BACKUP_DIR}/${backupname}/${backupname}.status

        do_volbackup ${backupname} ${statusfile}

        logstatus "Database Backup Started for ${backupname}" >> ${statusfile}
        do_dbbackup ${backupname} ${statusfile}
        do_dbvalidate ${backupname} ${statusfile}
        if [ "$?" = "0" ]
        then
            logmessage "info" "Database backup succeed for ${backupname}"
            logstatus "Database Backup Completed for ${backupname}" >> ${statusfile}
        else
            rm -f ${WLC_BACKUP_DIR}/${backupname}/${APPNAME}.data.${backupname}
            logmessage "error" "Database backup Failed for ${backupname}"
            logstatus "Database Backup Failed for ${backupname}" >> ${statusfile}
        fi
}


if [ \( "${BACKUP_INTERVAL}" = "" \) -o \(  "${BACKUP_COUNT}" = "" \) -o \( "${WLC_BACKUP_DIR}" = ""  \)  -o \( “${VOLPATH}” = “” \) ]
then
    logmessage "error" "Required backup environment variables BACKUP_INTERVAL, BACKUP_COUNT, WLC_BACKUP_DIR and VOLPATH are not set. Exiting"
    exit 1
fi

mkdir -p ${WLC_BACKUP_DIR}
chmod 777 ${WLC_BACKUP_DIR}

retstatus=0

case $1 in
    "Adhoc" ) :
        timestamp=`date --utc +\%Y\%m\%d_\%H\%M\%SZ`
        backupname="Adhoc-${timestamp}"
        backup_sub ${backupname}

        ;;

    "valrestore" ) :
        backupname=$2
        retstatus=0
        valrestorestatusfile=${WLC_BACKUP_DIR}/Validate-Restore.status
        resfile=${WLC_BACKUP_DIR}/backup-to-restore
        rm -rf ${valrestorestatusfile}
        echo > ${resfile}
        dbbkfile=${WLC_BACKUP_DIR}/${backupname}/${APPNAME}.data.${backupname}
        logmessage "info" "Validation started for database backup in ${backupname}"
        logstatus "Validation started for database backup in ${backupname}" >> ${valrestorestatusfile}
        do_dbvalidate ${backupname} ${valrestorestatusfile}
        if [ "$?" = "1" ]
        then
            logstatus "Validation Failed for database backup in ${backupname}, use different backup file to restore" >> ${valrestorestatusfile}
            logmessage "error" "Validation failed for database backup in ${backupname}"
        else
            logstatus "Validation Completed for database backup in ${backupname}" >> ${valrestorestatusfile}
            logmessage "info" "Validation completed for database backup in ${backupname}"
            do_volvalidate ${backupname} ${valrestorestatusfile}
            if [ "$?" = "1" ]
            then
                logstatus "Validation Failed for Volume backup in ${backupname}, use different backup file to restore" >> ${valrestorestatusfile}
                logmessage "error" "Validation failed for volume backup in ${backupname}"
                echo > ${resfile}
                retstatus=1

            else
                logmessage "info" "Validation completed for volume backup in ${backupname}"
                logstatus "WLC backup ${backupname} Ready to Restore" >> ${valrestorestatusfile}
                echo ${backupname} > ${resfile}
            fi
        fi
        ;;


    "restore" ) :
        backupname=$2
        retstatus=0
        restorestatusfile=${WLC_BACKUP_DIR}/${backupname}/Restore-${backupname}.status
        WLC_RESTORE_LOCK=${WLC_BACKUP_DIR}/wlc_restore.lock
        mkdir ${WLC_RESTORE_LOCK} > /dev/null 2>&1
        if [ "$?" = "0" ]
        then
            rm -rf ${restorestatusfile}
            logmessage "info" "Validation started for database backup in ${backupname}"
            do_dbvalidate ${backupname} ${restorestatusfile}
            if [ "$?" = "1" ]
            then
                logmessage "error" "Validation failed for database backup in ${backupname}"
                logstatus "Database backup validation failed" >> ${restorestatusfile}
                retstatus=1
            else
                logmessage "info" "Database backup validated successfully from ${backupname}"
                do_volvalidate ${backupname} ${restorestatusfile}
                if [ "$?" = "1" ]
                then
                    retstatus=1
                else
                    logstatus "Database Restore Started" >> ${restorestatusfile}
                    do_dbrestore ${backupname} ${restorestatusfile}
                    if [ "$?" = "0" ]
                    then
                        :
                    else
                        retstatus=1
                    fi
                    logstatus "Database Restore Completed" >> ${restorestatusfile}

                    do_volrestore ${backupname} ${restorestatusfile}
                    if [ "$?" = "0" ]
                    then
                        :
                    else
                        retstatus=1
                    fi
                fi
            fi
            rm -rf $WLC_RESTORE_LOCK
        else
            logmessage "info" "WLC Restore already in progress.Skipping this instance"
            retstatus=2
        fi

        ;;

    * ) :
        while :
        do
            timestamp=`date --utc +\%Y\%m\%d_\%H\%M\%SZ`
            backupname="Periodic-${timestamp}"
            backup_sub ${backupname}
            do_prune
            sleep ${BACKUP_INTERVAL}
        done
        ;;
esac
exit ${retstatus}
