#!/bin/bash

set -a
. /home/wlcapp/reportdb.int.env
. /home/wlcapp/topologydb.int.env
. /home/wlcapp/opennms.int.env
. /home/wlcapp/wlcapp.int.env
. /home/wlcapp/wlc.int.env

[ -f /home/wlcapp/branding/rakuten-logo.png ] && mkdir -p /opt/app-root/html/wlcapp/assets/images && cp /home/wlcapp/branding/rakuten-logo.png /opt/app-root/html/wlcapp/assets/images/rakuten-logo.png
#[ -f /home/wlcapp/conf/config.json ] && mkdir -p /opt/app-root/html/wlcapp/assets/config && cp /home/wlcapp/conf/config.json /opt/app-root/html/wlcapp/assets/config/config.json

[ -f /home/wlcapp/wlcapp.fe.tar ] && mkdir -p /opt/app-root/html && tar -C /opt/app-root/html -xf /home/wlcapp/wlcapp.fe.tar
[ -f /home/wlcapp/index.js ] && cp /home/wlcapp/index.js /opt/app-root/src/node_modules/node-jasper/index.js

if [ -f /home/wlcapp/hbase-site.xml.tmpl ]
then
    tgtfile=hbase-site.xml
    sed \
	-e 's/WLCAPP_HBASE_ZQ/'$WLCAPP_HBASE_ZQ'/' \
	< /home/wlcapp/$tgtfile.tmpl > /opt/app-root/src/appheonixplugin/$tgtfile
fi


cd /home/wlcapp
[ -f treeview.properties.tmpl ] && [ -f treeview.war ] && bash ./start_treeview.sh &
[ -d migrations ] && cp -r migrations /opt/app-root/src

cp -f -r reports/* /opt/app-root/src/reports

cp -f -r topology/apicons public/topology
mkdir -p public/topology/floorimages


export LD_LIBRARY_PATH=/usr/lib/jvm/jre-1.8.0-openjdk/lib/amd64/server
bash /home/wlcapp/start_topoServer.sh &
bash /home/wlcapp/start_reportServer.sh &
bash /home/wlcapp/start_smartDeviceServer.sh &
bash /home/wlcapp/start_scheduleServer.sh &
bash /home/wlcapp/start_thresholdServer.sh &
bash /home/wlcapp/start_backupServer.sh &
bash /home/wlcapp/start_owsso.sh &
bash /home/wlcapp/start_main.sh 
