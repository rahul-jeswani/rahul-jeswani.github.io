const express = require('express');
const cors = require('cors');
const app = express();
const winston = require('winston');

require('winston-syslog').Syslog;

sslogformat = winston.format.printf(({ level, message, label, timestamp }) => {
  return `${timestamp} ${level} [${label}] ${message}`;
});


var logger = winston.createLogger({
  format: winston.format.combine(
    winston.format.label({ label: 'WLC Report Server App' }),
    winston.format.timestamp(),
    sslogformat
  ),
  levels: winston.config.syslog.levels,
  transports: [
    new winston.transports.Console(),
  ]
});


app.listen(process.env.WLCREPORTAPPPORT, () => {
  logger.info('Server started!...') ;
})

app.use(cors(corsOptions));
app.set('json spaces', 40);

app.use(express.static('/opt/app-root/html/'));
var JDBC = require('jdbc');
var jinst = require('jdbc/lib/jinst');
var Poolap = require('jdbc/lib/pool');
var fs = require('fs');
var errCode = null;
var errMsg = "";
var debug = true;
var enhancedlog = false;
var parserJson = require('xml2js');
var nodemailer = require('nodemailer');
const { Pool, Client } = require('pg');
const reportsDir = '/opt/app-root/src/reports';
var canSendMail = false;
if ( !process.env.MAIL_HOST == null && MAIL_PORT && !MAIL_SERVICE == null && !MAIL_AUTH_USERNAME == null && !MAIL_AUTH_PWD == null ) {
	canSendMail = true; 
}
fs.readdir(reportsDir + '/templates', (err, files) => {
  if (debug) logger.info(files);
});

const connectionString = 'postgres://'+process.env.REPORT_DBUSER+':'+process.env.REPORT_DBPASS+'@'+process.env.REPORT_DBHOST+':'+process.env.REPORT_DBPORT+'/'+process.env.REPORT_DBNAME+'';
const poolPsql = new Pool({
  connectionString: connectionString,
})
if (debug) { logger['level'] = 'debug'; };
if (debug) { enhancedlog = true; };

poolPsql.on('error', (err) => {
	logger.error('An Idle Client has experienced error',err.stack);
})
const prom_client = require('prom-client');
const collectDefaultMetrics = prom_client.collectDefaultMetrics;
collectDefaultMetrics({ timeout: 5000 });


const register = require('prom-client/lib/registry').globalRegistry;

app.get(process.env.WLCAPPMETRICSURI, (req, res) => {
	res.set('Content-Type', register.contentType);
	res.end(register.metrics());
});

if (!jinst.isJvmCreated()) {
  jinst.addOption('-Xrs')
  jinst.setupClasspath([  
    '/opt/app-root/src/appheonixplugin/hadoopjars/*',
    '/opt/app-root/src/appheonixplugin/hbasejars/*',
	'/opt/app-root/src/appheonixplugin/hbase-site.xml',
    '/opt/app-root/src/appheonixplugin/',
    '/opt/app-root/src/appheonixplugin/phoenix-4.7.0.2.6.5.0-292-client.jar',
        '/opt/app-root/src/pglibs/postgresql-42.2.8.jar',
        '/opt/app-root/src/jasperlibs/jasperreports-5.6.0.jar',
        '/opt/app-root/src/jasperlibs/commons-beanutils-1.9.4.jar',
        '/opt/app-root/src/jasperlibs/jackson-databind-2.10.1.jar',
        '/opt/app-root/src/jasperlibs/jackson-core-2.10.1.jar',
        '/opt/app-root/src/jasperlibs/commons-collections4-4.0.jar',
        '/opt/app-root/src/jasperlibs/commons-collections-3.2.1.jar',
        '/opt/app-root/src/jasperlibs/commons-digester-2.1.jar',
        '/opt/app-root/src/jasperlibs/itext-2.1.7.jar'   
          ])
}

var corsOptions = {
  origin: '*',
  optionsSuccessStatus: 200 // some legacy browsers (IE11, various SmartTVs) choke on 204 
}

var jasperAp = require('node-jasper')({
        path: '/opt/app-root/src/jasperlibs/jasperreports-5.6.0',
        reports: {
             },
            drivers: {
            pg: {
                path: '/opt/app-root/src/appheonixplugin/phoenix-4.7.0.2.6.5.0-292-client.jar',
                class: 'org.apache.phoenix.jdbc.PhoenixDriver',
                type: 'phoenix'
            }
        },
        conns: {
            dbserverAp: {
        host: '',
                port: '',
                dbname: '',
                user: '',
                pass: '',
                jdbc:'jdbc:phoenix:' + process.env.PHOENIXSERVERS + ':/hbase-unsecure',
                driver: 'pg'
            }
        },
        defaultConn: 'dbserverAp'
       
});

var jasperpsql = require('node-jasper')({
        path: '/opt/app-root/src/jasperlibs/jasperreports-5.6.0',
        reports:{
        },
        drivers: {
                pgsql: {
                    path: '/opt/app-root/src/pglibs/postgresql-42.2.8.jar',
                    class: 'org.postgresql.Driver',
                    type: 'postgresql'
                }
        },
        conns: {
                dbserverPsql: {
                    host: process.env.OPENNMS_DBHOST,
                    port: process.env.OPENNMS_DBPORT,
                    dbname: process.env.OPENNMS_DBNAME,
                    user: process.env.OPENNMS_DBUSER,
                    pass: process.env.OPENNMS_DBPASS,
                    driver: 'pgsql'
                }
        },
        defaultConn: 'dbserverPsql'
});

const bodyParser = require('body-parser')
app.use(bodyParser.json())

function catch_all_handler(err, req, res, next) {
  res.status(500);
  logger.error("catchall exception :" + err);    
}
app.use(catch_all_handler)

app.route('/wlcapp/api/report/reportList', cors(corsOptions)).post((req, res) => {
    template = [];
	scheduleDetails = [];
	templateParamDetails = [];
	readTemplateCount = 0;
	fs.readdir(reportsDir + '/templates', (errReadDir, files) => {
		if(files){
			if (debug) logger.info(files);
			var ExecUpdateAsync = new Promise((resolve, reject) => {
			  files.forEach(function (readedFile) {
				  if(readedFile.split(".")[1]=="jrxml"){
					template.push(readedFile.split(".")[0]);
					fs.readFile( reportsDir + '/templates/'+readedFile.split(".")[0]+'.jrxml', function(errReadTemplate, data) {
						if(!errReadTemplate){
							parserJson.parseString(data, function (errParse, result) {
								if(!errParse){
									readTemplateCount++;
									let tempObj = {};
									tempObj['key'] = readedFile.split(".")[0];
									rowParamDetails = [];
									if(result.jasperReport.parameter){									
										result.jasperReport.parameter.forEach(function (data) {
											if(data.$['class'].split('.')[0] == 'java' && data.$['class'].split('.')[1] == 'lang'){
												let tempParamObj = {};
												tempParamObj['format'] = data.$['class'].split('.')[2];
												tempParamObj['name'] = data.$['name'];
												rowParamDetails.push(tempParamObj);
											}										
										});
									}
									tempObj['value'] = rowParamDetails;
									templateParamDetails.push(tempObj);
									if(template.length == readTemplateCount){
										resolve();
									}
								}else{
									if (debug) logger.error(errParse);
								}
								
							});
						}else{
							if (debug) logger.error(errReadTemplate);
						}
										
					});
				  }
			  });
			});
			ExecUpdateAsync.then(() => {
			  if(typeof template !== 'undefined' && template.length>0){
					let query = "SELECT * from report_schedule where template_name in ('"+template.join("','")+"');" ;
					getResult(query, function(errExecQuery,rows){
						sendBackResult = {};
						sendBackResult['templates'] = template;
						sendBackResult['parameterDetails'] = templateParamDetails;
						if(!errExecQuery){
							sendBackResult['scheduleDetails'] = rows;
							res.status(200).json({ reportList: sendBackResult });
						}else{
							if (debug) logger.error(errExecQuery);
							sendBackResult['scheduleDetails'] = '';
							res.status(200).json({ reportList: sendBackResult });
						}
					})			
				}else if(typeof template !== 'undefined' && template.length==0){
					res.status(200).json({ reportList: "None" });
				}else{
					res.status(320).json({ error: "Failed to fetch details from DB" });
				}
			});	
		}else{
			if (debug) logger.error(errReadDir);
			res.status(320).json({ error: errReadDir });
		}
      
    });
})

function executeQuery(query, callback) {    
	poolPsql.query(query, (err, reportResult) => {	
		if (err) {
			return callback(err, null);
		}
		return callback(null, reportResult);							
	});			
}

function getResult(query,callback) {
	scheduleDetails = [];
	executeQuery(query, function (err, reportResult) {
	 if (!err) {
		reportResult.rows.forEach(function(templateDetail){
			let tempObj = {};
			tempObj['key'] = templateDetail['template_name'];
			tempObj['value'] = templateDetail;
			scheduleDetails.push(tempObj);
		}) 
        callback(null,scheduleDetails);
     }
     else {
        callback(true,err);
     }
  });
}

app.route('/wlcapp/api/report/generateReport', cors(corsOptions)).post((req, res) => {		
	let data = {}
	if(req.body.startTimeObj.name && req.body.endTimeObj.name){
		var d = new Date(req.body.startTimeObj.value);
		var e = new Date(req.body.endTimeObj.value);
		let textd = d.toISOString().replace(/T/, ' ').replace(/\..+/, '');
		let texte = e.toISOString().replace(/T/, ' ').replace(/\..+/, '');
		data = {
		}
		data[req.body.startTimeObj.name] = textd;
		data[req.body.endTimeObj.name] = texte;
	}
	let testVar = {
		jrxml: reportsDir + '/templates/'+req.body.template+'.jrxml'
	}					
	let report = {
			report: testVar,
			data: data,
			dataset: []
			};					
	fs.readFile( reportsDir + '/templates/'+req.body.template+'.jrxml', function(errReadTemplate, data) {
		if(data){
			parserJson.parseString(data, function (errParse, result) {
				result.jasperReport.property.forEach(function (data) {    
					if(data.$['name'] == "com.jaspersoft.studio.data.defaultdataadapter"){
						let dataAdapterName = data.$['value'];
						if(dataAdapterName && dataAdapterName == 'phoenix'){
							try {
								if(req.body.format == 'csv'){
									   var pdf = jasperAp.export(
											report,
											'csv'
										);
									}else{
												var pdf = jasperAp.pdf(report);
										}
							}catch(errParse) {
								logger.error("catchall exception :" + errParse);    
							}
						}else if(dataAdapterName && dataAdapterName == 'psql') {
							if(req.body.format == 'csv'){
								var pdf = jasperpsql.export(
									report,
									'csv'
								);
							}else{
								var pdf = jasperpsql.pdf(report);
							}
						}
						if(pdf){
							let fileName = req.body.template+'_'+Date.now();
							if(req.body.format == 'csv'){
								fileType = 'csv';
								res.contentType("application/csv");											
							}else{
								fileType = 'pdf';
								res.contentType("application/pdf");
							}
								fs.writeFile(reportsDir + '/lib/reportTemplate.'+fileType, pdf, function (errWriteFile, data) {
									if(!errWriteFile){
										let timeReportCreated = (new Date()).toISOString();
										fs.copyFile(reportsDir + '/lib/reportTemplate.'+fileType, reportsDir + '/generated/'+fileName+'.'+fileType, (errCopyFile) => {
											if (errCopyFile) throw errCopyFile;
											let filePath = reportsDir + '/generated/'+fileName+'.'+fileType;
											var data =fs.readFileSync(filePath);
											res.set({
												'Content-Disposition': 'attachment; filename='+fileName+'.'+fileType,
											});
											res.send(data);
										});
									}else{
										if (debug) logger.error(errWriteFile);
										res.status(320).json({ error: errWriteFile });
									}																	
								});
						}else{
							errCode = 401;
							errMsg = "Server is not connected.";
							res.status(errCode).json({ error: errMsg });
						}
					}
				  });
			});
		}else{
			if (debug) logger.error(errReadTemplate);
			res.status(320).json({ error: errReadTemplate });
		}
		    
	 });                                            
})

app.route('/wlcapp/api/report/mailusers', cors(corsOptions)).post((req, res) => {
	let condition = "";
	if(req.body.scheduleValues){
		condition = "where report_id = "+req.body.scheduleValues;
	}	
	poolPsql.query("select * from report_tosend "+condition, (err, reportResult) => {
	  if(err){
            if (debug) logger.error(err);
			errMsg = "Update failed.";
			res.status(303).json({ error: errMsg });
        }else{
			res.status(200).json({ mailUsersList: reportResult.rows });	  
		}
	})
})

app.route('/wlcapp/api/report/updateSchedule', cors(corsOptions)).post((req, res) => {
	let scheduleValues = req.body.scheduleValues;
	let getMailAddr = scheduleValues.mailAddr.split(',');
	let timeCreated = (new Date()).toISOString();
	let query;
	if(scheduleValues.reportScheduleId == null){
		query = "insert into report_schedule (cron_schedule_string , template_name ,save_report,save_report_as,send_report, start_at, end_to, created_at) values ('"+scheduleValues.cronValue+"', '"+scheduleValues.templateName+"','"+scheduleValues.saveReport+"', '"+scheduleValues.formatType+"','"+scheduleValues.sendReport+"', '"+scheduleValues.startAt+"', '"+scheduleValues.endAt+"','"+timeCreated+"') returning id";
	}else{
		query = "update report_schedule set cron_schedule_string = '"+scheduleValues.cronValue+"',save_report = '"+scheduleValues.saveReport+"', save_report_as = '"+scheduleValues.formatType+"',send_report = '"+scheduleValues.sendReport+"', start_at = '"+scheduleValues.startAt+"', end_to = '"+scheduleValues.endAt+"', created_at = '"+timeCreated+"' where id = '"+scheduleValues.reportScheduleId+"'";
	}
	poolPsql.query(query, (errExecQuery, result) => {
	  if(errExecQuery){
            if (debug) logger.error(errExecQuery);
			errMsg = "Update failed.";
			res.status(303).json({ error: errMsg });
        }else{
			if(scheduleValues.reportScheduleId){
				reportScheduledId = scheduleValues.reportScheduleId;
			}else{
				reportScheduledId = result.rows[0].id;
			}
			getMailAddr.forEach(mailId => {
				let mailInsertQuery = "insert into report_tosend (email_id , report_id) select '"+mailId+"', "+reportScheduledId+" where NOT EXISTS ( select email_id, report_id from report_tosend WHERE email_id = '"+mailId+"' and report_id = "+reportScheduledId+" ) returning id;";
				poolPsql.query(mailInsertQuery, (errInsertQuery, resultAddMail) => {
					if(errInsertQuery){
						if (debug) logger.error(errInsertQuery);
					}
					if (debug) logger.info(resultAddMail);
				})
			})
			if(scheduleValues.reportScheduleId != null){
				let query = 'SELECT * from report_tosend where report_id = '+scheduleValues.reportScheduleId ;
				updateMail(query, getMailAddr, function(errUpdateMail,resultUpdateMail){
					if(!errUpdateMail){
						if (debug) logger.info(resultUpdateMail);
					}else{
						if (debug) logger.error(errUpdateMail);
					}
				})
			}
			message = "Updated Successfully";
			res.status(200).json({ success: message });
		}	
	})
})

function updateMail(query, mailAddr, callback){
	poolPsql.query(query, (errExecQuery, reportResult) => {	
		if(errExecQuery){
            return callback(errExecQuery, null);  
        }else{
			let removedAddr = [];	
			reportResult['rows'].forEach(function (row) {
				if(mailAddr.indexOf(row['email_id'])==-1){
					removedAddr.push(row['id']);
				}			
			})
			if(removedAddr.length >= 1){
				removeAddrQuery = "delete from report_tosend where id in ("+removedAddr+")"
				poolPsql.query(removeAddrQuery, (errDeleteQuery, resultremoveMail) => {
					if(errDeleteQuery){
						return callback(errDeleteQuery, null);
					}
					return callback(null, resultremoveMail);
				})
			}
		}		
	});
}