#!/usr/bin/bash

function logmessage {
   echo "`date +'%Y-%m-%dT%H:%M:%S%Z%z'` $1 [OpenNMS: `basename $0`] $2"
}


set -a
export HOME=/opt/opennms/
. /home/opennms/opennms.int.env
. /home/opennms/wlc.int.env
. /home/opennms/openwisp.int.env

tgtfile=opennms-datasources.xml
sed \
	-e 's/OPENNMS_DBNAME/'$OPENNMS_DBNAME'/' \
	-e 's/OPENNMS_DBUSER/'$OPENNMS_DBUSER'/' \
	-e 's/OPENNMS_DBPASS/'$OPENNMS_DBPASS'/' \
	-e 's/OPENNMS_DBPORT/'$OPENNMS_DBPORT'/' \
	-e 's/OPENNMS_DBHOST/'$OPENNMS_DBHOST'/' \
	-e 's/OPENNMS_DBADMINUSER/'$OPENNMS_DBADMINUSER'/' \
	-e 's/OPENNMS_DBADMINPASS/'$OPENNMS_DBADMINPASS'/' \
	< /opt/opennms-etc-overlay/$tgtfile.tmpl > /opt/opennms-etc-overlay/$tgtfile

tgtfile=opennms.properties
sed \
	-e 's/OPENNMS_GRAFANA_HOST/'$OPENNMS_GRAFANA_HOST'/' \
	-e 's/OPENNMS_GRAFANA_PORT/'$OPENNMS_GRAFANA_PORT'/' \
	< /opt/opennms-etc-overlay/$tgtfile.tmpl > /opt/opennms-etc-overlay/$tgtfile


tgtfile=syslog-aplocation-forwarder-localhost.xml
sed \
        -e 's/LOGSTASH_IP/'$LOGSTASH_IP'/' \
         < /opt/opennms-etc-overlay/$tgtfile.tmpl > /opt/opennms-etc-overlay/$tgtfile

tgtfile=snmptrap-northbounder-configuration.xml
sed \
	-e 's/OPENNMS_NB_TRAP_RECEIVER_HOST/'$OPENNMS_NB_TRAP_RECEIVER_HOST'/' \
	-e 's/OPENNMS_NB_TRAP_RECEIVER_PORT/'$OPENNMS_NB_TRAP_RECEIVER_PORT'/' \
	< /opt/opennms-etc-overlay/$tgtfile.tmpl > /opt/opennms-etc-overlay/$tgtfile

tgtfile=HCL-WLC-FSS-MIB.events.xml
sed \
	-e 's/WLC_UHN_NAME/'$WLC_UHN_NAME'/' \
	-e 's/WLC_UHN_NAME/'$WLC_UHN_NAME'/' \
	< /opt/opennms-etc-overlay/events/$tgtfile.tmpl > /opt/opennms-etc-overlay/events/$tgtfile


tgtfile=ldap.xml
sed \
	-e 's/LDAP_BASE_DN/'$LDAP_BASE_DN'/' \
	-e 's/LDAP_BIND_USER/'$LDAP_BIND_USER'/' \
	-e 's/LDAP_BIND_PASS/'$LDAP_BIND_PASS'/' \
	-e 's/LDAP_RMP_ADMIN_GROUP/'$LDAP_RMP_ADMIN_GROUP'/' \
	-e 's/LDAP_RMP_USER_GROUP/'$LDAP_RMP_USER_GROUP'/' \
	-e 's/LDAP_RMP_TEST_GROUP/'$LDAP_RMP_TEST_GROUP'/' \
	-e 's/LDAP_GROUP_SEARCH_ATTR/'$LDAP_GROUP_SEARCH_ATTR'/' \
	-e 's/LDAP_GROUPTYPE_ATTR/'$LDAP_GROUPTYPE_ATTR'/' \
	-e 's/LDAP_GROUP_SEARCH_DN/'$LDAP_GROUP_SEARCH_DN'/' \
	-e 's/LDAP_USER_SEARCH_DN/'$LDAP_USER_SEARCH_DN'/' \
	-e 's/LDAP_USERID_ATTR/'$LDAP_USERID_ATTR'/' \
	-e 's/LDAP_URI1/'$LDAP_HOSTP1'/' \
	-e 's/LDAP_URI2/'$LDAP_HOSTP2'/' \
	< /opt/opennms-jetty-webinf-overlay/spring-security.d/$tgtfile.tmpl > /opt/opennms-jetty-webinf-overlay/spring-security.d/$tgtfile


ln -s /usr/lib/jvm/java-11-openjdk-11.0.4.11-0.el7_6.x86_64/lib/jli/libjli.so /usr/lib64

logmessage info "Initializing ..."
cd /opt/opennms
bash /home/opennms/entrypoint.sh -i
logmessage info "Fixing permissions ..."
chown -R opennms:opennms /opt/opennms


if [ -f /home/opennms/branding/icon.png ]
then
        cp /home/opennms/branding/icon.png /opt/opennms/jetty-webapps/opennms/images/o-green-trans.png
        cp /home/opennms/branding/icon.png /opt/opennms/jetty-webapps/opennms/images
        cp /home/opennms/branding/icon.png /opt/opennms/jetty-webapps/opennms/favicon-32x32.png
        cp /home/opennms/branding/icon.png /opt/opennms/jetty-webapps/opennms/favicon-16x16.png
        cp /home/opennms/branding/icon.png /opt/opennms/jetty-webapps/opennms/favicon.ico
        cp /home/opennms/branding/icon2x.png /opt/opennms/jetty-webapps/opennms/apple-touch-icon.png
fi
if [ -f /home/opennms/branding/logo.svg ]
then
        cp /home/opennms/branding/logo.svg /opt/opennms/jetty-webapps/opennms/images/o-green-trans.svg
        cp /home/opennms/branding/logo.svg /opt/opennms/jetty-webapps/opennms/images
fi

logmessage info "Starting ..."
su opennms -p /home/opennms/create_reversion.sh &
su opennms -p /home/opennms/add_provisioning_requisition.sh &
su opennms -p /home/opennms/send_config_history.sh &
su opennms -p /home/opennms/file_ingest.sh &
su opennms -p /home/opennms/start_node_exporter.sh &
su opennms -p /home/opennms/sync_aps.sh &
#su opennms -p /home/opennms/import_location.sh &
su opennms -p /home/opennms/wlc_heartbeat_trap.sh &
su opennms -p /home/opennms/start_opennms_service.sh
