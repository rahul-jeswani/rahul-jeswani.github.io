#!/bin/bash
cd /home/opennms
#. /home/opennms/wlc.env

function logmessage {
   echo "`date +'%Y-%m-%dT%H:%M:%S%Z%z'` $1 [Analytics: `basename $0`] $2"
}
tstamp_file=/home/opennms/file_ingest_timestamp
>$tstamp_file

while :
do
sleep 60


while IFS= read -r line; do
#echo "Text read from file: $line"
previous=$line
done < "$tstamp_file"

#file=$2
file=${AP_LOCATION_MAP_PATH}/${AP_LOCATION_MAP_FILE}
threshold_file=${AP_LOCATION_MAP_PATH}/${AP_THRESHOLD_MAP_FILE}


#configPath=$3
configPath=/home/opennms/path.property

source $configPath

pwd=$password
username=$user
hostname=$host
destinationPath=$destination_path
jarPath=$jar_script_path

modified=$( stat -c "%Y" $file)
#echo 'Modified variable'$modified

if [ "$previous" == "$modified" ]; then
{
#    echo  'File is not Updated'
	:
}

else

{ 
	previous=$modified
#echo $previous
	echo "$modified" > "$tstamp_file" 
	logmessage "info" "File is updated. Start the data ingestion"

#		sshpass -p $pwd scp -r $file $username@$hostname:$destinationPath
#		sshpass -p $pwd scp -r $threshold_file $username@$hostname:$destinationPath
#		sshpass -p $pwd ssh $username@$hostname sh $jarPath

               sshpass -p $pwd scp -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -r $file $username@$hostname:$destinationPath/ap_location_map_$WLCID.csv
               sshpass -p $pwd scp -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -r $threshold_file $username@$hostname:$destinationPath/ap_threshold_$WLCID.csv
               sshpass -p $pwd ssh -o StrictHostKeyChecking=no $username@$hostname sh $jarPath


}
echo 'Script done'
#exit 1
fi
done
