#!/usr/bin/bash

function logmessage {
   echo "`date +'%Y-%m-%dT%H:%M:%S%Z%z'` $1 [OpenNMS: `basename $0`] $2"
}


logmessage info "Transfering startup artefacts ..."
cp -r /home/opennms.h/* /home/opennms
logmessage info "Fixing artefacts ..."
chown -R opennms:opennms /home/opennms/* /opt/opennms
chmod -R go-w /home/opennms/*
chmod -R -x /home/opennms/*.*
chmod -R +x /home/opennms/*.pl

logmessage info "Transfering control ..."
bash /home/opennms/start_opennms.sh
