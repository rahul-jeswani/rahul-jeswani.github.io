#!/bin/sh
cd /home/opennms
#. wlc.env

#onms_logmsg="`date +'%Y-%m-%dT%H:%M:%SZ%z'`:OpenNMS:`basename $0`"

function logmessage {
   echo "`date +'%Y-%m-%dT%H:%M:%S%Z%z'` $1 [WLC:OpenNMS: `basename $0`] $2"
}

if [[ "$(curl -s -o /dev/null -w ''%{http_code}''  http://localhost:8980/opennms)" != "302" ]]
then
	logmessage "info" "opennms not ready."
	exit 0
fi

PROVISION_LOCK=${PROVISION_LOCK:-/home/opennms/provision.lock}

PROVISION_PL='/home/opennms/provision.pl'
export HOME=/opt/opennms

Foreign_Src=$1
echo $Foreign_Src
if [ ! $Foreign_Src ];then
    Foreign_Src="RakutenAPs"
   logmessage "info" "Foreign Source not provided, assigning $Foreign_Src as default"
fi

#echo $Foreign_Src
$PROVISION_PL requisition add $Foreign_Src

logmessage "info"  "Requisition $Foreign_Src created successfully"
mkdir $PROVISION_LOCK 2>/dev/null
if [ $? -ne 0 ]
then
   logmessage "info" "Provision already in progress. Skipping this instance"
   exit 0
fi
logmessage "info" "WLC_DBNAME=$WLC_DBNAME"
export PGPASSWORD=$POSTGRES_PASSWORD
errorMsg="AP has registered with OpenWISP and is ready to receive configuration updates"
insert_query="insert into ap_location_map (macaddress, hostname, friendlyname, floor, building, site, latitude, \
		longitude, wlcfqdn , lastmodifieddate, status , category) values "
category="Production"
#errorMsg="AP_Registered"
{
  read
  while IFS="," read AP_MAC_ID AP_Hostname AP_Friendlyname AP_Floor AP_Building AP_Site AP_Lat AP_Long AP_WLC AP_Misc;
  do
     if [ "$AP_MAC_ID" != "" ]
     then
        mac=`echo $AP_MAC_ID | sed -e 's/[:\-]//g' -e 's/\(.*\)/\L\1/'`
        # echo "mac = $mac"
	MAC_Upper=${AP_MAC_ID^^}
        logmessage "info" "$mac  $AP_Hostname $AP_Friendlyname $AP_Floor $AP_Building $AP_Site $AP_WLC $AP_Misc"
        # Add node to default Requisition
        $PROVISION_PL node add $Foreign_Src $mac $AP_Friendlyname

        # update node with building
        $PROVISION_PL node set $Foreign_Src $mac building $AP_Building

        #Add floor asset to Node
        $PROVISION_PL asset add $Foreign_Src $mac floor $AP_Floor

         #Add Region asset to Node
        $PROVISION_PL asset add $Foreign_Src $mac region $AP_Site

         #Add Latitude asset to Node
        $PROVISION_PL asset add $Foreign_Src $mac latitude $AP_Lat

         #Add Longitude asset to Node
        $PROVISION_PL asset add $Foreign_Src $mac longitude $AP_Long
		
	#Add category to node
	$PROVISION_PL category add $Foreign_Src $mac $category

        logmessage "info" "Node  $AP_Friendlyname Added and updated successfully"
		currtime_in_millis="$(date +%s000)"
		status=""
		
		psql -X -A -U ${POSTGRES_USER} -d ${WLC_DBNAME} -h ${POSTGRES_HOST} -p ${POSTGRES_PORT} -t -c \
		"$insert_query ('$MAC_Upper', '$AP_Hostname', '$AP_Friendlyname', '$AP_Floor', '$AP_Building', '$AP_Site', '$AP_Lat', '$AP_Long', '$AP_WLC', '$currtime_in_millis', '$status', '$category')"
		
		 logmessage "info" "Node  $AP_Friendlyname Added to $WLC_DBNAME successfully"
				
    fi
  done
} < ${AP_LOCATION_MAP_PATH}/${AP_LOCATION_MAP_FILE}


$PROVISION_PL requisition import $Foreign_Src

logmessage "info" 'provision.pl executed successfully'


/opt/opennms/bin/send-event.pl  uei.opennms.plugins/assettopology/regenerate localhost -p 'providerId wlc.net' 
logmessage "info" 'send-event.pl executed'
rm -rf $PROVISION_LOCK

exit 0
