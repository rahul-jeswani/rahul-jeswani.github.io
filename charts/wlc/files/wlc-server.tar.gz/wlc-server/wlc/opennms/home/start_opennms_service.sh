#!/bin/bash
cd /opt/opennms

function logmessage {
   echo "`date +'%Y-%m-%dT%H:%M:%S%Z%z'` $1 [WLC:OpenNMS: `basename $0`] $2"
}

while :
do
   logmessage "info" "(re)Starting OpenNMS Service"
   bash /home/opennms/entrypoint.sh -o
   logmessage "error" "OpenNMS Service exited"
   sleep 30
done
