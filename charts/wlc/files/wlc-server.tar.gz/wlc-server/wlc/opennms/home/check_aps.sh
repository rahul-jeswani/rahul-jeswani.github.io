#!/bin/bash

function usage {

cat <<EOF

Script for checking the status of registration of APs at OpenWISP and discovery of the APs at OpenNMS

Usage: $0 <APs count> <Net1> <Net2> <Net3> <Net4>

  Takes as inputs the count of APs and the starting IP address info for the APs
  Takes the Net1, Net2, Net3 and Net4 values as the last few arguments.
  The starting IPv4 address is taken as <Net1>.<Net2>.<Net3>.<Net4> and
  the starting IPv6 address is taken as 2001:db8:0:3:<Net1>:<Net2>:<Net3>:<Net4>

Usage: $0 -f <csv-file>
  With the "-f" option, takes a csv-file. The file format is same as that of the ap_location_map.csv file.
  The script checks for all the APs in the CSV file.


EOF

}

cd /home/opennms
#. postgres.int.env
. openwisp.int.env
. opennms.int.env


function check_ap {
    n1=$1
    n2=$2
    n3=$3
    n4=$4
    ipv4addr="$n1.$n2.$n3.$n4"
    ipv6addr="2001:db8:0:3:$n1:$n2:$n3:$n4"

#    ipaddr=$ipv6addr
    ipaddr=$ipv4addr

    export PGPASSWORD=${POSTGRES_PASSWORD}
    owisp_ipaddr=""
#    owisp_ipaddr="$ipaddr"
    owisp_ipaddr=`psql -X -A -U ${POSTGRES_USER} -d ${OPENWISP_DBNAME} -h ${POSTGRES_HOST} -p ${POSTGRES_PORT} -t -c "select mac_address, management_ip from config_device where management_ip='"$ipaddr"'" 2>/dev/null`

    if [ "$owisp_ipaddr" != "" ]
    then
        export PGPASSWORD=$OPENNMS_DBPASS
        onms_ipaddr=""
        onms_ipaddr=`psql -X -A -U ${OPENNMS_DBUSER} -d ${OPENNMS_DBNAME} -h ${OPENNMS_DBHOST} -p ${OPENNMS_DBPORT} -t -c "select ipinterface.ipaddr from ipinterface where ipaddr='"$ipaddr"'" 2>/dev/null`
        if [ "$onms_ipaddr" = "" ]
        then
            echo "$ipaddr - Registered in OpenWISP but not in OpenNMS"
            return 2
        else
            return 1
        fi
    else
        return 0
    fi
    
}



function check_aps_inrange {
    ninstances=${1:-4}
    net1=${2:-172}
    net2=${3:-19}
    net3=${4:-0}
    net4=${5:-21}

    icount=0
    regcnt=0
    while [ $net3 -le 255 ]
    do
        while [ $net4 -le 255 ]
        do
            check_ap $net1 $net2 $net3 $net4
            retval=$?
            if [ $retval = 1 ]
            then
                regcnt=`expr $regcnt + 1`
            fi
            net4=`expr $net4 + 1`
            icount=`expr $icount + 1`
            if [ $icount -gt $ninstances ]
            then
                break;
            fi
        done
        net4=0
        net3=`expr $net3 + 1`
        if [ $icount -ge $ninstances ]
        then
            break;
        fi
    done
    return $regcnt
}

function check_apbymac {
    mac=$1
    normal_mac=`echo $mac | sed -e 's/[:\-]/:/g' -e 's/\(.*\)/\U\1/'`
    export PGPASSWORD=${POSTGRES_PASSWORD}
    owisp_ipaddr=""
    owisp_ipaddr=`psql -X -A -U ${POSTGRES_USER} -d ${OPENWISP_DBNAME} -h ${POSTGRES_HOST} -p ${POSTGRES_PORT} -t -c "select management_ip from config_device where mac_address='"$normal_mac"'" 2>/dev/null`

    if [ "$owisp_ipaddr" != "" ]
    then
        onms_ipaddr=""
        onms_ipaddr=`psql -X -A -U ${POSTGRES_USER} -d ${OPENNMS_DBNAME} -h ${POSTGRES_HOST} -p ${POSTGRES_PORT} -t -c "select ipinterface.ipaddr from ipinterface where ipaddr='"$owisp_ipaddr"'" 2>/dev/null`
        if [ "$onms_ipaddr" = "" ]
        then
            echo "AP with MAC $normal_mac - Registered in OpenWISP with IP $owisp_ipaddr but not in OpenNMS"
            return 2
        else
            echo "AP with MAC $normal_mac - Registered in OpenWISP and OpenNMS with IP $owisp_ipaddr"
            return 1
        fi
    else
        echo "AP with MAC $normal_mac - Not registered in OpenWISP"
        return 0
    fi
}


function check_aps_incsv {
  regcnt=0
  read
  while IFS="," read AP_MAC_ID AP_Hostname AP_Friendlyname AP_Floor AP_Building AP_Site AP_WLC AP_Misc;
  do
     if [ "$AP_MAC_ID" != "" ]
     then
         if [ "$retrycnt" = "0" ]
         then
             no_of_aps=`expr $no_of_aps + 1`
         fi
         check_apbymac $AP_MAC_ID
         if [ "$?" = "1" ]
         then
             regcnt=`expr $regcnt + 1`
         fi
     fi
  done
}

maxretry=3
retrycnt=0
inp_csv=""

if [ "$1" = "-h"  -o "$1" = "" ]
then
    usage
    exit
fi


if [ "$1" = "-f" ]
then
   inp_csv=$2
   if [ ! -f "$inp_csv" ]
   then
       usage
       exit
   else
       no_of_aps=0
   fi
else

   no_of_aps=${1:-4}
   inp_net1=${2:-172}
   inp_net2=${3:-20}
   inp_net3=${4:-0}
   inp_net4=${5:-1}
fi

while [ $retrycnt -lt $maxretry ]
do
    if [ "$inp_csv" = "" ]
    then
        check_aps_inrange $no_of_aps $inp_net1 $inp_net2 $inp_net3 $inp_net4
        regcnt=$?
    else
        check_aps_incsv < $inp_csv
    fi
    if [ $regcnt -lt $no_of_aps ]
    then
        echo "Fewer number of APs($regcnt) seen than expected($no_of_aps)"
        echo "Will retry `expr $maxretry - $retrycnt - 1` more times"
        sleep 60
    else
        echo "Number of APs seen same as expected ($no_of_aps)"
        break
    fi
    retrycnt=`expr $retrycnt + 1`
done



exit 0
