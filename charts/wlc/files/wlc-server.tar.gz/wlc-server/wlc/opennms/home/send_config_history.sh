#!/usr/bin/bash
function logmessage {
   echo "`date +'%Y-%m-%dT%H:%M:%S%Z%z'` $1 [OpenNMS: `basename $0`] $2"
}

cd /home/opennms/
mkdir -p analytic-files/processed_files
while :
do
  sleep 60
  cd /home/opennms/analytic-files
  rm -f processed_files/*
  java -jar ../wlc-config.jar
  count=$(ls -d *.json 2>/dev/null | wc -l)
  if [ $count -ne 0 ]
  then
    logmessage "info" "$count files are being sent to kafka"
    configfiles=`ls *.json` 
    for eachfile in $configfiles
    do
      cat $eachfile | /home/kafka_2.11-0.10.1.1/bin/kafka-console-producer.sh --broker-list $KAFKA_HOST --topic events
      current_time=$(date "+%Y.%m.%d-%H.%M.%S")
      mv $eachfile processed_files/${eachfile}_$current_time        
    done
  fi
  cd /home/opennms
done
