#!/bin/bash
cd /home/opennms

function logmessage {
   echo "`date +'%Y-%m-%dT%H:%M:%S%Z%z'` $1 [WLC:OpenNMS: `basename $0`] $2"
}

SYNC_APS_LOCK=/home/opennms/sync_aps.lock
rm -rf SYNC_APS_LOCK

while :
do
sleep 60

if [[ "$(curl -s -o /dev/null -w ''%{http_code}''  http://localhost:8980/opennms)" != "302" ]]
then
    logmessage "info" "opennms not ready."
    continue
fi

PROVISION_PL=/home/opennms/provision.pl

mkdir $SYNC_APS_LOCK 2>/dev/null
if [ $? -ne 0 ]
then
   logmessage "info" "Sync already in progress. Skipping this instance"
   continue
fi

errorMsg="AP has registered with OpenWISP and is ready to receive configuration updates"
export PGPASSWORD=$POSTGRES_PASSWORD

res_arr=$(psql -X -A -U ${POSTGRES_USER} -d ${OPENWISP_DBNAME} -h ${POSTGRES_HOST} -p ${POSTGRES_PORT} -t -c "select dev.mac_address, dev.management_ip from config_device dev where dev.management_ip not in (select device_ip from device_ip_data)" 2>/dev/null)
ow_logmsg="`date +'%Y-%m-%dT%H:%M:%SZ%z'`:OpenWISP:`basename $0`"
#echo "res_arr = $res_arr"

if [ -z "$res_arr" ]
then
    :
#    echo "All AP are sync with OpenNMS, No action required"
else
    logmessage "info"  "Registered AP need to be sync with OpenNMS"
    # logmessage "info" "WLC_DBNAME=$WLC_DBNAME"
    # logmessage "info"  "WLC_REQUISITION=$WLC_REQUISITION"

    for i in $res_arr
    do

        ap_mac_id=$(echo $i | awk -F '|' '{print $1}')
        ip_addr=$(echo $i | awk -F '|' '{print $2}')

        mac=`echo $ap_mac_id | sed -e 's/[:\-]//g' -e 's/\(.*\)/\L\1/'`
        logmessage "info" "processing following MAC = $mac and ipaddress = $ip_addr"

        foreign_src=$(psql -X -A -U ${POSTGRES_USER} -d ${OPENNMS_DBNAME} -h ${POSTGRES_HOST} -p ${POSTGRES_PORT} -t -c " select foreignsource from node where foreignid='$mac'")

        # echo "foreign_src : $foreign_src"
        if [ -z "$foreign_src" ]
        then
                logmessage "error" "Unable to retrieve Requisition for the registered MAC=$mac . continue ..."
                continue
        fi
                if [ -z "$ip_addr" ]
        then
                        logmessage "error" "IP Address empty for the registered MAC=$mac . continue ..."
                continue
        fi

                neName=$(psql -X -A -U ${POSTGRES_USER} -d ${WLC_DBNAME} -h ${POSTGRES_HOST} -p ${POSTGRES_PORT} -t -c " select hostname from ap_location_map where macaddress='$ap_mac_id'")

                logmessage "info" "neName=$neName getting synced with opennms..."
                # Sending apRegistered notification trap
                /opt/opennms/bin/send-event.pl -p "trapName AP_Registered" -p "trapId $trapId"  -p "trapType 4" -p "trapSeverity 4" -p "clearTrap 2" -p "neName $neName" -p "mac $ap_mac_id" -p "errorMsg $errorMsg" -p "probableCause NA"   -p "alarmCode WLC_CONT_1"  -p "clearAlarmId 0"  uei.opennms.org/alarms/hcl-wlc-fss/apRegistered

        $PROVISION_PL interface add $foreign_src $mac $ip_addr
        $PROVISION_PL interface set $foreign_src $mac $ip_addr snmp-primary P
        $PROVISION_PL service add $foreign_src $mac $ip_addr SNMP
        $PROVISION_PL service add $foreign_src $mac $ip_addr ICMP
   #    $PROVISION_PL service add $foreign_src $mac $ip_addr HTTP
   #    $PROVISION_PL service add $foreign_src $mac $ip_addr HTTPS
   #    $PROVISION_PL service add $foreign_src $mac $ip_addr SSH
    #   $PROVISION_PL category add $foreign_src $mac Production

                $PROVISION_PL requisition import $foreign_src
        logmessage "info" "Event sent for IP $ip_addr node  $mac"

                # Marking sync
                psql -X -A -U ${POSTGRES_USER} -d ${OPENWISP_DBNAME} -h ${POSTGRES_HOST} -p ${POSTGRES_PORT} -t -c "insert into device_ip_data (device_ip) values ('$ip_addr')" 2>/dev/null

                currtime_in_millis="$(date +%s000)"

                psql -X -A -U ${WLC_DBUSER} -d ${WLC_DBNAME} -h ${WLC_DBHOST} -p ${WLC_DBPORT} -t -c "update ap_location_map set lastmodifieddate='$currtime_in_millis',status='up' where macaddress='$ap_mac_id'" 2>/dev/null

                logmessage "info" "Status updated for MAC=$ap_mac_id"

                /opt/opennms/bin/send-event.pl -p "trapName AP_Discovered" -p "trapId $trapId"  -p "trapType 4" -p "trapSeverity 4" -p "clearTrap 2" -p "neName $neName" -p "mac $ap_mac_id" -p "errorMsg $errorMsg" -p "probableCause NA"   -p "alarmCode WLC_CONT_2"  -p "clearAlarmId 0"  uei.opennms.org/alarms/hcl-wlc-fss/apDiscovered

        if [ $? -eq 0 ]
        then
                logmessage "info" "device_ip_data updated for MAC=$ap_mac_id"
        else
                logmessage "error" "device_ip_data update failed for MAC=$ap_mac_id"
        fi
                logmessage "info" "sync completed for MAC=$ap_mac_id"
    done

fi

rm -rf $SYNC_APS_LOCK

done

exit 0


