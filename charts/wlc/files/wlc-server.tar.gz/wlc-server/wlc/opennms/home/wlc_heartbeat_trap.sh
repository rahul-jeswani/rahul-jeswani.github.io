#!/bin/bash
cd /home/opennms

function logmessage {
   echo "`date +'%Y-%m-%dT%H:%M:%S%Z%z'` $1 [WLC:OpenNMS: `basename $0`] $2"
}

while :
do
   sleep ${WLC_HEARTBEAT_INTERVAL}
   /opt/opennms/bin/send-event.pl  -p "neName ${WLC_UHN_NAME}" uei.opennms.org/alarms/hcl-wlc-fss/wlcHeartBeat
#   logmessage "info" "WLC HeartBeat Trap sent successfully"
done
