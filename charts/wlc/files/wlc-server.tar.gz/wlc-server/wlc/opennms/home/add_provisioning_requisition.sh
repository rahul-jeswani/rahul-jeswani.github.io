#!/bin/bash

function logmessage {
   echo "`date +'%Y-%m-%dT%H:%M:%S%Z%z'` $1 [WLC:OpenNMS: `basename $0`] $2"
}

while :
do
sleep 60

	if [[ "$(curl -s -o /dev/null -w ''%{http_code}''  http://localhost:8980/opennms)" != "302" ]]
	then
		logmessage "info" "opennms not ready."
		continue
	fi

	REQUISITION=$WLC_REQUISITION

	test=$(/home/opennms/provision.pl requisition list $REQUISITION)

	if [ -z "$test" ]
		then
			echo "Requisition $REQUISITION does not exist, needs to be created"
			/home/opennms/provision.pl requisition add $REQUISITION
			/home/opennms/provision.pl requisition import $REQUISITION

			logmessage "info" "Requisition $REQUISITION created successfully"
	   else
			logmessage "info" "Requisition $REQUISITION  already created "
	fi

done