#!/usr/bin/bash

function logmessage {
   echo "`date +'%Y-%m-%dT%H:%M:%S%Z%z'` $1 [OpenNMS: `basename $0`] $2"
}

while [ true ]
do
        logmessage "info" "(re)Starting OpenNMS Node exporter"

    	/home/node_exporter/node_exporter --web.listen-address=${OPENNMS_METRICS_LISTEN_ADDRESS} --web.telemetry-path=${OPENNMS_METRICS_TELEMETRY_PATH} --web.disable-exporter-metrics

        logmessage "error" "OpenNMS Node exporter exited"

    	sleep 30
done

