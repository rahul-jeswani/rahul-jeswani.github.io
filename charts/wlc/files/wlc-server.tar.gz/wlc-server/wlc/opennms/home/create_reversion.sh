#!/usr/bin/bash
psql postgresql://$OPENWISP_DBUSER:$OPENWISP_DBPASS@$POSTGRES_HOST/$OPENWISP_DBNAME << EOF
drop table IF EXISTS reversion_version_process_history;

CREATE TABLE reversion_version_process_history (
    id integer NOT NULL
);


ALTER TABLE reversion_version_process_history ADD CONSTRAINT pk
  PRIMARY KEY (id);

ALTER TABLE reversion_version_process_history OWNER TO postgres;

INSERT INTO reversion_version_process_history (id) VALUES (0);

EOF
