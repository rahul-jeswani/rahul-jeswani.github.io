#!/bin/bash
cd /home/opennms
#. /home/opennms/wlc.env

function logmessage {
   echo "`date +'%Y-%m-%dT%H:%M:%S%Z%z'` $1 [WLC:OpenNMS: `basename $0`] $2"
}
tstamp_file=/home/opennms/provision_timestamp
PROVISION_LOCK=/home/opennms/provision.lock
export PROVISION_LOCK

>$tstamp_file
rm -rf ${PROVISION_LOCK}

while :
do
sleep 60

if [[ "$(curl -s -o /dev/null -w ''%{http_code}''  http://localhost:8980/opennms)" != "302" ]]
then
    logmessage "info" "opennms not ready."
else

    
    while IFS= read -r line; do
    #echo "Text read from file: $line"
    previous=$line
    done < "$tstamp_file"
    
    file=${AP_LOCATION_MAP_PATH}/${AP_LOCATION_MAP_FILE}
    
    #previous=1535634548
    #echo 'in preious variable'$previous
    
    modified=$( stat -c "%Y" $file)
    #echo 'Modified variable'$modified
    
    if [ "$previous" != "$modified" ]
    then
            previous=$modified
            #echo $previous
    	echo "$modified" > "$tstamp_file" 
        	logmessage "info" "Importing modified file $file"
            bash /home/opennms/provision_aps.sh
        	logmessage "info" "Importing done"
    fi
fi

done
