#!/bin/bash

nodeId=$1
uei=$2
severity=$3
nodeLabel=$4

function logmessage {
   echo "`date +'%Y-%m-%dT%H:%M:%S%Z%z'` $1 [WLC:OpenNMS: `basename $0`] $2"
}

logmessage "info" "ap_status_event_generator.sh called with nodeId=$nodeId , uei=$uei, severity=$severity , nodeLabel=$nodeLabel"

logmessage "info" "WLC_DBNAME=$WLC_DBNAME"
export PGPASSWORD=$POSTGRES_PASSWORD
ap_arr=$(psql -X -A -U ${POSTGRES_USER} -d ${WLC_DBNAME} -h ${POSTGRES_HOST} -p ${POSTGRES_PORT} -t -c "select macaddress, hostname, friendlyname from ap_location_map" 2>/dev/null)
logmessage "info" "$ap_arr"
if [ -z "$ap_arr" ]
then
	logmessage "info" "No Access point available in wlc_db"
else    
    for i in $ap_arr
    do
		AP_MAC_ID=$(echo $i | awk -F '|' '{print $1}')
		AP_Hostname=$(echo $i | awk -F '|' '{print $2}')
    	AP_Friendlyname=$(echo $i | awk -F '|' '{print $3}') 
		if [ "$AP_Friendlyname" == "$nodeLabel" ]
		then
			newUei="uei.opennms.org/alarms/hcl-wlc-fss/apUp"
			apStatus="up"
			if [ "$uei" == "uei.opennms.org/nodes/nodeDown" ]
			then
				// AP Down
				newUei="uei.opennms.org/alarms/hcl-wlc-fss/apDown"
				apStatus="down"					
			fi
	
			/opt/opennms/bin/send-event.pl -p  "neName $AP_Hostname" -p "mac $AP_MAC_ID"  "$newUei"
			
			logmessage "info" "Event - $newUei generated for neName=$AP_Hostname"
			
			currtime_in_millis="$(date +%s000)"          
			psql -X -A -U ${POSTGRES_USER} -d ${WLC_DBNAME} -h ${POSTGRES_HOST} -p ${POSTGRES_PORT} -t -c "update ap_location_map set lastmodifieddate='$currtime_in_millis',status='$apStatus' where macaddress='$AP_MAC_ID'"
			logmessage "info" "Status of AP with MAC=$ap_mac_id updated to $apStatus"
		fi
	done
fi
