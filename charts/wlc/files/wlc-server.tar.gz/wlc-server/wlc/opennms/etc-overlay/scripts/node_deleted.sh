
#echo Node $1 was deleted >> /opt/opennms/etc/scripts/Deleted_Nodes

/opt/opennms/bin/send-event.pl  uei.opennms.plugins/assettopology/regenerate localhost -p 'providerId wlc.net'
