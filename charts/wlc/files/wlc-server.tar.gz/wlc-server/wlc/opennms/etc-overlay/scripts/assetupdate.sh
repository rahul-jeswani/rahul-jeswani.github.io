#!/bin/sh

nodeid=$1
interface=$2

onms_logmsg="`date +'%Y-%m-%dT%H:%M:%SZ%z'`:OpenNMS:`basename $0`:${nodeid} "

# Query db to get mac id for this node

export PGPASSWORD=${OPENWISP_DBPASS}
macaddress=$(psql -U $OPENWISP_DBUSER -h $POSTGRES_HOST -d $OPENWISP_DBNAME -t -c "select config_device.mac_address from config_device join config_config on config_config.device_id=config_device.id where config_config.last_ip='$interface';" | tail -2 | head -1 | tr -d "[:blank:]")


if [ "${macaddress}" == "" ]
then
	echo "${onms_logmsg} : Asset update failed, mac address not available"
	exit 0
fi

macaddress=`echo ${macaddress} | sed -e 's/[:\-]//g' -e 's/\(.*\)/\L\1/'`

OLDIFS=${IFS}
IFS=","
while read AP_MAC_ID AP_Hostname AP_Friendlyname AP_Floor AP_Building AP_Site AP_WLC AP_Misc;
do
        mac=`echo $AP_MAC_ID | sed -e 's/[:\-]//g' -e 's/\(.*\)/\L\1/'`
        if [ "${mac}" == "${macaddress}" ];then


            export PGPASSWORD=${OPENNMS_DBPASS}
            update=$( psql -U ${OPENNMS_DBUSER} -h ${POSTGRES_HOST} -d ${OPENNMS_DBNAME} -c "update assets set building = '${AP_Building}',floor='${AP_Floor}',region='${AP_Site}' where nodeid=${nodeid};")
	    if [ $? -eq 0 ]
	    then
		echo "${onms_logmsg} : ${AP_Friendlyname} : Asset update successful"
	    else
		echo "${onms_logmsg} : ${AP_Friendlyname} : Asset update failed"
	    fi
            break
        fi
done < ${AP_LOCATION_MAP_PATH}/${AP_LOCATION_MAP_FILE}
IFS=${OLDIFS}

/opt/opennms/bin/send-event.pl  uei.opennms.plugins/assettopology/regenerate localhost -p 'providerId wlc.net'
