#!/bin/bash

nodeid=$1
uei=$2
severity=$3

export PGPASSWORD=${OPENNMS_DBPASS}
mac_address=$(psql -U $OPENNMS_DBUSER -h $POSTGRES_HOST -d $OPENNMS_DBNAME -t -c "select foreignid from node where nodeid='$nodeid';" | sed -e 's/\([0-9A-Fa-f]\{2\}\)/\1:/g' -e 's/\(.*\):$/\1/')
eventid=$(psql -U $OPENNMS_DBUSER -h $POSTGRES_HOST -d $OPENNMS_DBNAME -t -c "select eventid from events where nodeid='$nodeid' and eventuei='$uei' order by eventtime desc limit 1;")
eventtime=$(psql -U $OPENNMS_DBUSER -h $POSTGRES_HOST -d $OPENNMS_DBNAME -t -c "select eventtime from events where nodeid='$nodeid' and eventuei='$uei' order by eventtime desc limit 1;")
eventdescr=$(psql -U $OPENNMS_DBUSER -h $POSTGRES_HOST -d $OPENNMS_DBNAME -t -c "select eventdescr from events where nodeid='$nodeid' and eventuei='$uei' order by eventtime desc limit 1;" | tr "\n" " " | tr -s ' ' | sed -E 's/\+/ /g' )
eventlogmsg=$(psql -U $OPENNMS_DBUSER -h $POSTGRES_HOST -d $OPENNMS_DBNAME -t -c "select eventlogmsg from events where nodeid='$nodeid' and eventuei='$uei' order by eventtime desc limit 1;" | tr "\n" " " | tr -s ' ' | sed -E 's/\+/ /g') 

export PGPASSWORD=${OPENWISP_DBPASS}
mac_address=$(echo "$mac_address" | xargs)
mac_upper=${mac_address^^}
ap_version=$(psql -U $OPENWISP_DBUSER -h $POSTGRES_HOST -d $OPENWISP_DBNAME -t -c "select os from config_device where mac_address='$mac_upper'")

echo "AP_STATUS - Time : ${eventtime},  ForeignID : ${mac_address}, EventID : ${eventid}, NodeID : ${nodeid}, UEI : ${uei}, EventDescriptions : ${eventdescr}, Severity : ${severity}, AP_SW_Version : ${ap_version}, LogMessage : ${eventlogmsg}" | /home/kafka_2.11-0.10.1.1/bin/kafka-console-producer.sh --broker-list ${KAFKA_HOST} --topic events

#cat kafka.log | /home/kafka_2.11-0.10.1.1/bin/kafka-console-producer.sh --broker-list $KAFKA_HOST --topic events
