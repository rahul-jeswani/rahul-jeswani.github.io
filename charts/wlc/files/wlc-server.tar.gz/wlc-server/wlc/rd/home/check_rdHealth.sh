#!/bin/bash

cd /home/rd

set -a 
. wlc.int.env

HEALTH=$(python dbConnectionTest.py)

if [ "$HEALTH" = "0" ] 
then 
#     echo "success "
     exit 0
else 
#     echo "fail "
     exit 1
fi

