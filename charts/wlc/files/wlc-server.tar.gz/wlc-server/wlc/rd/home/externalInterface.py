#!/home/anaconda3/bin/python
# -*- coding: utf-8 -*-
"""
Created on Thu Mar 12 07:55:03 2020

@author: anaconda


17 jul : changed timeouts for scan info (now 2 min) and for history taggging (now 6 hrs)
24 jul : changed json message parsing, now using json library; handled the condition of empty SSID
10 aug : - corrected the read position for hostname (now it has position 4, before it had 5... this is due to the deletion
         of operative status from the postgres table)
         - inserted error handling to counteract for missing data in the json structure of roguescantable_json

"""
from dataSet import *
from datetime import datetime
import psycopg2
import sys
import json
import os

DB_SERVER_HOST = os.environ['WLC_DBHOST']
DB_SERVER_PORT = os.environ['WLC_DBPORT']
DB_SERVER_USER = os.environ['WLC_DBUSER']
DB_SERVER_PASSWORD = os.environ['WLC_DBPASS']
DB_SERVER_DATABASE = os.environ['WLC_DBNAME']
'''
DB_SERVER_HOST = '172.19.0.2'
DB_SERVER_PORT = '5432'
DB_SERVER_USER = 'postgres'
DB_SERVER_PASSWORD = 'postgres'
DB_SERVER_DATABASE = 'wlcdb'
'''

CONNECTION_ATTEMPTS = 5


# ------------------------------------------------

def GetNEDataFromInventory(ap):
    # returns none as second parameter if there is no match for the supplied mac address among registered network elements
    # if a match is found it returns the matching ap object 
    
   
    bssid=ap.BSSID
    ssid=ap.SSID

    retries = CONNECTION_ATTEMPTS
    while retries > 0:
        try:
            conn = psycopg2.connect(user=DB_SERVER_USER, password=DB_SERVER_PASSWORD, host=DB_SERVER_HOST, port=DB_SERVER_PORT, database=DB_SERVER_DATABASE)
            break
        except:
            retries-=1
            if retries == 0:
                print ("+ Unable to connect to Database")
                return(False, None)             
  
    cur = conn.cursor()
#   remember that execute needs a tuple as second parameter, then always add a "," if only one variable is queried
#   verify the bssid and ssid are registered
    retries = CONNECTION_ATTEMPTS
    while retries > 0:
        try:
            cur.execute("""SELECT * from roguedetector_registeredaps WHERE bssid = %s ;""", (bssid,))  
            break
        except:
            retries-=1
            if retries == 0:
                print ("+ Unable to fetch from Database")
                return(False, None)             
   
    rows = cur.fetchall()
    
    if len(rows)==0: # the supplied BSSID has not a corresponding registered AP
        cur.close()
        conn.close()
        return (True,None)
    else:
        sensorMAC = rows[0][0]
        ap.hostName = rows[0][4]
 
    retries = CONNECTION_ATTEMPTS
    while retries > 0:
        try:
            cur.execute("""SELECT * from ap_location_map WHERE MACADDRESS= %s;""", (str(sensorMAC),))  
            break
        except:
            retries-=1
            if retries == 0:
                print ("+ Unable to fetch from Database")
                return(False, None)             
    
    rows = cur.fetchall()
    
    if len(rows)==0:
        cur.close()
        conn.close()
        return (True,None)          
    else:        
        if ((rows[0][10]).lower()=='up'):
            ap.operational = True
        else:
            ap.operational = False
        cur.close()
        conn.close()
        return (True,sensorMAC)
    

# ------------------------------------------------
        
def GetDetectedAPandSensorInfoFromLogStash():
 
##################   get scan data inserted from logstash   ################
    retries = CONNECTION_ATTEMPTS
    while retries > 0:
        try:
            conn = psycopg2.connect(user=DB_SERVER_USER, password= DB_SERVER_PASSWORD, host=DB_SERVER_HOST, port=DB_SERVER_PORT, database=DB_SERVER_DATABASE)
            break
        except:
            retries-=1
            if retries == 0:
                print ("/ Unable to connect to Database")
                return(False, None, None)             
           
   
    cur = conn.cursor()
#   remember that execute needs a tuple as second parameter, then always add a "," if only one variable is queried
    retries = CONNECTION_ATTEMPTS
    while retries > 0:
        try:
            cur.execute("""SELECT * FROM roguedetector_roguescantable_json;""",)  
            break
        except:
            retries-=1
            if retries == 0:
                print ("/ Unable to fetch from Database")
                return(False, None, None)             

    rows = cur.fetchall()

    retries = CONNECTION_ATTEMPTS
    while retries > 0:
        try:
            cur.execute("""DELETE FROM roguedetector_roguescantable_json WHERE timetick < now() - interval '2 minutes';""",)  
            conn.commit()
            cur.close()
            conn.close()
            break
        except:
            retries-=1
            if retries == 0: # there is no need to return if the data cannot be removed
                print ("/ Unable to remove rogue scan data from Database")
 

    #create the list of sensors
    sensorsMACList = []  ### this list contains the mac addresses of the sensors received in json data
    if len(rows)==0:
        return (True,None,None) # read succeded but no data are present
    else:
        dataReceivedFromSensorList = []
        for ap in rows: 
            jsondata = ap[3]
            sensorMAC = jsondata.get('ap_mac_address')  
            readBSSID = jsondata.get('bssid')
            readSSID  = jsondata.get('essid')
            readRSSI = jsondata.get('signal_level')
            readBitRates = jsondata.get('bit_rates')

            # clean up read data
            if (readSSID == None):
                readSSID = "NO SSID"
            if (readRSSI == None):
                readRSSI = ""
            readRSSI = readRSSI.split(' ')[0]
            if (readBitRates == None):
                readBitRates = ""


            if sensorMAC:
                if sensorMAC not in sensorsMACList: 
                    sensorsMACList.append(sensorMAC)
                dataReceivedFromSensorList.append(DetectedAP (sensorMAC,readBSSID,readSSID,"None",readRSSI,readBitRates))
            else:
                continue
               
############### for each sensor of the sensorsList, 
############### find the sensor location and autoClassification flag
    retries = CONNECTION_ATTEMPTS
    while retries > 0:
        try:
            conn = psycopg2.connect(user=DB_SERVER_USER, password= DB_SERVER_PASSWORD, host=DB_SERVER_HOST, port=DB_SERVER_PORT, database=DB_SERVER_DATABASE)            
            break
        except:
            retries-=1
            if retries == 0:
                print ("- Unable to connect to Database")
                return(False,None,None)             
            
    sensorObjectsList = []
    
    # build the list of sensor objects fetching coordinates and the autoClassify flag of the sensor
    for sensorMAC in sensorsMACList:
        cur = conn.cursor()
        retries = CONNECTION_ATTEMPTS
        while retries > 0:
            try:
                cur.execute("""SELECT * from ap_location_map WHERE MACADDRESS= %s;""", (str(sensorMAC),))  
                break
            except:
                retries-=1
                if retries == 0:
                    print ("- Unable to fetch from Database")
                    return(False,None,None)             

        row = cur.fetchall()
        if len(row)==0:
            continue
        else:
            sensorObjectsList.append(SensorAP(sensorMAC,'', '', row[0][12],row[0][10]))
        
        # get the list of SSIDS that the sensor shall control: so far it uses a table where each registeredMAC
        # has its own list. In future the list will be common for all sensors and fetched directly from a dedicated
        # table column
        # remember that execute needs a tuple as second parameter, then always add a "," if only one variable is queried
        retries = CONNECTION_ATTEMPTS
        while retries > 0:
            try:
                cur.execute("""SELECT * from roguedetector_checkedSSIDs; """,)  
                break
            except:
                retries-=1
                if retries == 0:
                    print ("- Unable to fetch from Database")
                    return(False,None,None)             

        #let's store in rows the list of admitted ssid
        rows = cur.fetchall()
        
        admittedSSIDsList=[]
        for ssid in rows:
            admittedSSIDsList.append(ssid[0])
            
        # coordinates so far are fake
        sensorObjectsList[-1].location = ''
        
        # add the list of admited SSIDs for the sensor
        sensorObjectsList[-1].checkedSSIDList = admittedSSIDsList
    
    cur.close()
    conn.close()
    
    return (True,sensorObjectsList,dataReceivedFromSensorList)    


# ------------------------------------------------
        
def SaveResults(sensorList):

    retries = CONNECTION_ATTEMPTS
    while retries > 0:
        try:
            conn = psycopg2.connect(user=DB_SERVER_USER, password= DB_SERVER_PASSWORD, host=DB_SERVER_HOST, port=DB_SERVER_PORT, database=DB_SERVER_DATABASE)            
            break
        except:
            retries-=1
            if retries == 0:
                print ("\ Unable to connect to Database")
                return(False)             
    
    cur = conn.cursor()
    
    retries = CONNECTION_ATTEMPTS
    while retries > 0:
        try:
            cur.execute("""DELETE FROM roguedetector_classifiedAPs WHERE timetick < now() - interval '30 days';""")
            cur.execute("""UPDATE roguedetector_classifiedAPs SET history='*' WHERE timetick < now() - interval '6 hours';""")
            conn.commit()
            break
        except:
            retries-=1
            if retries == 0: # no need to return, will try later
                print ("\ Unable to update Database, no hurry I will try later")

    for sensor in sensorList:  
       
        for ap in sensor.classifiedAPList:
 
            loggerString = 'logger {\\"sensor MAC\\": \\"' + str(ap.detectingSensor) + '\\", \\"SSID\\": \\"'  + str(ap.SSID) + '\\", \\"BSSID\\": \\"' + str(ap.BSSID)  + '\\", \\"hostName\\" : \\"'  + str(ap.hostName) + '\\", \\"classification\\" : \\"' + str(ap.classification.value) + '\\", \\"RSSI\\" : \\"' + str(ap.RSSI) + '\\"}'

            # find if the current reported ap is already present in the database
            retries = CONNECTION_ATTEMPTS
            while retries > 0:
                try:
                    cur.execute("""SELECT * from roguedetector_classifiedAPs WHERE bssid= %s AND sensorMAC= %s AND ssid= %s;""", (str(ap.BSSID),str(ap.detectingSensor),str(ap.SSID)))  
                    break
                except:
                    retries-=1
                    if retries == 0:
                        print ("- Unable to fetch from Database")
                        return(False)             

            rows = cur.fetchall()
    
            if len(rows)==0: # case of a detected AP which is not yet in the db
                retries = CONNECTION_ATTEMPTS
                while retries > 0:
                    try:
                        cur.execute("""INSERT INTO roguedetector_classifiedAPs (sensorMAC, bssid, ssid, classification, history, rssi) VALUES (%s,%s,%s,%s,' ',%s);""",
                                (ap.detectingSensor,ap.BSSID, ap.SSID, ap.classification.value, ap.RSSI))
                        conn.commit()
                        os.system(loggerString)
                        break
                    except:
                        retries-=1
                        if retries == 0:
                            print ("- Unable to write to Database")
                            return(False)             
            else: # case of a detected AP which is already in the AP -> only update its info
                retries = CONNECTION_ATTEMPTS
                while retries > 0:
                    try:
                        cur.execute("""UPDATE roguedetector_classifiedAPs SET timetick = now(), history= ' ', classification=%s, ssid=%s WHERE sensorMAC=%s and bssid=%s AND ssid= %s;""",
                                    (ap.classification.value, ap.SSID, ap.detectingSensor,ap.BSSID,ap.SSID))
                        conn.commit()
                        break
                    except:
                        retries-=1
                        if retries == 0:
                            print ("- Unable to write to Database")
                            return(False)             
                #if classification has changed then send info to syslog
                if (rows[0][3] != ap.classification.value):
                    os.system(loggerString)
      
    cur.close()
    conn.close()
    
    return(True)



def GetNEMACAddressList(registeredNetworkElementsMACs):
##################   get mac addresses of registered NEs ################
    retries = CONNECTION_ATTEMPTS
    while retries > 0:
        try:
            conn = psycopg2.connect(user=DB_SERVER_USER, password= DB_SERVER_PASSWORD, host=DB_SERVER_HOST, port=DB_SERVER_PORT, database=DB_SERVER_DATABASE)
            break
        except:
            retries-=1
            if retries == 0:
                print ("/ Unable to connect to Database")
                return(False)             
 
    cur = conn.cursor()
#   remember that execute needs a tuple as second parameter, then always add a "," if only one variable is queried
    retries = CONNECTION_ATTEMPTS
    while retries > 0:
        try:
            cur.execute("""SELECT MACADDRESS FROM ap_location_map;""",)  
            break
        except:
            retries-=1
            if retries == 0:
                print ("/ Unable to fetch from Database")
                return(False)             
 
    rows = cur.fetchall()
    cur.close()
    conn.close()
    
    if (rows == None):
        # ---> no commissioned APs
        return(False)
    else:
        for row in rows:
            registeredNetworkElementsMACs.append(row[0])
        return(True)
    
    

def GetCorrespondingAPs(registeredNetworkElementsMACs):
    
    retries = CONNECTION_ATTEMPTS
    while retries > 0:
        try:
            conn = psycopg2.connect(user=DB_SERVER_USER, password= DB_SERVER_PASSWORD, host=DB_SERVER_HOST, port=DB_SERVER_PORT, database=DB_SERVER_DATABASE)
            break
        except:
            retries-=1
            if retries == 0:
                print ("/ Unable to connect to Database")
                return(False)             
 
    cur = conn.cursor()
    
#   clean and rebuild the table containing the association inventory<->aps   
    retries = CONNECTION_ATTEMPTS
    while retries > 0:
        try:
            cur.execute("""DELETE FROM roguedetector_registeredaps WHERE timetick < now() - interval '6 hours';""")
            conn.commit()
            break
        except:
            retries-=1
            if retries == 0: # no need to return, will try later
                print ("/ Unable to update Database")
                
# fetch the list of ssids to be checked which have already been registered                
    retries = CONNECTION_ATTEMPTS
    while retries > 0:
        try:
            cur.execute("""SELECT * from roguedetector_checkedSSIDs; """,)  
            break
        except:
            retries-=1
            if retries == 0:
                print ("- Unable to fetch from Database")
                return(False,None,None)             

    #let's store in rows the list of admitted ssid
    rows = cur.fetchall()
    
    checkedSSIDsList=[]
    for ssid in rows:
        checkedSSIDsList.append(ssid[0])

#   remember that execute needs a tuple as second parameter, then always add a "," if only one variable is queried
#   SELECT distinct configuration_report ->> 'bssid' FROM roguedetector_configurationaptable_json where configuration_report ->> 'ap_mac_address' = '00:00:00:00:00:03';
    for macAddress in registeredNetworkElementsMACs: # for each NE's MAC
        retries = CONNECTION_ATTEMPTS
        while retries > 0:
            try:
                cur.execute("""select distinct configuration_report ->> 'bssid' as bssid, configuration_report ->>'essid' as essid, configuration_report ->>'ap_hostname' as hostName FROM roguedetector_configurationaptable_json where configuration_report ->> 'ap_mac_address' = %s;""", (str(macAddress),))   
                break
            except:
                retries-=1
                if retries == 0:
                    print ("/ Unable to update Database")
                    return(False)
 
        ids = cur.fetchall()
        
        for oneId in ids:               # for each AP of each NE
            #insert in ap table
            retries = CONNECTION_ATTEMPTS
            while retries > 0:
                try:
                    cur.execute("""SELECT * from roguedetector_registeredaps WHERE mac= %s AND bssid = %s ;""", (str(macAddress),str(oneId[0])))  
                    break
                except:
                    retries-=1
                    if retries == 0:
                        print ("/ Unable to fetch from Database")
                        return(False)

            row = cur.fetchall()
            if len(row)==0: # couple mac/bssid is not present -> insert it
                retries = CONNECTION_ATTEMPTS
                while retries > 0:
                    try:
                        cur.execute("""INSERT INTO roguedetector_registeredaps(mac, bssid, ssid, hostname) VALUES (%s,%s,%s,%s);""", (str(macAddress),str(oneId[0]),str(oneId[1]),str(oneId[2])))
                        conn.commit()
                        break
                    except:
                        retries-=1
                        if retries == 0:
                            print ("/ Unable to write to Database")
                            return(False)
            else: # couple mac/bssid already exists -> update the entry
                retries = CONNECTION_ATTEMPTS
                while retries > 0:
                    try:
                        cur.execute("""UPDATE roguedetector_registeredaps SET ssid=%s, hostname=%s WHERE mac=%s AND bssid=%s""", (str(oneId[1]),str(oneId[2]),str(macAddress),str(oneId[0])))
                        conn.commit()
                        break
                    except:
                        retries-=1
                        if retries == 0:
                            print ("/ Unable to update Database")
                            return(False)
                        
            # check if the SSID of this AP is already present in checkedSSIDs table; 
            # if it is then update its timetick otherwise add it
            # remove ssids that have not been refreshed for 6 hours
            currentSSID = str(oneId[1])
            retries = CONNECTION_ATTEMPTS
            while retries > 0:
                try:
                    cur.execute("""SELECT * from roguedetector_checkedSSIDs WHERE ssid= %s ;""", (currentSSID,))  
                    break
                except:
                    retries-=1
                    if retries == 0:
                        print ("/ Unable to fetch from Database")
                        return(False)

            row = cur.fetchall()
            if len(row)==0: # ssid is not present -> insert it
                while retries > 0:
                    try:
                        cur.execute("""INSERT INTO roguedetector_checkedSSIDs (ssid) VALUES (%s);""", (currentSSID,))  
                        cur.execute("""DELETE FROM roguedetector_checkedSSIDs WHERE timetick < now() - interval '5 minutes';""")
                        break
                    except:
                        retries-=1
                        if retries == 0:
                            print ("/ Unable to write on Database")
                            return(False)
            else:       
                while retries > 0:
                    try:
                        cur.execute("""UPDATE roguedetector_checkedSSIDs SET timetick = now() WHERE ssid=%s;""",(currentSSID,))
                        cur.execute("""DELETE FROM roguedetector_checkedSSIDs WHERE timetick < now() - interval '5 minutes';""")
                        break
                    except:
                        retries-=1
                        if retries == 0:
                            print ("/ Unable to update Database")
                            return(False)
            
    conn.commit()
    cur.close()
    conn.close()
    return(True)
   
