#!/usr/bin/bash

function logmessage {
   echo "`date +'%Y-%m-%dT%H:%M:%S%Z%z'` $1 [WLC Rogue Detector Server App: `basename $0`] $2"
}

cd /home/rd
while [ true ]
do
        logmessage "info" "(re)Starting rsyslog daemon"

        rsyslogd -n -f /home/rd/rsyslog.conf -i /home/rd/rsyslog.pid

        logmessage "error" "rsyslog daemon exited"
    sleep 30
done

 
