# -*- coding: utf-8 -*-
"""
Created on Thu Mar  5 11:28:26 2020

@author: marco.tozzi
"""
from enum import Enum
import json
import logging


class ClassificationType(Enum):
    UNKNOWN = 'UNKNOWN'
    ROGUE = 'ROGUE'
    FRIENDLY = 'FRIENDLY'
    EXTERNAL = 'EXTERNAL'
    SUSPECT = 'SUSPECT'

class AP:
      def __init__(self, BSSID, SSID, hostName =""):
       self.BSSID = BSSID
       self.SSID = SSID
       self.hostName = hostName
        
class NetworkElement:
      def __init__(self, MAC, location, opStatus):       
        self.MAC = MAC
        self.location = location
        self.opStatus = opStatus
      
        
class InventoryRegisteredAP(AP):
      def __init__(self, BSSID, SSID, MAC, location, encryption, opStatus):
        AP.__init__(self,BSSID, SSID)  
        NetworkElement.__init__(self,MAC, location, opStatus)
        self.encryption = encryption
        
class SensorAP(NetworkElement):
      def __init__(self, MAC, location, checkedSSIDList, autoClassification, opStatus):
        NetworkElement.__init__(self,MAC, location, opStatus)   
        self.checkedSSIDList = checkedSSIDList
        self.autoClassification = autoClassification
        self.classifiedAPList = [] # this list contains the output of the classification procedure
        
class DetectedAP(AP):
      def __init__(self, sensorMAC, BSSID, SSID, Encryption, RSSI, rates, cypher=None, authentication=None, operational='False', hostName=""):
        AP.__init__(self,BSSID, SSID, hostName)  
        self.Encryption = Encryption
        self.detectingSensor = sensorMAC
        self.RSSI = RSSI
        self.rates = rates
        self.cypher = cypher
        self.authentication = authentication
        self.operational = operational

        
class ClassifiedAP(AP):
      def __init__(self, detectingSensor, BSSID, SSID, Classification, RSSI, hostName=""):
        AP.__init__(self,BSSID, SSID, hostName)  
        self.detectingSensor = detectingSensor.MAC
        self.classification = Classification
        self.RSSI = RSSI



# ------------------------------------------------