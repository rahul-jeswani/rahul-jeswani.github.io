#!/bin/bash
for (( ; ; ))
do
   python scheduledRogueDetector.py 2>&1 
done
