#!/bin/bash

set -a
. /home/rd/wlc.int.env
. /home/rd/rd.int.env

tgtfile=rsyslog.conf
sed \
	-e 's/LOGSTASH_IP/'$LOGSTASH_IP'/' \
	< /home/rd/$tgtfile.tmpl > /home/rd/$tgtfile


bash /home/rd/start_rsyslog.sh &
su rd -p /home/rd/start_node_exporter.sh &
su rd -p /home/rd/rogueDetector.sh
