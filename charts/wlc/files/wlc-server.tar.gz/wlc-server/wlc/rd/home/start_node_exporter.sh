#!/usr/bin/bash

function logmessage {
   echo "`date +'%Y-%m-%dT%H:%M:%S%Z%z'` $1 [WLC Rogue Detector Server App : `basename $0`] $2"
}

while [ true ]
do
        logmessage "info" "(re)Starting WLC Rogue Detector Server App Node exporter"

    	/home/node_exporter/node_exporter --web.listen-address=${RD_METRICS_LISTEN_ADDRESS:-:9187} --web.telemetry-path=${RD_METRICS_TELEMETRY_PATH:-/metrics} --web.disable-exporter-metrics

        logmessage "error" "WLC Rogue Detector Server App Node exporter exited"

    	sleep 30
done

