#!/bin/bash

cp -r /home/rd.h/* /home/rd
chown -R rd /home/rd/*
chmod -R go-w /home/rd/*
chmod -R -x /home/rd/*.*

bash /home/rd/start_rd.sh
