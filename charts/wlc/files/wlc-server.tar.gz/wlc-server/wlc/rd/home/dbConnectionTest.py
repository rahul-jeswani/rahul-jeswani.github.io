#!/home/anaconda3/bin/python
# -*- coding: utf-8 -*-
"""
Created on Fri Jun 26 07:55:03 2020

@author: anaconda
"""
import psycopg2
import sys
import os

DB_SERVER_HOST = os.environ['WLC_DBHOST']
DB_SERVER_PORT = os.environ['WLC_DBPORT']
DB_SERVER_USER = os.environ['WLC_DBUSER']
DB_SERVER_PASSWORD = os.environ['WLC_DBPASS']
DB_SERVER_DATABASE = os.environ['WLC_DBNAME']

  
try:
   conn = psycopg2.connect(user=DB_SERVER_USER, password=DB_SERVER_PASSWORD, host=DB_SERVER_HOST, port=DB_SERVER_PORT, database=DB_SERVER_DATABASE)
   conn.close()
   print(0)
   result=0
   
except:
   print(1)
   result=1

sys.exit(result)
     
 
