# -*- coding: utf-8 -*-.

#!/home/anaconda3/bin/python

"""
Created on Thu Mar  5 11:14:33 2020

@author: marco.tozzi
"""

from dataSet import *
from externalInterface import *
import math
import sched
import time
from datetime import datetime
import os
import re

TIMEOUT_DETECTOR = 10              # this value sets the rogue detector execution periodicity 
TIMEOUT_INVENTORY = 60            # this value sets the inventory update periodicity

def ClassifyAPs(underInvestigationAPList, sensorList):
# underInvestigationAPList -> the list of APs provided by the sensor that need to be classified
# classifiedAPList -> the list of the classified APs
# 1st step: verify if the BSSID exists in inventory data. If a match is found, found is true 
#    and the data is returned, otherwise found is false
            
    for detectedAp in underInvestigationAPList:
             
        # find which is the sensor 
        sensor = None
        for cursor in sensorList:
            if cursor.MAC == detectedAp.detectingSensor:
                sensor = cursor
                break
                 
        if (sensor==None):  #case when a sensor is not registered in inventory -- should never happen!
            continue
        
        if (sensor.autoClassification == False):
            sensor.classifiedAPList.append(ClassifiedAP(sensor, detectedAp.BSSID, detectedAp.SSID, ClassificationType.UNKNOWN, detectedAp.RSSI)) 
            continue
            
        # verify if the BSSID exists in inventory data. 
        result, correspondingRegisteredNE = GetNEDataFromInventory(detectedAp)
        
        if (result==False):
            return(False)

        # generate the SSIDs removing non alphanumeric characters
        alnumSSID = re.sub('[^0-9A-Za-z]',"", detectedAp.SSID)
        alnumSSIDList = [re.sub('[^0-9A-Za-z]',"", s) for s in sensor.checkedSSIDList]
        alnumSSIDUpperList = [x.upper() for x in alnumSSIDList]
      
        if (detectedAp.SSID in sensor.checkedSSIDList): # if detected SSID is among the checked
            if (correspondingRegisteredNE != None):  # if BSSID of detected ap is present in inventory
                # let us check if the detected AP BSSID is the same as sensor's BSSID... in this case it is rogue
                # since it is not possible a sensor detects itself
                if (detectedAp.detectingSensor == correspondingRegisteredNE): # this is true if 
                    # the detected AP has the BSSID 
                    # that belongs to the NE sensor --->> it is a fake AP --->> classify as ROGUE
                    sensor.classifiedAPList.append(ClassifiedAP(sensor, detectedAp.BSSID, detectedAp.SSID, ClassificationType.ROGUE, detectedAp.RSSI, detectedAp.hostName)) 
                elif (detectedAp.operational == False):
                    sensor.classifiedAPList.append(ClassifiedAP(sensor, detectedAp.BSSID, detectedAp.SSID, ClassificationType.UNKNOWN, detectedAp.RSSI, detectedAp.hostName )) 
                elif InvestigatedAPisFar(detectedAp, sensor): # if it is far from where it should be
                    sensor.classifiedAPList.append(ClassifiedAP(sensor, detectedAp.BSSID, detectedAp.SSID, ClassificationType.ROGUE, detectedAp.RSSI, detectedAp.hostName)) 
                else: 
                    # additional more restrictive criteria shall be put under this 
                    # branch (configuration check, RSSI...)
                    # since so far they have not yet been defined, then classify as FRIENDLY
                    sensor.classifiedAPList.append(ClassifiedAP(sensor, detectedAp.BSSID, detectedAp.SSID, ClassificationType.FRIENDLY, detectedAp.RSSI, detectedAp.hostName)) 
            else:
                sensor.classifiedAPList.append(ClassifiedAP(sensor, detectedAp.BSSID, detectedAp.SSID, ClassificationType.ROGUE, detectedAp.RSSI, detectedAp.hostName)) 
        elif ((alnumSSID.upper() in alnumSSIDUpperList) or (correspondingRegisteredNE != None)):
            sensor.classifiedAPList.append(ClassifiedAP(sensor, detectedAp.BSSID, detectedAp.SSID, ClassificationType.SUSPECT, detectedAp.RSSI, detectedAp.hostName)) 
        else:
            sensor.classifiedAPList.append(ClassifiedAP(sensor, detectedAp.BSSID, detectedAp.SSID, ClassificationType.EXTERNAL, detectedAp.RSSI, detectedAp.hostName)) 
    return(True)



def InvestigatedAPisFar(ap, sensor):
    # this is a fake calculation. it needs to be modified when coordinate format has been decided 
    #return (math.sqrt(math.pow((ap.lat-sensor.lat),2)+math.pow((ap.lon-sensor.lon),2)) < 100)
    return(False)
    


def RogueDetector():
    s.enter(TIMEOUT_DETECTOR, 1, RogueDetector)

    success, sensorList, detectedAPList = GetDetectedAPandSensorInfoFromLogStash() # these are the detected AP info provided by the sensor above
    
    if ((success == True) and (sensorList != None) and (detectedAPList != None)):
        success = ClassifyAPs(detectedAPList,sensorList)
        if (success == True):        
            success = SaveResults(sensorList)
    


def UpdateInventory():
    s.enter(TIMEOUT_INVENTORY, 2, UpdateInventory)
    # this function gets all rows from correspondingRegisteredNEtworkelements table
    # for each row searches in the configtable_json the bssid that
    # correspond to the mac address and then populates the 
    # registeredaps table
    
    correspondingRegisteredNEtworkElementsMACs = []
    GetNEMACAddressList(correspondingRegisteredNEtworkElementsMACs)
    GetCorrespondingAPs(correspondingRegisteredNEtworkElementsMACs)
    
    


############### main program #################

s = sched.scheduler()

s.enter(TIMEOUT_DETECTOR, 1, RogueDetector)
s.enter(TIMEOUT_INVENTORY, 2, UpdateInventory)
    
s.run();
    


