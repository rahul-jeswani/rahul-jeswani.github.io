#!/usr/bin/bash

while :
do
#    sleep 86400
    sleep 300
   
    rev=$(etcdctl endpoint status --write-out json | egrep -o '"revision":[0-9]*' | egrep -o '[0-9]*')
    etcdctl compact "$rev"
    etcdctl defrag --endpoints=${ETCD_LISTEN_PEER_URLS}
    etcdctl alarm disarm 

done
