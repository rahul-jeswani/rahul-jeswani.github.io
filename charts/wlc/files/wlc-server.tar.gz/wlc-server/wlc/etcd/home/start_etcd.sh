#!/usr/bin/bash

bash /home/etcd/start_etcd_cleanup.sh &
/usr/bin/etcd
