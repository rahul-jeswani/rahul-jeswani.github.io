#!/bin/bash

# Script to trigger backup of EMS and NE data

BACKUPFILE=$1

if [ "${BACKUPFILE}" = "" ]
then
	echo "No backupfile specified".
	exit 0
fi

if [ -f "${BACKUPFILE}" ]
then
	echo "A ${BACKUPFILE} exists already. Please provide another file name"
	exit 0
fi
mkdir ${BACKUPDIR}
if [ $? -ne 0 ]
then
	echo "Unable to create intermediate artefacts for backup"
	exit 0
fi

WLC_COMPONENTS="opennms openwisp grafana wlcapp"

echo "Stopping WLC components before backup"

docker stop ${WLC_COMPONENTS} 

docker exec wlc sh /home/wlc/backup.sh ${BACKUPFILE}

docker start ${WLC_COMPONENTS}
