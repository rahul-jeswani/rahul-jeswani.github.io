#!/bin/sh

function logmessage {
   echo "`date +'%Y-%m-%dT%H:%M:%S%Z%z'` $1 [ Stolon : `basename $0`] $2"
}

export APPNAME=${APPNAME:-wlc}

#For stolon running under K8S, use configmap
if [ "${STKEEPER_CLUSTER_NAME}" = "" ]
then
    ST_CTL_PARAMS="--cluster-name ${ST_CLUSTER_NAME} --store-backend ${ST_STORE_BACKEND} --store-endpoints ${ST_STORE_ENDPOINTS}"
else
    ST_CTL_PARAMS="--cluster-name ${STKEEPER_CLUSTER_NAME} --store-backend ${STKEEPER_STORE_BACKEND} --kube-resource-kind=configmap"
fi


set -a
. /home/stolon/dbobs.int.env
. /home/stolon/stolon.int.env

function check_cluster_init {
    retryCnt=5
    while [ $retryCnt -gt 0 ]
    do
        retryCnt=`expr $retryCnt - 1`
        keeclusstatus=`/usr/local/bin/stolonctl ${ST_CTL_PARAMS} status 2>&1`
        echo $keeclusstatus | fgrep "No keepers available No cluster available" > /dev/null
        if [ "$?" = "0" ]
        then
            logmessage "info" "cluster initialization complete"
            break;
        else
            logmessage "info" "cluster initialization yet to complete"
        fi
        sleep 60
    done
}


function check_dbserver_ready {
    retryCnt=5
    while [ $retryCnt -gt 0 ]
    do
        retryCnt=`expr $retryCnt - 1`
        pg_isready -h ${POSTGRES_HOST}  -p ${POSTGRES_PORT}  -U ${POSTGRES_USER} > /dev/null 2>&1
        if [ "$?" = "0" ]
        then
            logmessage "info" "database server ready"
            break;
        else
            logmessage "info" "database server not ready"
        fi
        sleep 60
    done
}


rm -f /tmp/stolon-ctl.status

initCluster=0   ##Indicates whether cluster must be initialized. 
initDB=0        ##Indicates whether DB must be initialized
restoreDB=0     ##Indicates whether DB must be restored from backup

if [ -f /home/stolon/stolon.init ]
then
    logmessage "info" "Cluster and DB init requested"
    initCluster=1
    initDB=1
    restoreDB=0
    initMode="{ \"initMode\": \"new\" }"
fi

if [ "$initCluster" = "0" ]
then
    clusterInfo=`/usr/local/bin/stolonctl ${ST_CTL_PARAMS} status 2>&1`
    clusterStatus=$?
    echo $clusterInfo | fgrep "No keepers available No cluster available"  > /dev/null
    if [  \( "$clusterStatus" != "0" \)  -o   \( "$?" = "0" \)  ]
    then
        ## Cluster status is not ok. Initialize cluster
        logmessage "error" "Cluster status not ok. Cluster will be initialized"
        initCluster=1
    else
        logmessage "info" "Cluster data found."
    fi
    ## Now, Check whether DB data is present and which one was the master keeper
    keepers=`cd /var/lib/postgresql/data; /bin/ls`
    existingKeeper=""
    for keeper in ${keepers}
    do
        initPGParameters=`cat /var/lib/postgresql/data/${keeper}/dbstate | egrep -o '"InitPGParameters":{.*}'`
        if [ "$?" = "0" ]
        then
            ## Found the master keeper
            logmessage "info" "Found previous master keeper"
            existingKeeper=${keeper}
            initMode="{\"initMode\": \"existing\", \"existingConfig\":{\"keeperUID\" : \""${existingKeeper}"\"} }"
        fi
    done
    if [ "${existingKeeper}" = "" ]
    then
        logmessage "info" "Could not identify previous master keeper"
        if [ "${keeper}" = "" ]
        then
            ##No keeper found. So, make note to restore data from backup"
            logmessage "info" "Could not identify any keeper. Cluster will be initialized"
            initMode="{ \"initMode\": \"new\" }"
            initCluster=1
            restoreDB=1
        else
            ##Could not find master keeper. So, choose a keeper with data"
            logmessage "info" "Keeper data available"
            existingKeeper=${keeper}
            initMode="{\"initMode\": \"existing\", \"existingConfig\":{\"keeperUID\" : \""${existingKeeper}"\"} }"
        fi
    fi
fi

if [ "$initCluster" = "1" ]
then
    logmessage "info" "Initializing cluster with init mode : ${initMode}"
    /usr/local/bin/stolonctl ${ST_CTL_PARAMS} init "${initMode}" -y
    echo $? > /tmp/stolon-ctl.status
    if [ "`cat /tmp/stolon-ctl.status`" = "0" ]
    then
        rm -f /home/stolon/stolon.init
    fi
    check_cluster_init
else
    echo 0 > /tmp/stolon-ctl.status
fi



if [ "$initDB" = "0" ]
then
    if [ "$restoreDB" = "0" ]
    then
        export PGPASSWORD=${POSTGRES_PASSWORD}
        if [ "$APPNAME" = "fss" ]
        then
            appdb=fssdb
        else
            appdb=opennms
        fi
        
        check_dbserver_ready

        database=`psql -X -A -U  ${POSTGRES_USER} -h ${POSTGRES_HOST} -t -c "\l" 2>&1`
        logmessage "info" "Databases in dbserver : $database"
        echo $database | fgrep "${appdb}|" > /dev/null
        if [ "$?" = "0" ]
        then
            logmessage "info" "Cluster ${ST_CLUSTER_NAME} and keeper are running fine with application ${APPNAME}"
        else
            logmessage "error" "Application database missing. Initializing database and restoring from backup"
            initMode="{\"initMode\": \"new\" }"
            /usr/local/bin/stolonctl ${ST_CTL_PARAMS} init "${initMode}" -y
            check_cluster_init
            restoreDB=1
        fi
    fi
fi

check_dbserver_ready

if [ "$restoreDB" = "1" ]
then
    logmessage "info" "restoring database"
    bash /home/stolon/dbbackup_restore.sh restore
fi


bash /home/stolon/dbbackup_restore.sh 

#while :
#do
#    sleep 10000
#done
