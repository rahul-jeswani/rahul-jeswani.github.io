#!/usr/bin/bash 

set -a
. /home/stolon/dbobs.int.env
. /home/stolon/stolon.int.env

gosu stolon /usr/local/bin/stolon-sentinel --cluster-name ${ST_CLUSTER_NAME} --store-backend ${ST_STORE_BACKEND} --store-endpoints ${ST_STORE_ENDPOINTS} --metrics-listen-address ${ST_METRICS_LISTEN_ADDR1} --metrics-listen-address ${ST_METRICS_LISTEN_ADDR2} --log-level warn

