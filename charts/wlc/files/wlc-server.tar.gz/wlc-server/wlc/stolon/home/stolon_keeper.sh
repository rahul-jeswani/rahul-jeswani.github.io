#!/usr/bin/bash

set -a
. /home/stolon/dbobs.int.env
. /home/stolon/stolon.int.env

gosu stolon mkdir -p ${ST_DB_DATADIR}/${ST_DB_UID}
gosu stolon cp /home/stolon/conf/postgresql.conf ${ST_DB_DATADIR}/${ST_DB_UID}

gosu stolon /usr/local/bin/stolon-keeper --cluster-name ${ST_CLUSTER_NAME} --store-backend ${ST_STORE_BACKEND} --store-endpoints ${ST_STORE_ENDPOINTS} --pg-listen-address ${ST_KEEPER_ADDR1} --pg-listen-address ${ST_KEEPER_ADDR2} --pg-repl-username ${ST_STOLON_REPLUSER} --pg-repl-password ${ST_STOLON_REPLPWD} --pg-su-password ${ST_STOLON_PWD} --pg-su-username ${ST_STOLON_USER} --uid ${ST_DB_UID} --data-dir ${ST_DB_DATADIR}/${ST_DB_UID} --metrics-listen-address ${ST_METRICS_LISTEN_ADDR1} --metrics-listen-address ${ST_METRICS_LISTEN_ADDR2} --log-level warn
