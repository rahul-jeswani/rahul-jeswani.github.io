#!/usr/bin/bash

function get_log_prefix {
    echo "`date +'%Y-%m-%dT%H:%M:%SZ%z'` [Stolon - `basename $0`]"
}
set -a
. /home/stolon/dbobs.int.env
. /home/stolon/stolon.int.env

while [ true ]
do
#    pg_isready -h /tmp -p 5432 -d postgres -U postgres
    pg_isready -h  ${ST_STOLON_PROXY} -p ${POSTGRES_PORT} -d postgres -U ${POSTGRES_USER}
    if [ $? -eq 0 ]
    then
        echo "$(get_log_prefix) error : (re)Starting postgres exporter"

        /home/stolon/postgres_exporter 

        echo "$(get_log_prefix) error : postgres exporter exited"
    else
        echo "$(get_log_prefix) error : Waiting for postgres database to be ready"
    fi
    sleep 30
done

