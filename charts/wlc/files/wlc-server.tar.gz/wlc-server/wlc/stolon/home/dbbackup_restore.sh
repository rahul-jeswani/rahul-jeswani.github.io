#!/bin/bash

function logmessage {
   echo "`date +'%Y-%m-%dT%H:%M:%S%Z%z'` $1 [ Stolon : `basename $0`] $2"
}

cd /home/stolon
export PGPASSWORD=${POSTGRES_PASSWORD}

set -a
. /home/stolon/dbobs.int.env
. /home/stolon/stolon.int.env

function do_validate {
    find ${BACKUP_DIR} -type f -print0 | xargs --null grep -Z -L 'PostgreSQL database dump complete' | xargs --null rm
    find ${BACKUP_DIR} -type f -print0 | xargs --null grep -Z -L 'PostgreSQL database cluster dump complete' | xargs --null rm
}

function do_prune {
    find ${BACKUP_DIR} -name '*.*' -mmin +`expr ${BACKUP_INTERVAL} \* ${BACKUP_COUNT} / 60` -delete > /dev/null
}

function do_backup {
    backuptype=$1
    tstamp=$(date --utc +\%Y\%m\%d_\%H\%M\%SZ)
    backupfile=${BACKUP_DIR}/${APPNAME}.data.${tstamp}
    logmessage "info" "${backuptype} backup : Backing up data to ${backupfile}"
    pg_dumpall -h ${POSTGRES_HOST} -U ${POSTGRES_USER} -p ${POSTGRES_PORT} > ${backupfile} 2>&1
    logmessage "info" "${backuptype} backup : Backing to ${backupfile} completed"
}

function do_restore {
    cd ${BACKUP_DIR}
    latest_backup=`ls -t | head -n 1`
    if [ "${latest_backup}" = "" ]
    then
        logmessage "error" "No valid backup file found for restore"
        exit 1        
    else
        logmessage "info" "Restoring data from ${latest_backup}"
        psql -h ${POSTGRES_HOST} -U ${POSTGRES_USER} -p ${POSTGRES_PORT} < ${latest_backup}
        logmessage "info" "Restoring data from ${latest_backup} completed"
        exit 0
    fi
}


if [ \( "${BACKUP_INTERVAL}" = "" \) -o \(  "${BACKUP_COUNT}" = "" \) -o \( "${BACKUP_DIR}" = ""  \) ]
then
    logmessage "error" "Required backup environment variables BACKUP_INTERVAL, BACKUP_COUNT and BACKUP_DIR are not set. Exiting"
    exit 1
fi

mkdir -p ${BACKUP_DIR}

case $1 in
    "now" ) :
        do_backup "Adhoc"
        do_validate
        ;;
    "restore" ) :
        do_validate
        do_restore
        ;;
    * ) :
        while :
        do
            do_backup "Periodic"
            do_validate
            do_prune
            sleep ${BACKUP_INTERVAL}
        done
        ;;
esac
