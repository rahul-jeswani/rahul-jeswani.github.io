#!/usr/bin/bash

set -a
. /home/stolon/dbobs.int.env
. /home/stolon/stolon.int.env

echo PATH=\$PATH:$PATH >> ~stolon/.profile
echo PATH=\$PATH:$PATH >> ~repluser/.profile

bash /home/stolon/start_exporter.sh &
#bash /home/stolon/dbbackup_restore.sh &

gosu stolon /usr/local/bin/stolon-proxy --cluster-name ${ST_CLUSTER_NAME} --store-backend ${ST_STORE_BACKEND} --store-endpoints ${ST_STORE_ENDPOINTS} --port ${ST_PRXY_PORT} --listen-address '0.0.0.0' --listen-address '::' --metrics-listen-address ${ST_METRICS_LISTEN_ADDR1} --metrics-listen-address ${ST_METRICS_LISTEN_ADDR2} --log-level warn
