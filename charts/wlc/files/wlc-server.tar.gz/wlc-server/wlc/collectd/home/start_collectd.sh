#!/usr/bin/bash

#[ -f /home/collectd/prestart_collectd.sh ] && bash /home/collectd/prestart_collectd.sh

if [ -f /home/collectd/conf/collectd.conf.tmpl ]
then
tgtfile=collectd.conf
sed \
	-e 's/KAFKA_HOST/'$KAFKA_HOST'/' \
	-e 's/COLLECTD_KAFKA_TOPIC/'$COLLECTD_KAFKA_TOPIC'/' \
	< /home/collectd/conf/$tgtfile.tmpl > /home/collectd/conf/$tgtfile
fi

bash /home/collectd/start_node_exporter.sh &

/usr/sbin/collectd -f -C /home/collectd/conf/collectd.conf
