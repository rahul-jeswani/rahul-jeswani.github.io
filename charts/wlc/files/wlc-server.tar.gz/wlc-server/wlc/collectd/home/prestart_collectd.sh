#!/usr/bin/bash

#[ -f /home/collectd/conf/collectd.conf ] && cp /home/collectd/conf/collectd.conf /etc
if [ -f /home/collectd/conf/collectd.conf.tmpl ]
then
tgtfile=collectd.conf
sed \
	-e 's/KAFKA_HOST/'$KAFKA_HOST'/' \
	-e 's/COLLECTD_KAFKA_TOPIC/'$COLLECTD_KAFKA_TOPIC'/' \
	< /home/collectd/conf/$tgtfile.tmpl > /etc/$tgtfile
fi
