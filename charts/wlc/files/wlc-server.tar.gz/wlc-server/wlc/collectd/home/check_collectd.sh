#!/usr/bin/bash

netstat -alun 2>&1 | grep 25826 > /dev/null

