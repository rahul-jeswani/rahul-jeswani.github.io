#!/usr/bin/bash

function logmessage {
   echo "`date +'%Y-%m-%dT%H:%M:%S%Z%z'` $1 [Collectd: `basename $0`] $2"
}

#COLLECTD_METRICS_LISTEN_ADDRESS=:9187
#COLLECTD_METRICS_TELEMETRY_PATH=/metrics

while [ true ]
do
        logmessage "info" "(re)Starting Collectd Node exporter"

    	/home/collectd/node_exporter --web.listen-address=${COLLECTD_METRICS_LISTEN_ADDRESS:-:9187} --web.telemetry-path=${COLLECTD_METRICS_TELEMETRY_PATH:-/metrics} --web.disable-exporter-metrics

        logmessage "error" "Collectd Node exporter exited"

    	sleep 30
done

