#!/usr/bin/bash

#mkdir /home/collectd
cp -r /home/collectd.h/* /home/collectd
chown -R collectd:collectd /home/collectd/* 
chmod -R go-w /home/collectd/*
chmod -R -x /home/collectd/*.* /home/collectd/*/*.*

su collectd -p  /home/collectd/start_collectd.sh
