#!/usr/bin/bash


cp -r /home/logstash.h/* /home/logstash
chown -R logstash:logstash /home/logstash/* 
chmod -R go-w /home/logstash/*
chmod -R -x /home/logstash/*.* /home/logstash/*/*.*

bash  /home/logstash/start_logstash.sh
