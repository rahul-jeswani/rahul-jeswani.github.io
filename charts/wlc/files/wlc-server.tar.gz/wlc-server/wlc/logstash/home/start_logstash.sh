#!/bin/bash -e

set -a
. /home/logstash/logstash.int.env
. /home/logstash/wlc.int.env

[ -f  /home/logstash/conf/syslog.conf ]   && cp /home/logstash/conf/syslog.conf /usr/share/logstash/pipeline/syslog.conf
[ -f  /home/logstash/conf/logstash.yml ]  && cp /home/logstash/conf/logstash.yml /usr/share/logstash/config/logstash.yml
[ -f  /home/logstash/conf/pipelines.yml ] && cp /home/logstash/conf/pipelines.yml /usr/share/logstash/config/pipelines.yml

su logstash -p /home/logstash/start_node_exporter.sh &

bash /home/logstash/entrypoint.sh

