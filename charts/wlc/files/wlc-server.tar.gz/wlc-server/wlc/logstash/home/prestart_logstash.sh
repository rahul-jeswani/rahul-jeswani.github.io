#!/usr/bin/bash


[ -f  /home/logstash/conf/syslog.conf ]   && cp /home/logstash/conf/syslog.conf /usr/share/logstash/pipeline/syslog.conf
[ -f  /home/logstash/conf/logstash.yml ]  && cp /home/logstash/conf/logstash.yml /usr/share/logstash/config/logstash.yml
[ -f  /home/logstash/conf/pipelines.yml ] && cp /home/logstash/conf/pipelines.yml /usr/share/logstash/config/pipelines.yml

exit 0
