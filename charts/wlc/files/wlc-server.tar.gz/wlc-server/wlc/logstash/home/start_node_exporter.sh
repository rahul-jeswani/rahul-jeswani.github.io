#!/usr/bin/bash

function logmessage {
   echo "`date +'%Y-%m-%dT%H:%M:%S%Z%z'` $1 [logstash: `basename $0`] $2"
}

#LOGSTASH_METRICS_LISTEN_ADDRESS=:9187
#LOGSTASH_METRICS_TELEMETRY_PATH=/metrics

while [ true ]
do
        logmessage "info" "(re)Starting logstash Node exporter"

    	/home/logstash/node_exporter --web.listen-address=${LOGSTASH_METRICS_LISTEN_ADDRESS:-:9187} --web.telemetry-path=${LOGSTASH_METRICS_TELEMETRY_PATH:-/metrics} --web.disable-exporter-metrics

        logmessage "error" "logstash Node exporter exited"

    	sleep 30
done

