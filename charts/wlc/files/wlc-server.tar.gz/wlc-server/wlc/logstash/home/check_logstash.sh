#!/usr/bin/bash

cat /proc/net/tcp6 | egrep '(0)+:(0202 )(0)+:(0000) (0A)' > /dev/null
