#!/bin/bash

function logmessage {
   echo "`date +'%Y-%m-%dT%H:%M:%S%Z%z'` $1 [OpenWISP: `basename $0`] $2"
}

export PGPASSWORD=$POSTGRES_PASSWORD
if [ "$( psql -X -A -U $POSTGRES_USER -h $OPENWISP_DBHOST -d $POSTGRES_DB -p $OPENWISP_DBPORT -t -c "SELECT 1 FROM pg_database WHERE datname='$OPENWISP_DBNAME';" )" = '1' ]
then
    logmessage "info" "OpenWISP Database already exists"
else
    logmessage "info" "OpenWISP Database need to be created"
    psql -X -A -U $POSTGRES_USER -h $OPENWISP_DBHOST -d $POSTGRES_DB -p $OPENWISP_DBPORT -t -c "create database $OPENWISP_DBNAME;"     
fi
if [ "$( psql -X -A -U $POSTGRES_USER -h $POSTGRES_HOST -d $POSTGRES_DB -p $POSTGRES_PORT -t -c "SELECT 1 FROM pg_database WHERE datname='$GRAFANA_DBNAME';" )" = '1' ]
then
    logmessage "info" "Grafana Database already exists"
    psql -X -A -U $POSTGRES_USER -h $POSTGRES_HOST -d $POSTGRES_DB -p $POSTGRES_PORT -t -c "drop database $GRAFANA_DBNAME;" 2>/dev/null
fi

logmessage "info" "Grafana Database being reloaded"
psql -X -A -U $POSTGRES_USER -h $POSTGRES_HOST -d $POSTGRES_DB -p $POSTGRES_PORT -t -c "create database $GRAFANA_DBNAME;"     
psql -X -A -U $POSTGRES_USER -h $POSTGRES_HOST -d $GRAFANA_DBNAME -p $POSTGRES_PORT < /home/openwisp/gf_ms7_dump.sql
