#!/usr/bin/bash

function logmessage {
   echo "`date +'%Y-%m-%dT%H:%M:%S%Z%z'` $1 [OpenWISP: `basename $0`] $2"
}

while [ true ]
do
        logmessage "info" "(re)Starting OpenWISP Node exporter"

    	/home/node_exporter/node_exporter --web.listen-address=${OPENWISP_METRICS_LISTEN_ADDRESS} --web.telemetry-path=${OPENWISP_METRICS_TELEMETRY_PATH} --web.disable-exporter-metrics

        logmessage "error" "OpenWISP Node exporter exited"

    	sleep 30
done

