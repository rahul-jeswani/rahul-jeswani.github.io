--------------------------------------------------------------
-- Rogues Scan table creation (to collect scan data from APs)
--------------------------------------------------------------

CREATE TABLE roguedetector_roguescantable_json (
   id serial NOT NULL PRIMARY KEY,
   timetick timestamptz NOT NULL DEFAULT NOW(),
   host_name varchar(30),
   scan_report json
);

-------------------------------------------------------------------------
-- Configuration table creation (to collect configuration data from APs)
-------------------------------------------------------------------------

CREATE TABLE roguedetector_configurationaptable_json (
   id serial NOT NULL PRIMARY KEY,
   timetick timestamptz NOT NULL DEFAULT NOW(),
   host_name varchar(30),
   configuration_report json
);

-------------------------------
-- Ingress database creation
-------------------------------

--CREATE TABLE roguedetector_registeredNetworkElements (
--MAC   varchar(17) NOT NULL primary key,
--autoclassification boolean DEFAULT true,
--operational boolean DEFAULT true,
--location varchar(250),
--timetick timestamptz NOT NULL DEFAULT NOW()
--);

CREATE TABLE roguedetector_registeredAPs (
MAC   varchar(17) references ap_location_map (macaddress) on DELETE CASCADE,
BSSID varchar(17),
SSID  varchar(32),
encryption varchar(20),
hostname varchar(255),
timetick timestamptz NOT NULL DEFAULT NOW()
);

CREATE TABLE roguedetector_checkedssids (
SSID varchar(32),
timetick timestamptz NOT NULL DEFAULT NOW()
);

-----------------------------
-- Egress database creation
-----------------------------

CREATE TYPE  classificationType AS ENUM ('UNKNOWN', 'ROGUE','FRIENDLY','EXTERNAL','SUSPECT');

CREATE TABLE roguedetector_classifiedAPs (
sensorMAC   varchar(17),
BSSID        varchar(17),
SSID        varchar(32),
Classification ClassificationType,
RSSI integer,
timetick timestamptz NOT NULL DEFAULT NOW(),
history char(1)
);

--------------------------------------------------------------------------------------------------------------------
-- Function and trigger creation to delete oldest configuration entry (to keep updated the entry with the last-one)
--------------------------------------------------------------------------------------------------------------------

CREATE FUNCTION configurationaptable_delete_oldest_entry() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
	DELETE
	FROM
		roguedetector_configurationaptable_json a
			USING roguedetector_configurationaptable_json b
	WHERE
		a.timetick < b.timetick
		AND a.configuration_report ->> 'ap_hostname' = b.configuration_report ->> 'ap_hostname'
		AND a.configuration_report ->> 'bssid' = b.configuration_report ->> 'bssid'
		AND a.configuration_report ->> 'ap_mac_address' = b.configuration_report ->> 'ap_mac_address';
	RETURN NEW;
END;
$$;

CREATE TRIGGER configurationaptable_delete_oldest_entry_trigger
    AFTER INSERT ON roguedetector_configurationaptable_json 
    EXECUTE PROCEDURE configurationaptable_delete_oldest_entry();

--------------------------------------------------------------------------------------------------------------------------------------------------
-- Function and trigger creation to delete oldest configuration results after 3 hours (in case the AP is removed or disconnected from the network)
--------------------------------------------------------------------------------------------------------------------------------------------------

CREATE FUNCTION configurationaptable_delete_old_row_entry() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  DELETE FROM roguedetector_configurationaptable_json  WHERE timetick < NOW() - INTERVAL '3 hours';
  RETURN NEW;
END;
$$;

CREATE TRIGGER configurationaptable_delete_old_row_trigger
    AFTER INSERT ON roguedetector_configurationaptable_json
    EXECUTE PROCEDURE configurationaptable_delete_old_row_entry();

-------------------------------------------------------------------------------------------------------------------------------
-- Function and trigger creation to delete oldest scan results after 1 day (to keep clean and avoid explosion of the database)
-------------------------------------------------------------------------------------------------------------------------------

CREATE FUNCTION roguescantable_delete_old_rows() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  DELETE FROM roguedetector_roguescantable_json  WHERE timetick < NOW() - INTERVAL '1 day';
  RETURN NEW;
END;
$$;

CREATE TRIGGER roguescantable_delete_old_rows_trigger
    AFTER INSERT ON roguedetector_roguescantable_json
    EXECUTE PROCEDURE roguescantable_delete_old_rows();
	
