#!/usr/bin/bash

function logmessage {
   echo "`date +'%Y-%m-%dT%H:%M:%S%Z%z'` $1 [WLCDB: `basename $0`] $2"
}

export PGPASSWORD=$WLC_DBPASS
if [ "$( psql -X -A -U $WLC_DBUSER -h $WLC_DBHOST -d $POSTGRES_DB -p $WLC_DBPORT -t -c "SELECT 1 FROM pg_database WHERE datname='$WLC_DBNAME';" )"= '1' ]
then
    logmessage "info" "WLCDB Database already exists"
else
    logmessage "info" "WLCDB Database need to be created"
    psql -X -A -U $WLC_DBUSER -h  $WLC_DBHOST -d $POSTGRES_DB -p $WLC_DBPORT -t -c "create database $WLC_DBNAME WITH OWNER = postgres ENCODING = 'UTF8' LC_COLLATE = 'en_US.utf8' LC_CTYPE = 'en_US.utf8' TABLESPACE = pg_default CONNECTION LIMIT = -1;"
    psql -X -A -U $WLC_DBUSER -h  $WLC_DBHOST -d $POSTGRES_DB -p $WLC_DBPORT -t -c "GRANT TEMPORARY, CONNECT ON DATABASE $WLC_DBNAME TO PUBLIC;"
    psql -X -A -U $WLC_DBUSER -h  $WLC_DBHOST -d $POSTGRES_DB -p $WLC_DBPORT -t -c "GRANT ALL ON DATABASE wlcdb TO postgres;"
    psql -X -A -U $WLC_DBUSER -h  $WLC_DBHOST -d $POSTGRES_DB -p $WLC_DBPORT -t -c "GRANT ALL ON DATABASE wlcdb TO opennms;"
fi

#psql -X -A -U $WLC_DBUSER -h $WLC_DBHOST -d $WLC_DBNAME -p $WLC_DBPORT < /home/openwisp/security_table.sql

psql postgresql://$POSTGRES_USER:$POSTGRES_PASSWORD@$POSTGRES_HOST/$WLC_DBNAME << EOF
drop table IF EXISTS ap_location_map;

CREATE TABLE public.ap_location_map
(
    macaddress character varying(50) NOT NULL,
    hostname character varying(50) NOT NULL,
    friendlyname character varying(50) NOT NULL,
    floor character varying(100),
    building character varying(100),
    site character varying(100),
    latitude double precision,
    longitude double precision,
    wlcfqdn character varying(100) NOT NULL,
    lastmodifieddate bigint, 
    status character varying(50),
    category character varying(100),
    autoclassification boolean DEFAULT true,
    PRIMARY KEY (macaddress)
)
WITH (
    OIDS = FALSE
);

ALTER TABLE public.ap_location_map
    OWNER to postgres;

EOF

psql -X -A -U $WLC_DBUSER -h $WLC_DBHOST -d $WLC_DBNAME -p $WLC_DBPORT < /home/openwisp/security_table.sql

