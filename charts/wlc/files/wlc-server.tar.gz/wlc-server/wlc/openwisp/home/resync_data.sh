#!/bin/bash

function logmessage {
   echo "`date +'%Y-%m-%dT%H:%M:%S%Z%z'` $1 [OpenWISP: `basename $0`] $2"
}

. /home/openwisp/openwisp.int.env
export PGPASSWORD=$POSTGRES_PASSWORD
logmessage "info" "Initiating re-synchronization of registered APs with OpenNMS"
psql -X -A -U ${OPENWISP_DBUSER} -d ${OPENWISP_DBNAME} -h ${OPENWISP_DBHOST} -p ${OPENWISP_DBPORT} -t -c "delete from device_ip_data"
