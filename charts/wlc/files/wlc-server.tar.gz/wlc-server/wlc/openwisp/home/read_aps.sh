#!/bin/bash
#. /home/openwisp/openwisp.env
#. /home/openwisp/opennms.env
#. /home/openwisp/postgres.env
#. /home/openwisp/wlc.env

function logmessage {
   echo "`date +'%Y-%m-%dT%H:%M:%S%Z%z'` $1 [OpenWISP: `basename $0`] $2"
}

while :
do
sleep 60
	
	export PGPASSWORD=$WLC_DBPASS
	ap_arr=$(psql -X -A -U ${WLC_DBUSER} -d ${WLC_DBNAME} -h ${WLC_DBHOST} -p ${WLC_DBPORT} -t -c "select macaddress, hostname, friendlyname from ap_location_map" 2>/dev/null)
	
	if [ -z "$ap_arr" ]
	then
			#logmessage "info" "No Access point available in wlc_db"
			:
	else
		for i in $ap_arr
		do
			ap_mac=$(echo $i | awk -F '|' '{print $1}')
			AP_Hostname=$(echo $i | awk -F '|' '{print $2}')
			AP_Friendlyname=$(echo $i | awk -F '|' '{print $3}')
			export PGPASSWORD=$POSTGRES_PASSWORD

			mac=`echo $ap_mac | sed -e 's/[\-]/:/g' -e 's/\(.*\)/\U\1/'`
			dev_details=$(psql -X -A -U ${OPENWISP_DBUSER} -d ${OPENWISP_DBNAME} -h ${POSTGRES_HOST} -t -c "select name, friendly_name from config_device where mac_address='$mac'" 2>/dev/null)
			if [ ! -z "$dev_details" ]
			then
				dv_name=$(echo $dev_details | awk -F '|' '{print $1}' )
				friendly_name=$(echo $dev_details | awk -F '|' '{print $2}' )
				if [ ! -z "$dv_name" ]
				then
					if [ "$dv_name" == "$AP_Hostname" ] && [ "$friendly_name" == "$AP_Friendlyname" ]
					then
						:
						#       logmessage "info" "${ow_logmsg} : already updated"
					else
						psql -X -A -U ${OPENWISP_DBUSER} -d ${OPENWISP_DBNAME} -h ${POSTGRES_HOST} -t -c "update config_device set name='$AP_Hostname' , friendly_name='$AP_Friendlyname' where mac_address='$mac'" > /dev/null 2>&1
						if [ $? -eq 0 ]
						then
								logmessage "info" "AP details successfully updated for MAC='$ap_mac' , AP_Hostname='$AP_Hostname' and  friendly_name='$AP_Friendlyname'"
						else
								logmessage "info" "AP details updation failed for MAC='$ap_mac' , AP_Hostname='$AP_Hostname' and  friendly_name='$AP_Friendlyname'"
						fi
					fi
				fi
			fi
			ip=$(psql -X -A -U ${OPENWISP_DBUSER} -d ${OPENWISP_DBNAME} -h ${POSTGRES_HOST} -t -c "select management_ip from config_device  where mac_address='$mac'" 2>/dev/null)
			export PGPASSWORD=$OPENNMS_DBPASS
			nlabel=$(psql -X -A -U ${OPENNMS_DBUSER} -d ${OPENNMS_DBNAME} -h ${POSTGRES_HOST} -t -c "select nodelabel from node where nodeid=(select nodeid from ipinterface where ipaddr='$ip')" 2>/dev/null)			
			if [ ! -z "$nlabel" ]
			then
				if [ "$nlabel" == "$AP_Friendlyname" ]
				then
						:
				else
					psql -X -A -U ${OPENNMS_DBUSER} -d ${OPENNMS_DBNAME} -h ${POSTGRES_HOST} -t -c "update node set nodelabel='$AP_Friendlyname' where nodeid=(select nodeid from ipinterface where ipaddr='$ip')" > /dev/null 2>&1
					if [ $? -eq 0 ]
					then
							logmessage "info"  "AP Node Label successfully updated for MAC='$ap_mac' with '$AP_Friendlyname'"
					else
							logmessage "info" "AP Node Label updation failed for MAC='$ap_mac' with '$AP_Friendlyname'"
					fi
				fi
			fi

		done
	fi

done
