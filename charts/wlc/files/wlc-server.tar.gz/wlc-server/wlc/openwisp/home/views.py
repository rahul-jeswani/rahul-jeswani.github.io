from django.shortcuts import redirect
from django.views.decorators.csrf import csrf_exempt
from rest_framework.decorators import api_view
from rest_framework.response import Response
import psycopg2
import json
import datetime
import os
import requests
import time
from django.core import serializers


@csrf_exempt
def onmslogin(request, csrftoken, sessionid, expires, max_age):

    response = redirect('/admin/')
    ts = datetime.datetime.now()
    response.set_cookie("csrftoken", csrftoken , max_age=max_age, expires=ts + datetime.timedelta(days=1), domain=request.META["HTTP_X_FORWARDED_SERVER"] , secure=None)
    response.set_cookie("JSESSIONID", sessionid, max_age=max_age, expires=ts + datetime.timedelta(days=1), domain=request.META["HTTP_X_FORWARDED_SERVER"], secure=None)
    response.set_cookie("sessionid", sessionid, max_age=max_age, expires=ts + datetime.timedelta(days=1), domain=request.META["HTTP_X_FORWARDED_SERVER"], secure=None)
    return response


@csrf_exempt
@api_view(['POST', 'PUT'])
def tagtemplate(request):
    #call script here

    if request.method == 'POST':
        try:
            connection = psycopg2.connect(user=os.environ['OPENWISP_DBUSER'],
                                  password=os.environ['OPENWISP_DBPASS'],
                                  host=os.environ['OPENWISP_DBHOST'],
                                  port=os.environ['OPENWISP_DBPORT'],
                                  database=os.environ['OPENWISP_DBNAME'])
            cursor = connection.cursor()
            data = json.loads(request.body)
            configs = data['configs']
            
            for config in configs:

                cursor.execute("INSERT INTO config_config_templates(config_id, template_id, sort_value) VALUES (%s, %s, %s)", (config['config_id'], config['template_id'], '1'))
                connection.commit()
                count = cursor.rowcount
                print (count, "Record inserted successfully into config_config_templates table")

                if(count > 0):
                    env_ap_os = os.environ['OS_SUPPORT_MIN_AP_VERSION']
                    ap_version = env_ap_os.split("V")[1].split("_")
                    cursor.execute("SELECT config FROM config_template WHERE id = %s", (config['template_id'],))
                    rows = cursor.fetchone()
                    configdata = rows[0]
                    jsonconfig = json.loads(configdata)
                    for (k, v) in jsonconfig.items():
                       temp_type = k
                       if temp_type == 'swupgrade':
                          t_version = jsonconfig['swupgrade']['swversion']
                          template_version = t_version.split("V")[1].split("_")
                          os_value = t_version + "*"
                          if(template_version[0] < ap_version[0] or ( template_version[0] == ap_version[0] and template_version[1] < ap_version[1])):
                             cursor.execute("UPDATE config_device AS cd SET os = %s FROM config_config AS cc WHERE cc.device_id = cd.id AND cc.id = %s", (os_value, config['config_id']))
                    connection.commit()

        except (Exception, psycopg2.Error) as error :
            if(connection):
                print("Failed to insert record into config_config_templates table", error)
                return Response(error)

        finally:
            #closing database connection.
            if(connection):
                cursor.close()
                connection.close()
                print("PostgreSQL connection is closed")

        return Response({"result": "Template has tagged to device"})

 
    if request.method == 'PUT':
        try:
            connection = psycopg2.connect(user=os.environ['OPENWISP_DBUSER'],
                                  password=os.environ['OPENWISP_DBPASS'],
                                  host=os.environ['OPENWISP_DBHOST'],
                                  port=os.environ['OPENWISP_DBPORT'],
                                  database=os.environ['OPENWISP_DBNAME'])
            cursor = connection.cursor()
            data = json.loads(request.body)
            configs = data['configs']
            #return Response(configs)

            for config in configs:

                cursor.execute("DELETE FROM config_config_templates WHERE config_id=%s AND template_id=%s", (config['config_id'], config['template_id']))
                connection.commit()
                count = cursor.rowcount
                print (count, "Record deleted successfully into config_config_templates table")

        except (Exception, psycopg2.Error) as error :
            if(connection):
                print("Failed to delete record into config_config_templates table", error)
                return Response(error)

        finally:
            #closing database connection.
            if(connection):
                cursor.close()
                connection.close()
                print("PostgreSQL connection is closed")

        return Response({"result": "Template has untagged to device"}) 


@csrf_exempt
@api_view(['POST'])
def speedtest(request):

    if request.method == 'POST':
        try:
            connection = psycopg2.connect(user=os.environ['OPENWISP_DBUSER'],
                                  password=os.environ['OPENWISP_DBPASS'],
                                  host=os.environ['OPENWISP_DBHOST'],
                                  port=os.environ['OPENWISP_DBPORT'],
                                  database=os.environ['OPENWISP_DBNAME'])

            jsonrequest = {}
            jsonresponse = {}
            response = {}
            netvelocity = {}
            info_20mhz = {}
            info_5mhz = {}
            data = json.loads(request.body)
            speedtest = data['rmno:femto_nv']
            netvelocity['version'] = speedtest['version']
            netvelocity['device'] = speedtest['device']
            netvelocity['model'] = speedtest['model']
            netvelocity['txn_id'] = speedtest['txn_id']
            netvelocity['mac_address'] = speedtest['mac_address']
            macaddress = speedtest['mac_address']
            netvelocity['serial_number'] = speedtest['serial_number']
            netvelocity['location'] = speedtest['location']
            netvelocity['bandwidth'] = speedtest['bandwidth']
            netvelocity['active_test_type'] = speedtest['active_test_type']
            netvelocity['nv_fqdn'] = speedtest['nv_fqdn']
            netvelocity['nv_filename'] = speedtest['nv_filename']
            netvelocity['oss_fqdn'] = speedtest['oss_fqdn']
            netvelocity['test_retry_max'] = speedtest['test_retry_max']
            netvelocity['test_retry_interval'] = speedtest['test_retry_interval']
            atp_test_info = speedtest['atp-test-info']

#####      20MHZ Block ##################################################

            bandwidth_20mhz = atp_test_info['20mhz']
            test_01_20mhz = bandwidth_20mhz['TC-ATP1C-01']
            info_20mhz['test_duration1'] =  test_01_20mhz['test_duration']
            info_20mhz['pass_criteria1'] =  test_01_20mhz['pass_criteria']

            test_02_20mhz = bandwidth_20mhz['TC-ATP1C-02'] 
            info_20mhz['test_duration2'] =  test_02_20mhz['test_duration']
            info_20mhz['pass_criteria2'] =  test_02_20mhz['pass_criteria']

            test_03_20mhz = bandwidth_20mhz['TC-ATP1C-03'] 
            info_20mhz['test_duration3'] =  test_03_20mhz['test_duration']
            info_20mhz['pass_criteria3'] =  test_03_20mhz['pass_criteria']
            info_20mhz['test_bandwidth'] = '20mhz'
 
#####      5MHZ Block ##################################################

            bandwidth_5mhz = atp_test_info['5mhz']
            test_01_5mhz = bandwidth_5mhz['TC-ATP1C-01']
            info_5mhz['test_duration1'] =  test_01_5mhz['test_duration']
            info_5mhz['pass_criteria1'] =  test_01_5mhz['pass_criteria']

            test_02_5mhz = bandwidth_5mhz['TC-ATP1C-02'] 
            info_5mhz['test_duration2'] =  test_02_5mhz['test_duration']
            info_5mhz['pass_criteria2'] =  test_02_20mhz['pass_criteria']

            test_03_5mhz = bandwidth_5mhz['TC-ATP1C-03'] 
            info_5mhz['test_duration3'] =  test_03_5mhz['test_duration']
            info_5mhz['pass_criteria3'] =  test_03_5mhz['pass_criteria']
            
            info_5mhz['test_bandwidth'] = '5mhz'    

            netvelocity['atp_test_info'] = [info_20mhz,info_5mhz]
            jsonrequest['netvelocity'] = netvelocity
            template_req_data = json.dumps(jsonrequest)
            cursor = connection.cursor()
#####      Check AP Status      ##################################################################
            ap_status = check_ap_status(speedtest['mac_address'])
            if ap_status == 'up':
                #####  Getting config id from DB  ##################################################            
                query = "select con.id from config_device dev , config_config con where dev.mac_address = %s AND dev.id=con.device_id"
                cursor.execute(query, (speedtest['mac_address'],))
                record = cursor.fetchone()
                config_id = record[0]
              ##### check if template with same name as mac_address exist and deleting if exist   ##################################################  
                tempexistquery = "select count(*) from config_template where name = %s"
                cursor = connection.cursor()
                cursor.execute(tempexistquery, (speedtest['mac_address'],))
                rows = cursor.fetchone()
                count = rows[0]
                if count == 1:
                   get_temp_id_query = "select id from config_template where name = %s"
                   cursor = connection.cursor()
                   cursor.execute(get_temp_id_query, (speedtest['mac_address'],))
                   temp_rows = cursor.fetchone()
                   exist_temp_id = temp_rows[0]
                   untag_query = "DELETE FROM config_config_templates WHERE config_id=%s AND template_id=%s"
                   cursor = connection.cursor()
                   cursor.execute(untag_query, (config_id, exist_temp_id))
                   delquery = "delete from config_template where name = %s"
                   cursor = connection.cursor()
                   cursor.execute(delquery, (speedtest['mac_address'],))
                   connection.commit()
              #####  calling create template API  ##################################################            
                organization = 'Rakuten'
                get_org_query = "select id from openwisp_users_organization where name = %s"
                cursor = connection.cursor()
                cursor.execute(get_org_query, (organization,))
                org_rows = cursor.fetchone()
                org_id = org_rows[0]
                temp_name = speedtest['mac_address']
                config_data = template_req_data
                template_data = {'name' : temp_name , 'config' : config_data , 'backend' : 'netjsonconfig.OpenWrt' , 'organization_id' : str(org_id)}
                template_data_json = json.dumps(template_data)
                temp_api_url_base = 'http://localhost:8000/Templates/'
                temp_headers = {'Content-Type': 'application/json','Accept': 'application/json'}
                temp_response = requests.post(temp_api_url_base, headers=temp_headers, data=template_data_json)
                temp_json_data = json.loads(temp_response.text)
                template_id = temp_json_data['id']
             #####  Tagging speed test template to AP by API  ##################################################   
                insert_tag_tmpl_query = "INSERT INTO config_config_templates(config_id, template_id, sort_value) VALUES (%s, %s, %s)"
                cursor = connection.cursor()
                cursor.execute(insert_tag_tmpl_query, (config_id, template_id, '1'))
                update_device_status_query = "UPDATE config_config set status ='modified' where id=%s" 
                cursor = connection.cursor()
                cursor.execute(update_device_status_query, (config_id,))
                connection.commit()
             #####      Response if device_status is up,down,not reachable to API   ##################################################            
                response['version'] = speedtest['version']
                response['device'] = speedtest['device']
                response['model'] = speedtest['model']
                response['txn_id'] = speedtest['txn_id']
                response['mac_address'] = speedtest['mac_address']
                response['serial_number'] = speedtest['serial_number']
                response['active_test_type'] = speedtest['active_test_type']
                response['result'] = 'success'
                response['error_code'] = '200'
            elif ap_status == 'down':
                response['version'] = speedtest['version']
                response['device'] = speedtest['device']
                response['model'] = speedtest['model']
                response['txn_id'] = speedtest['txn_id']
                response['mac_address'] = speedtest['mac_address']
                response['serial_number'] = speedtest['serial_number']
                response['active_test_type'] = speedtest['active_test_type']
                response['result'] = 'ap_not_reachable'
                response['error_code'] = '200'
            else:
                response['version'] = speedtest['version']
                response['device'] = speedtest['device']
                response['model'] = speedtest['model']
                response['txn_id'] = speedtest['txn_id']
                response['mac_address'] = speedtest['mac_address']
                response['serial_number'] = speedtest['serial_number']
                response['active_test_type'] = speedtest['active_test_type']
                response['result'] = 'failure'
                response['error_code'] = '200'
            jsonresponse['rmno:femto_nv'] = response

        except (Exception, psycopg2.Error) as error :
            if(connection):
                print("Failed to execute db query", error)
                return Response(error)

        finally:
            #closing database connection.
            if(connection):
                cursor.close()
                connection.close()
                print("PostgreSQL connection is closed")
    return Response(jsonresponse)


def check_ap_status(macaddress):
        try:
            connection = psycopg2.connect(user=os.environ['POSTGRES_USER'],
                                  password=os.environ['POSTGRES_PASSWORD'],
                                  host=os.environ['POSTGRES_HOST'],
                                  port=os.environ['POSTGRES_PORT'],
                                  database=os.environ['WLC_DBNAME'])
            check_ap_status_query = "select status from ap_location_map where macaddress = %s"
            cursor = connection.cursor()
            cursor.execute(check_ap_status_query, (macaddress,))
            count = cursor.rowcount
            status = 'na'
            if count == 1:
                rows = cursor.fetchone()
                status = rows[0]
        except (Exception, psycopg2.Error) as error :
            if(connection):
                print("Failed to check_ap_status", error)
        finally:
            #closing database connection.
            if(connection):
                cursor.close()
                connection.close()
                print("PostgreSQL connection is closed")
            return status