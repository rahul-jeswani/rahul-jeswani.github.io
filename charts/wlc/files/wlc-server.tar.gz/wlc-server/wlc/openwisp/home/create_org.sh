#!/bin/bash
. /home/openwisp/openwrt.env
export PGPASSWORD=$POSTGRES_PASSWORD
#on_logmsg="`date +'%Y-%m-%dT%H:%M:%SZ%z'`:Openwisp:`basename $0`"

function logmessage {
   echo "`date +'%Y-%m-%dT%H:%M:%S%Z%z'` $1 [OpenWISP: `basename $0`] $2"
}

count=$(psql -X -A -U ${OPENWISP_DBUSER} -d ${OPENWISP_DBNAME} -h ${POSTGRES_HOST} -t -c "select count(*) from openwisp_users_organization where name='Rakuten'")
if [ $count -eq 0 ]
then
    logmessage "info" "Org is not present , being created"
    bash create_org_i.sh &
else
    logmessage "info" "Org is present , shared secret are being updated"
    update=$(psql -X -A -U ${OPENWISP_DBUSER} -d ${OPENWISP_DBNAME} -h ${POSTGRES_HOST} -t -c "update config_organizationconfigsettings set shared_secret='$shared_secret' where organization_id=(select id from openwisp_users_organization where name='Rakuten' )" 2>/dev/null)

    if [ "$update" == "UPDATE 0" ]
    then 
        logmesage "info" "update failed"
    else
        logmessage "info" "update successful"
    fi
fi
