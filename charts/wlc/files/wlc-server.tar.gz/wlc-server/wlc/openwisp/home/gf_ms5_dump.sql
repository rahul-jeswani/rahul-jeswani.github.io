--
-- PostgreSQL database dump
--

-- Dumped from database version 10.8 (Debian 10.8-1.pgdg90+1)
-- Dumped by pg_dump version 10.8 (Debian 10.8-1.pgdg90+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: alert; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alert (
    id integer NOT NULL,
    version bigint NOT NULL,
    dashboard_id bigint NOT NULL,
    panel_id bigint NOT NULL,
    org_id bigint NOT NULL,
    name character varying(255) NOT NULL,
    message text NOT NULL,
    state character varying(190) NOT NULL,
    settings text NOT NULL,
    frequency bigint NOT NULL,
    handler bigint NOT NULL,
    severity text NOT NULL,
    silenced boolean NOT NULL,
    execution_error text NOT NULL,
    eval_data text,
    eval_date timestamp without time zone,
    new_state_date timestamp without time zone NOT NULL,
    state_changes integer NOT NULL,
    created timestamp without time zone NOT NULL,
    updated timestamp without time zone NOT NULL,
    "for" bigint
);


ALTER TABLE public.alert OWNER TO postgres;

--
-- Name: alert_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.alert_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.alert_id_seq OWNER TO postgres;

--
-- Name: alert_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.alert_id_seq OWNED BY public.alert.id;


--
-- Name: alert_notification; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alert_notification (
    id integer NOT NULL,
    org_id bigint NOT NULL,
    name character varying(190) NOT NULL,
    type character varying(255) NOT NULL,
    settings text NOT NULL,
    created timestamp without time zone NOT NULL,
    updated timestamp without time zone NOT NULL,
    is_default boolean DEFAULT false NOT NULL,
    frequency bigint,
    send_reminder boolean DEFAULT false,
    disable_resolve_message boolean DEFAULT false NOT NULL,
    uid character varying(40)
);


ALTER TABLE public.alert_notification OWNER TO postgres;

--
-- Name: alert_notification_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.alert_notification_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.alert_notification_id_seq OWNER TO postgres;

--
-- Name: alert_notification_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.alert_notification_id_seq OWNED BY public.alert_notification.id;


--
-- Name: alert_notification_state; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alert_notification_state (
    id integer NOT NULL,
    org_id bigint NOT NULL,
    alert_id bigint NOT NULL,
    notifier_id bigint NOT NULL,
    state character varying(50) NOT NULL,
    version bigint NOT NULL,
    updated_at bigint NOT NULL,
    alert_rule_state_updated_version bigint NOT NULL
);


ALTER TABLE public.alert_notification_state OWNER TO postgres;

--
-- Name: alert_notification_state_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.alert_notification_state_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.alert_notification_state_id_seq OWNER TO postgres;

--
-- Name: alert_notification_state_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.alert_notification_state_id_seq OWNED BY public.alert_notification_state.id;


--
-- Name: alert_rule_tag; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alert_rule_tag (
    alert_id bigint NOT NULL,
    tag_id bigint NOT NULL
);


ALTER TABLE public.alert_rule_tag OWNER TO postgres;

--
-- Name: annotation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.annotation (
    id integer NOT NULL,
    org_id bigint NOT NULL,
    alert_id bigint,
    user_id bigint,
    dashboard_id bigint,
    panel_id bigint,
    category_id bigint,
    type character varying(25) NOT NULL,
    title text NOT NULL,
    text text NOT NULL,
    metric character varying(255),
    prev_state character varying(25) NOT NULL,
    new_state character varying(25) NOT NULL,
    data text NOT NULL,
    epoch bigint NOT NULL,
    region_id bigint DEFAULT 0,
    tags character varying(500),
    created bigint DEFAULT 0,
    updated bigint DEFAULT 0,
    epoch_end bigint DEFAULT 0 NOT NULL
);


ALTER TABLE public.annotation OWNER TO postgres;

--
-- Name: annotation_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.annotation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.annotation_id_seq OWNER TO postgres;

--
-- Name: annotation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.annotation_id_seq OWNED BY public.annotation.id;


--
-- Name: annotation_tag; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.annotation_tag (
    annotation_id bigint NOT NULL,
    tag_id bigint NOT NULL
);


ALTER TABLE public.annotation_tag OWNER TO postgres;

--
-- Name: api_key; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.api_key (
    id integer NOT NULL,
    org_id bigint NOT NULL,
    name character varying(190) NOT NULL,
    key character varying(190) NOT NULL,
    role character varying(255) NOT NULL,
    created timestamp without time zone NOT NULL,
    updated timestamp without time zone NOT NULL,
    expires bigint
);


ALTER TABLE public.api_key OWNER TO postgres;

--
-- Name: api_key_id_seq1; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.api_key_id_seq1
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.api_key_id_seq1 OWNER TO postgres;

--
-- Name: api_key_id_seq1; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.api_key_id_seq1 OWNED BY public.api_key.id;


--
-- Name: cache_data; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cache_data (
    cache_key character varying(168) NOT NULL,
    data bytea NOT NULL,
    expires integer NOT NULL,
    created_at integer NOT NULL
);


ALTER TABLE public.cache_data OWNER TO postgres;

--
-- Name: dashboard; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dashboard (
    id integer NOT NULL,
    version integer NOT NULL,
    slug character varying(189) NOT NULL,
    title character varying(189) NOT NULL,
    data text NOT NULL,
    org_id bigint NOT NULL,
    created timestamp without time zone NOT NULL,
    updated timestamp without time zone NOT NULL,
    updated_by integer,
    created_by integer,
    gnet_id bigint,
    plugin_id character varying(189),
    folder_id bigint DEFAULT 0 NOT NULL,
    is_folder boolean DEFAULT false NOT NULL,
    has_acl boolean DEFAULT false NOT NULL,
    uid character varying(40)
);


ALTER TABLE public.dashboard OWNER TO postgres;

--
-- Name: dashboard_acl; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dashboard_acl (
    id integer NOT NULL,
    org_id bigint NOT NULL,
    dashboard_id bigint NOT NULL,
    user_id bigint,
    team_id bigint,
    permission smallint DEFAULT 4 NOT NULL,
    role character varying(20),
    created timestamp without time zone NOT NULL,
    updated timestamp without time zone NOT NULL
);


ALTER TABLE public.dashboard_acl OWNER TO postgres;

--
-- Name: dashboard_acl_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.dashboard_acl_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dashboard_acl_id_seq OWNER TO postgres;

--
-- Name: dashboard_acl_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.dashboard_acl_id_seq OWNED BY public.dashboard_acl.id;


--
-- Name: dashboard_id_seq1; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.dashboard_id_seq1
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dashboard_id_seq1 OWNER TO postgres;

--
-- Name: dashboard_id_seq1; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.dashboard_id_seq1 OWNED BY public.dashboard.id;


--
-- Name: dashboard_provisioning; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dashboard_provisioning (
    id integer NOT NULL,
    dashboard_id bigint,
    name character varying(150) NOT NULL,
    external_id text NOT NULL,
    updated integer DEFAULT 0 NOT NULL,
    check_sum character varying(32)
);


ALTER TABLE public.dashboard_provisioning OWNER TO postgres;

--
-- Name: dashboard_provisioning_id_seq1; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.dashboard_provisioning_id_seq1
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dashboard_provisioning_id_seq1 OWNER TO postgres;

--
-- Name: dashboard_provisioning_id_seq1; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.dashboard_provisioning_id_seq1 OWNED BY public.dashboard_provisioning.id;


--
-- Name: dashboard_snapshot; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dashboard_snapshot (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    key character varying(190) NOT NULL,
    delete_key character varying(190) NOT NULL,
    org_id bigint NOT NULL,
    user_id bigint NOT NULL,
    external boolean NOT NULL,
    external_url character varying(255) NOT NULL,
    dashboard text NOT NULL,
    expires timestamp without time zone NOT NULL,
    created timestamp without time zone NOT NULL,
    updated timestamp without time zone NOT NULL,
    external_delete_url character varying(255)
);


ALTER TABLE public.dashboard_snapshot OWNER TO postgres;

--
-- Name: dashboard_snapshot_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.dashboard_snapshot_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dashboard_snapshot_id_seq OWNER TO postgres;

--
-- Name: dashboard_snapshot_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.dashboard_snapshot_id_seq OWNED BY public.dashboard_snapshot.id;


--
-- Name: dashboard_tag; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dashboard_tag (
    id integer NOT NULL,
    dashboard_id bigint NOT NULL,
    term character varying(50) NOT NULL
);


ALTER TABLE public.dashboard_tag OWNER TO postgres;

--
-- Name: dashboard_tag_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.dashboard_tag_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dashboard_tag_id_seq OWNER TO postgres;

--
-- Name: dashboard_tag_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.dashboard_tag_id_seq OWNED BY public.dashboard_tag.id;


--
-- Name: dashboard_version; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dashboard_version (
    id integer NOT NULL,
    dashboard_id bigint NOT NULL,
    parent_version integer NOT NULL,
    restored_from integer NOT NULL,
    version integer NOT NULL,
    created timestamp without time zone NOT NULL,
    created_by bigint NOT NULL,
    message text NOT NULL,
    data text NOT NULL
);


ALTER TABLE public.dashboard_version OWNER TO postgres;

--
-- Name: dashboard_version_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.dashboard_version_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dashboard_version_id_seq OWNER TO postgres;

--
-- Name: dashboard_version_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.dashboard_version_id_seq OWNED BY public.dashboard_version.id;


--
-- Name: data_source; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.data_source (
    id integer NOT NULL,
    org_id bigint NOT NULL,
    version integer NOT NULL,
    type character varying(255) NOT NULL,
    name character varying(190) NOT NULL,
    access character varying(255) NOT NULL,
    url character varying(255) NOT NULL,
    password character varying(255),
    "user" character varying(255),
    database character varying(255),
    basic_auth boolean NOT NULL,
    basic_auth_user character varying(255),
    basic_auth_password character varying(255),
    is_default boolean NOT NULL,
    json_data text,
    created timestamp without time zone NOT NULL,
    updated timestamp without time zone NOT NULL,
    with_credentials boolean DEFAULT false NOT NULL,
    secure_json_data text,
    read_only boolean
);


ALTER TABLE public.data_source OWNER TO postgres;

--
-- Name: data_source_id_seq1; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.data_source_id_seq1
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.data_source_id_seq1 OWNER TO postgres;

--
-- Name: data_source_id_seq1; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.data_source_id_seq1 OWNED BY public.data_source.id;


--
-- Name: login_attempt; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.login_attempt (
    id integer NOT NULL,
    username character varying(190) NOT NULL,
    ip_address character varying(30) NOT NULL,
    created integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.login_attempt OWNER TO postgres;

--
-- Name: login_attempt_id_seq1; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.login_attempt_id_seq1
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.login_attempt_id_seq1 OWNER TO postgres;

--
-- Name: login_attempt_id_seq1; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.login_attempt_id_seq1 OWNED BY public.login_attempt.id;


--
-- Name: migration_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.migration_log (
    id integer NOT NULL,
    migration_id character varying(255) NOT NULL,
    sql text NOT NULL,
    success boolean NOT NULL,
    error text NOT NULL,
    "timestamp" timestamp without time zone NOT NULL
);


ALTER TABLE public.migration_log OWNER TO postgres;

--
-- Name: migration_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.migration_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.migration_log_id_seq OWNER TO postgres;

--
-- Name: migration_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.migration_log_id_seq OWNED BY public.migration_log.id;


--
-- Name: org; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.org (
    id integer NOT NULL,
    version integer NOT NULL,
    name character varying(190) NOT NULL,
    address1 character varying(255),
    address2 character varying(255),
    city character varying(255),
    state character varying(255),
    zip_code character varying(50),
    country character varying(255),
    billing_email character varying(255),
    created timestamp without time zone NOT NULL,
    updated timestamp without time zone NOT NULL
);


ALTER TABLE public.org OWNER TO postgres;

--
-- Name: org_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.org_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.org_id_seq OWNER TO postgres;

--
-- Name: org_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.org_id_seq OWNED BY public.org.id;


--
-- Name: org_user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.org_user (
    id integer NOT NULL,
    org_id bigint NOT NULL,
    user_id bigint NOT NULL,
    role character varying(20) NOT NULL,
    created timestamp without time zone NOT NULL,
    updated timestamp without time zone NOT NULL
);


ALTER TABLE public.org_user OWNER TO postgres;

--
-- Name: org_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.org_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.org_user_id_seq OWNER TO postgres;

--
-- Name: org_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.org_user_id_seq OWNED BY public.org_user.id;


--
-- Name: playlist; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.playlist (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    "interval" character varying(255) NOT NULL,
    org_id bigint NOT NULL
);


ALTER TABLE public.playlist OWNER TO postgres;

--
-- Name: playlist_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.playlist_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.playlist_id_seq OWNER TO postgres;

--
-- Name: playlist_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.playlist_id_seq OWNED BY public.playlist.id;


--
-- Name: playlist_item; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.playlist_item (
    id integer NOT NULL,
    playlist_id bigint NOT NULL,
    type character varying(255) NOT NULL,
    value text NOT NULL,
    title text NOT NULL,
    "order" integer NOT NULL
);


ALTER TABLE public.playlist_item OWNER TO postgres;

--
-- Name: playlist_item_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.playlist_item_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.playlist_item_id_seq OWNER TO postgres;

--
-- Name: playlist_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.playlist_item_id_seq OWNED BY public.playlist_item.id;


--
-- Name: plugin_setting; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.plugin_setting (
    id integer NOT NULL,
    org_id bigint,
    plugin_id character varying(190) NOT NULL,
    enabled boolean NOT NULL,
    pinned boolean NOT NULL,
    json_data text,
    secure_json_data text,
    created timestamp without time zone NOT NULL,
    updated timestamp without time zone NOT NULL,
    plugin_version character varying(50)
);


ALTER TABLE public.plugin_setting OWNER TO postgres;

--
-- Name: plugin_setting_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.plugin_setting_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.plugin_setting_id_seq OWNER TO postgres;

--
-- Name: plugin_setting_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.plugin_setting_id_seq OWNED BY public.plugin_setting.id;


--
-- Name: preferences; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.preferences (
    id integer NOT NULL,
    org_id bigint NOT NULL,
    user_id bigint NOT NULL,
    version integer NOT NULL,
    home_dashboard_id bigint NOT NULL,
    timezone character varying(50) NOT NULL,
    theme character varying(20) NOT NULL,
    created timestamp without time zone NOT NULL,
    updated timestamp without time zone NOT NULL,
    team_id bigint
);


ALTER TABLE public.preferences OWNER TO postgres;

--
-- Name: preferences_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.preferences_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.preferences_id_seq OWNER TO postgres;

--
-- Name: preferences_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.preferences_id_seq OWNED BY public.preferences.id;


--
-- Name: quota; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quota (
    id integer NOT NULL,
    org_id bigint,
    user_id bigint,
    target character varying(190) NOT NULL,
    "limit" bigint NOT NULL,
    created timestamp without time zone NOT NULL,
    updated timestamp without time zone NOT NULL
);


ALTER TABLE public.quota OWNER TO postgres;

--
-- Name: quota_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.quota_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.quota_id_seq OWNER TO postgres;

--
-- Name: quota_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.quota_id_seq OWNED BY public.quota.id;


--
-- Name: server_lock; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.server_lock (
    id integer NOT NULL,
    operation_uid character varying(100) NOT NULL,
    version bigint NOT NULL,
    last_execution bigint NOT NULL
);


ALTER TABLE public.server_lock OWNER TO postgres;

--
-- Name: server_lock_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.server_lock_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.server_lock_id_seq OWNER TO postgres;

--
-- Name: server_lock_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.server_lock_id_seq OWNED BY public.server_lock.id;


--
-- Name: session; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.session (
    key character(16) NOT NULL,
    data bytea NOT NULL,
    expiry integer NOT NULL
);


ALTER TABLE public.session OWNER TO postgres;

--
-- Name: star; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.star (
    id integer NOT NULL,
    user_id bigint NOT NULL,
    dashboard_id bigint NOT NULL
);


ALTER TABLE public.star OWNER TO postgres;

--
-- Name: star_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.star_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.star_id_seq OWNER TO postgres;

--
-- Name: star_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.star_id_seq OWNED BY public.star.id;


--
-- Name: tag; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tag (
    id integer NOT NULL,
    key character varying(100) NOT NULL,
    value character varying(100) NOT NULL
);


ALTER TABLE public.tag OWNER TO postgres;

--
-- Name: tag_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tag_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tag_id_seq OWNER TO postgres;

--
-- Name: tag_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tag_id_seq OWNED BY public.tag.id;


--
-- Name: team; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.team (
    id integer NOT NULL,
    name character varying(190) NOT NULL,
    org_id bigint NOT NULL,
    created timestamp without time zone NOT NULL,
    updated timestamp without time zone NOT NULL,
    email character varying(190)
);


ALTER TABLE public.team OWNER TO postgres;

--
-- Name: team_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.team_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.team_id_seq OWNER TO postgres;

--
-- Name: team_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.team_id_seq OWNED BY public.team.id;


--
-- Name: team_member; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.team_member (
    id integer NOT NULL,
    org_id bigint NOT NULL,
    team_id bigint NOT NULL,
    user_id bigint NOT NULL,
    created timestamp without time zone NOT NULL,
    updated timestamp without time zone NOT NULL,
    external boolean,
    permission smallint
);


ALTER TABLE public.team_member OWNER TO postgres;

--
-- Name: team_member_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.team_member_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.team_member_id_seq OWNER TO postgres;

--
-- Name: team_member_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.team_member_id_seq OWNED BY public.team_member.id;


--
-- Name: temp_user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.temp_user (
    id integer NOT NULL,
    org_id bigint NOT NULL,
    version integer NOT NULL,
    email character varying(190) NOT NULL,
    name character varying(255),
    role character varying(20),
    code character varying(190) NOT NULL,
    status character varying(20) NOT NULL,
    invited_by_user_id bigint,
    email_sent boolean NOT NULL,
    email_sent_on timestamp without time zone,
    remote_addr character varying(255),
    created timestamp without time zone NOT NULL,
    updated timestamp without time zone NOT NULL
);


ALTER TABLE public.temp_user OWNER TO postgres;

--
-- Name: temp_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.temp_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.temp_user_id_seq OWNER TO postgres;

--
-- Name: temp_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.temp_user_id_seq OWNED BY public.temp_user.id;


--
-- Name: test_data; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.test_data (
    id integer NOT NULL,
    metric1 character varying(20),
    metric2 character varying(150),
    value_big_int bigint,
    value_double double precision,
    value_float real,
    value_int integer,
    time_epoch bigint NOT NULL,
    time_date_time timestamp without time zone NOT NULL,
    time_time_stamp timestamp without time zone NOT NULL
);


ALTER TABLE public.test_data OWNER TO postgres;

--
-- Name: test_data_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.test_data_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.test_data_id_seq OWNER TO postgres;

--
-- Name: test_data_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.test_data_id_seq OWNED BY public.test_data.id;


--
-- Name: user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."user" (
    id integer NOT NULL,
    version integer NOT NULL,
    login character varying(190) NOT NULL,
    email character varying(190) NOT NULL,
    name character varying(255),
    password character varying(255),
    salt character varying(50),
    rands character varying(50),
    company character varying(255),
    org_id bigint NOT NULL,
    is_admin boolean NOT NULL,
    email_verified boolean,
    theme character varying(255),
    created timestamp without time zone NOT NULL,
    updated timestamp without time zone NOT NULL,
    help_flags1 bigint DEFAULT 0 NOT NULL,
    last_seen_at timestamp without time zone,
    is_disabled boolean DEFAULT false NOT NULL
);


ALTER TABLE public."user" OWNER TO postgres;

--
-- Name: user_auth; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_auth (
    id integer NOT NULL,
    user_id bigint NOT NULL,
    auth_module character varying(190) NOT NULL,
    auth_id character varying(190) NOT NULL,
    created timestamp without time zone NOT NULL,
    o_auth_access_token text,
    o_auth_refresh_token text,
    o_auth_token_type text,
    o_auth_expiry timestamp without time zone
);


ALTER TABLE public.user_auth OWNER TO postgres;

--
-- Name: user_auth_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_auth_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_auth_id_seq OWNER TO postgres;

--
-- Name: user_auth_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_auth_id_seq OWNED BY public.user_auth.id;


--
-- Name: user_auth_token; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_auth_token (
    id integer NOT NULL,
    user_id bigint NOT NULL,
    auth_token character varying(100) NOT NULL,
    prev_auth_token character varying(100) NOT NULL,
    user_agent character varying(255) NOT NULL,
    client_ip character varying(255) NOT NULL,
    auth_token_seen boolean NOT NULL,
    seen_at integer,
    rotated_at integer NOT NULL,
    created_at integer NOT NULL,
    updated_at integer NOT NULL
);


ALTER TABLE public.user_auth_token OWNER TO postgres;

--
-- Name: user_auth_token_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_auth_token_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_auth_token_id_seq OWNER TO postgres;

--
-- Name: user_auth_token_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_auth_token_id_seq OWNED BY public.user_auth_token.id;


--
-- Name: user_id_seq1; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_id_seq1
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_id_seq1 OWNER TO postgres;

--
-- Name: user_id_seq1; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_id_seq1 OWNED BY public."user".id;


--
-- Name: alert id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alert ALTER COLUMN id SET DEFAULT nextval('public.alert_id_seq'::regclass);


--
-- Name: alert_notification id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alert_notification ALTER COLUMN id SET DEFAULT nextval('public.alert_notification_id_seq'::regclass);


--
-- Name: alert_notification_state id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alert_notification_state ALTER COLUMN id SET DEFAULT nextval('public.alert_notification_state_id_seq'::regclass);


--
-- Name: annotation id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.annotation ALTER COLUMN id SET DEFAULT nextval('public.annotation_id_seq'::regclass);


--
-- Name: api_key id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_key ALTER COLUMN id SET DEFAULT nextval('public.api_key_id_seq1'::regclass);


--
-- Name: dashboard id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dashboard ALTER COLUMN id SET DEFAULT nextval('public.dashboard_id_seq1'::regclass);


--
-- Name: dashboard_acl id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dashboard_acl ALTER COLUMN id SET DEFAULT nextval('public.dashboard_acl_id_seq'::regclass);


--
-- Name: dashboard_provisioning id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dashboard_provisioning ALTER COLUMN id SET DEFAULT nextval('public.dashboard_provisioning_id_seq1'::regclass);


--
-- Name: dashboard_snapshot id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dashboard_snapshot ALTER COLUMN id SET DEFAULT nextval('public.dashboard_snapshot_id_seq'::regclass);


--
-- Name: dashboard_tag id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dashboard_tag ALTER COLUMN id SET DEFAULT nextval('public.dashboard_tag_id_seq'::regclass);


--
-- Name: dashboard_version id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dashboard_version ALTER COLUMN id SET DEFAULT nextval('public.dashboard_version_id_seq'::regclass);


--
-- Name: data_source id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.data_source ALTER COLUMN id SET DEFAULT nextval('public.data_source_id_seq1'::regclass);


--
-- Name: login_attempt id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.login_attempt ALTER COLUMN id SET DEFAULT nextval('public.login_attempt_id_seq1'::regclass);


--
-- Name: migration_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.migration_log ALTER COLUMN id SET DEFAULT nextval('public.migration_log_id_seq'::regclass);


--
-- Name: org id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.org ALTER COLUMN id SET DEFAULT nextval('public.org_id_seq'::regclass);


--
-- Name: org_user id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.org_user ALTER COLUMN id SET DEFAULT nextval('public.org_user_id_seq'::regclass);


--
-- Name: playlist id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.playlist ALTER COLUMN id SET DEFAULT nextval('public.playlist_id_seq'::regclass);


--
-- Name: playlist_item id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.playlist_item ALTER COLUMN id SET DEFAULT nextval('public.playlist_item_id_seq'::regclass);


--
-- Name: plugin_setting id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plugin_setting ALTER COLUMN id SET DEFAULT nextval('public.plugin_setting_id_seq'::regclass);


--
-- Name: preferences id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.preferences ALTER COLUMN id SET DEFAULT nextval('public.preferences_id_seq'::regclass);


--
-- Name: quota id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quota ALTER COLUMN id SET DEFAULT nextval('public.quota_id_seq'::regclass);


--
-- Name: server_lock id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.server_lock ALTER COLUMN id SET DEFAULT nextval('public.server_lock_id_seq'::regclass);


--
-- Name: star id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.star ALTER COLUMN id SET DEFAULT nextval('public.star_id_seq'::regclass);


--
-- Name: tag id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tag ALTER COLUMN id SET DEFAULT nextval('public.tag_id_seq'::regclass);


--
-- Name: team id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.team ALTER COLUMN id SET DEFAULT nextval('public.team_id_seq'::regclass);


--
-- Name: team_member id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.team_member ALTER COLUMN id SET DEFAULT nextval('public.team_member_id_seq'::regclass);


--
-- Name: temp_user id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.temp_user ALTER COLUMN id SET DEFAULT nextval('public.temp_user_id_seq'::regclass);


--
-- Name: test_data id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_data ALTER COLUMN id SET DEFAULT nextval('public.test_data_id_seq'::regclass);


--
-- Name: user id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."user" ALTER COLUMN id SET DEFAULT nextval('public.user_id_seq1'::regclass);


--
-- Name: user_auth id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_auth ALTER COLUMN id SET DEFAULT nextval('public.user_auth_id_seq'::regclass);


--
-- Name: user_auth_token id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_auth_token ALTER COLUMN id SET DEFAULT nextval('public.user_auth_token_id_seq'::regclass);


--
-- Data for Name: alert; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.alert (id, version, dashboard_id, panel_id, org_id, name, message, state, settings, frequency, handler, severity, silenced, execution_error, eval_data, eval_date, new_state_date, state_changes, created, updated, "for") FROM stdin;
\.


--
-- Data for Name: alert_notification; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.alert_notification (id, org_id, name, type, settings, created, updated, is_default, frequency, send_reminder, disable_resolve_message, uid) FROM stdin;
\.


--
-- Data for Name: alert_notification_state; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.alert_notification_state (id, org_id, alert_id, notifier_id, state, version, updated_at, alert_rule_state_updated_version) FROM stdin;
\.


--
-- Data for Name: alert_rule_tag; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.alert_rule_tag (alert_id, tag_id) FROM stdin;
\.


--
-- Data for Name: annotation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.annotation (id, org_id, alert_id, user_id, dashboard_id, panel_id, category_id, type, title, text, metric, prev_state, new_state, data, epoch, region_id, tags, created, updated, epoch_end) FROM stdin;
\.


--
-- Data for Name: annotation_tag; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.annotation_tag (annotation_id, tag_id) FROM stdin;
\.


--
-- Data for Name: api_key; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.api_key (id, org_id, name, key, role, created, updated, expires) FROM stdin;
1	1	OpenNMS	3f7bf5ef7f9572e74c4cc8d5702cea308f36d70efd08674a06ea38b99164a3112b9f25640ce4980ac3ff084ecacca265fb00	Viewer	2019-09-09 18:06:36	2019-09-09 18:06:36	\N
\.


--
-- Data for Name: cache_data; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cache_data (cache_key, data, expires, created_at) FROM stdin;
\.


--
-- Data for Name: dashboard; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dashboard (id, version, slug, title, data, org_id, created, updated, updated_by, created_by, gnet_id, plugin_id, folder_id, is_folder, has_acl, uid) FROM stdin;
14	5	ap-dashboard	AP DASHBOARD	{"annotations":{"list":[{"builtIn":1,"datasource":"-- Grafana --","enable":true,"hide":true,"iconColor":"rgba(0, 211, 255, 1)","name":"Annotations \\u0026 Alerts","type":"dashboard"}]},"editable":true,"gnetId":null,"graphTooltip":0,"id":14,"iteration":1579617582215,"links":[],"panels":[{"aliasColors":{},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":8,"w":12,"x":0,"y":0},"hiddenSeries":false,"id":10,"legend":{"avg":false,"current":false,"max":false,"min":false,"show":false,"total":false,"values":false},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"sum","alias":"$tag_aphost","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","metric":"ap.loc.bandwidth","refId":"A","tags":{"aphost":"*","building":"$Building","floor":"$Floor","site":"$Site"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"APs by Utilization","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"short","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":8,"w":12,"x":12,"y":0},"hiddenSeries":false,"id":6,"legend":{"avg":false,"current":false,"max":false,"min":false,"rightSide":true,"show":false,"total":true,"values":true},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"sum","alias":"$tag_aphost","counterTop":"10","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.traffic","refId":"A","shouldComputeTopN":true,"tags":{"aphost":"*","building":"$Building","floor":"$Floor","site":"$Site","type":"ap"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"APs by Traffic","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"decbytes","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":9,"w":12,"x":0,"y":8},"hiddenSeries":false,"id":8,"legend":{"avg":false,"current":false,"max":false,"min":false,"rightSide":true,"show":false,"total":true,"values":true},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"count","alias":"$tag_aphost","counterTop":"10","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.association","refId":"A","shouldComputeTopN":true,"tags":{"aphost":"*","building":"$Building","floor":"$Floor","site":"$Site","status":"success","type":"network"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"APs By Associations","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"short","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{},"breakPoint":"50%","cacheTimeout":null,"combine":{"label":"Others","threshold":0},"datasource":"OpenTSDB","fontSize":"80%","format":"short","gridPos":{"h":9,"w":12,"x":12,"y":8},"id":2,"interval":null,"legend":{"show":true,"values":true},"legendType":"Under graph","links":[],"maxDataPoints":3,"nullPointMode":"connected","options":{},"pieType":"pie","strokeWidth":1,"targets":[{"aggregator":"count","alias":"$tag_ssid_security","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.traffic","refId":"A","tags":{"building":"$Building","floor":"$Floor","site":"$Site","ssid_security":"*","type":"ssid"}}],"timeFrom":null,"timeShift":null,"title":"Security Distribution","type":"grafana-piechart-panel","valueName":"current"},{"aliasColors":{},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":9,"w":12,"x":0,"y":17},"hiddenSeries":false,"id":4,"legend":{"avg":false,"current":false,"max":false,"min":false,"rightSide":true,"show":false,"total":false,"values":false},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"avg","alias":"$tag_aphost","counterTop":"10","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.datarate","refId":"A","shouldComputeTopN":true,"tags":{"aphost":"*","building":"$Building","floor":"$Floor","site":"$Site","type":"ap"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"APs By Data Rate","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"decbytes","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}}],"refresh":"","schemaVersion":19,"style":"dark","tags":["OpenNMS"],"templating":{"list":[{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.datarate,site)","hide":0,"includeAll":true,"label":"Site","multi":false,"name":"Site","options":[],"query":"tag_values(clt.loc.datarate,site)","refresh":1,"regex":"","skipUrlSync":false,"sort":1,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.datarate,building,site=$Site)","hide":0,"includeAll":true,"label":"Building","multi":false,"name":"Building","options":[],"query":"tag_values(clt.loc.datarate,building,site=$Site)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.datarate,floor)","hide":0,"includeAll":true,"label":"Floor","multi":false,"name":"Floor","options":[],"query":"tag_values(clt.loc.datarate,floor)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"auto":false,"auto_count":30,"auto_min":"10s","current":{"text":"1hr","value":"1hr"},"hide":0,"label":null,"name":"Time","options":[{"selected":true,"text":"1hr","value":"1hr"},{"selected":false,"text":"2hr","value":"2hr"},{"selected":false,"text":"4hr","value":"4hr"},{"selected":false,"text":"8hr","value":"8hr"},{"selected":false,"text":"12hr","value":"12hr"}],"query":"1hr,2hr,4hr,8hr,12hr,","refresh":2,"skipUrlSync":false,"type":"interval"}]},"time":{"from":"now-90d","to":"now"},"timepicker":{"refresh_intervals":["5s","10s","30s","1m","5m","15m","30m","1h","2h","1d"]},"timezone":"","title":"AP DASHBOARD","uid":"pMMRvzhWz","version":5}	1	2020-01-21 14:35:14	2020-01-21 14:40:06	1	1	0		0	f	f	pMMRvzhWz
16	5	network-dashboard	NETWORK DASHBOARD	{"annotations":{"list":[{"builtIn":1,"datasource":"-- Grafana --","enable":true,"hide":true,"iconColor":"rgba(0, 211, 255, 1)","name":"Annotations \\u0026 Alerts","type":"dashboard"}]},"editable":true,"gnetId":null,"graphTooltip":0,"id":16,"iteration":1579617627575,"links":[],"panels":[{"aliasColors":{},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":6,"w":12,"x":0,"y":0},"hiddenSeries":false,"id":18,"legend":{"avg":false,"current":false,"max":false,"min":false,"show":false,"total":false,"values":false},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"sum","alias":"$tag_aphost","counterTop":"10","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.datarate","refId":"A","shouldComputeTopN":true,"tags":{"macid":"*"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"CLIENT HEALTH METRIC, POSITION, PROFILE","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":true,"values":["total"]},"yaxes":[{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":6,"w":12,"x":12,"y":0},"hiddenSeries":false,"id":8,"legend":{"avg":false,"current":false,"max":false,"min":false,"show":true,"total":true,"values":true},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"sum","alias":"$tag_aphost","counterTop":"10","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.traffic","refId":"A","shouldComputeTopN":true,"tags":{"building":"$Building","floor":"$Floor","site":"$Site","ssid":"*","type":"ssid"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Data transfer By SSID","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"short","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":6,"w":12,"x":0,"y":6},"hiddenSeries":false,"id":22,"legend":{"alignAsTable":false,"avg":false,"current":false,"max":false,"min":false,"rightSide":true,"show":true,"total":true,"values":true},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"sum","alias":"$tag_site","counterTop":"10","currentTagKey":"type","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.smartdevice","refId":"A","shouldComputeTopN":true,"tags":{"building":"$Building","floor":"$Floor","site":"$Site"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Location by APs","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"short","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{},"bars":false,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":6,"w":12,"x":12,"y":6},"hiddenSeries":false,"id":4,"legend":{"avg":true,"current":false,"max":false,"min":false,"show":false,"total":false,"values":true},"lines":true,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":true,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"avg","alias":"$tag_ssid","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","metric":"clt.loc.datarate","refId":"A","tags":{"building":"$Building","floor":"$Floor","site":"$Site","ssid":"$SSID"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"AP Data Transfer Trend","tooltip":{"shared":true,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"time","name":null,"show":true,"values":[]},"yaxes":[{"format":"decbytes","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":6,"w":12,"x":0,"y":12},"hiddenSeries":false,"id":14,"legend":{"alignAsTable":false,"avg":false,"current":false,"max":false,"min":false,"rightSide":true,"show":false,"sideWidth":null,"total":false,"values":false},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"avg","alias":"$tag_site","counterTop":"10","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.traffic","refId":"A","shouldComputeTopN":true,"tags":{"aphost":"*","building":"$Building","floor":"$Floor","site":"$Site","ssid":"$SSID","type":"client"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Average Data Transfer","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"decbytes","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{},"breakPoint":"50%","cacheTimeout":null,"combine":{"label":"Others","threshold":0},"datasource":"OpenTSDB","fontSize":"80%","format":"short","gridPos":{"h":6,"w":12,"x":12,"y":12},"id":6,"interval":null,"legend":{"show":true,"values":true},"legendType":"Under graph","links":[],"maxDataPoints":3,"nullPointMode":"connected","options":{},"pieType":"pie","strokeWidth":1,"targets":[{"aggregator":"sum","currentTagKey":"ssid","currentTagValue":"Rakuten-PPP","downsampleAggregator":"avg","downsampleFillPolicy":"none","metric":"clt.loc.smartdevice","refId":"A","tags":{"building":"$Building","client_type":"*","floor":"$Floor"}}],"timeFrom":null,"timeShift":null,"title":"Smart Device Association By SSID","type":"grafana-piechart-panel","valueName":"current"},{"aliasColors":{},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":6,"w":12,"x":0,"y":18},"hiddenSeries":false,"id":12,"legend":{"alignAsTable":false,"avg":false,"current":false,"max":false,"min":false,"rightSide":true,"show":false,"total":true,"values":true},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"count","alias":"$tag_site","counterTop":"10","currentTagKey":"ssid","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.association","refId":"A","shouldComputeTopN":true,"tags":{"building":"$Building","floor":"$Floor","site":"$Site","status":"success","type":"network"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Locations By Associations","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"short","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{},"bars":false,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":6,"w":12,"x":12,"y":18},"hiddenSeries":false,"id":2,"legend":{"alignAsTable":false,"avg":false,"current":false,"max":false,"min":false,"rightSide":false,"show":false,"total":false,"values":false},"lines":true,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"count","alias":"$tag_aphost","counterTop":"10","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.association","refId":"A","shouldComputeTopN":false,"tags":{"status":"success","type":"network"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Association Trend","tooltip":{"shared":true,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"time","name":null,"show":true,"values":[]},"yaxes":[{"format":"short","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{},"breakPoint":"50%","cacheTimeout":null,"combine":{"label":"Others","threshold":0},"datasource":"OpenTSDB","fontSize":"80%","format":"short","gridPos":{"h":6,"w":12,"x":0,"y":24},"id":10,"interval":null,"legend":{"show":true,"values":true},"legendType":"Under graph","links":[],"maxDataPoints":3,"nullPointMode":"connected","options":{},"pieType":"pie","strokeWidth":1,"targets":[{"aggregator":"avg","alias":"$tag_macid","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.smartdevice","refId":"A","tags":{"building":"$Building","floor":"$Floor","site":"$Site","ssid":"*","type":"network"}}],"timeFrom":null,"timeShift":null,"title":"Average Associations By SSID","type":"grafana-piechart-panel","valueName":"current"},{"aliasColors":{},"bars":false,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":6,"w":12,"x":12,"y":24},"hiddenSeries":false,"id":20,"legend":{"avg":false,"current":false,"max":false,"min":false,"show":true,"total":false,"values":false},"lines":true,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"sum","alias":"$tag_aphost","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"ap.loc.apstatus","refId":"A","tags":{"status":"active"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Active APs Trend","tooltip":{"shared":true,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"time","name":null,"show":true,"values":[]},"yaxes":[{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}}],"refresh":false,"schemaVersion":19,"style":"dark","tags":["OpenNMS"],"templating":{"list":[{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,site)","hide":0,"includeAll":true,"label":"Site","multi":false,"name":"Site","options":[],"query":"tag_values(clt.loc.traffic,site)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,building,site=$Site)","hide":0,"includeAll":true,"label":"Building","multi":false,"name":"Building","options":[],"query":"tag_values(clt.loc.traffic,building,site=$Site)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,floor)","hide":0,"includeAll":true,"label":"Floor","multi":false,"name":"Floor","options":[],"query":"tag_values(clt.loc.traffic,floor)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,ssid)","hide":0,"includeAll":true,"label":"SSID","multi":false,"name":"SSID","options":[],"query":"tag_values(clt.loc.traffic,ssid)","refresh":1,"regex":"","skipUrlSync":false,"sort":1,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,macid)","hide":0,"includeAll":true,"label":"Client","multi":false,"name":"Client","options":[],"query":"tag_values(clt.loc.traffic,macid)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"auto":false,"auto_count":30,"auto_min":"10s","current":{"text":"1hr","value":"1hr"},"hide":0,"label":null,"name":"Time","options":[{"selected":true,"text":"1hr","value":"1hr"},{"selected":false,"text":"2hr","value":"2hr"},{"selected":false,"text":"4hr","value":"4hr"},{"selected":false,"text":"8hr","value":"8hr"},{"selected":false,"text":"12hr","value":"12hr"}],"query":"1hr,2hr,4hr,8hr,12hr,","refresh":2,"skipUrlSync":false,"type":"interval"}]},"time":{"from":"now-90d","to":"now"},"timepicker":{"refresh_intervals":["5s","10s","30s","1m","5m","15m","30m","1h","2h","1d"]},"timezone":"","title":"NETWORK DASHBOARD","uid":"iSG-OzhZk","version":5}	1	2020-01-21 14:36:16	2020-01-21 14:40:32	1	1	0		0	f	f	iSG-OzhZk
10	3	connectivity-dashboard	Connectivity Dashboard	{"annotations":{"list":[{"builtIn":1,"datasource":"-- Grafana --","enable":true,"hide":true,"iconColor":"rgba(0, 211, 255, 1)","name":"Annotations \\u0026 Alerts","type":"dashboard"}]},"editable":true,"gnetId":null,"graphTooltip":0,"id":10,"iteration":1579529450534,"links":[],"panels":[{"aliasColors":{"Tried to Connect":"rgba(0, 0, 0, 0.77)","clt.loc.association{type=associated, status=success}":"#1250B0","success":"#5794F2"},"breakPoint":"100%","cacheTimeout":null,"combine":{"label":"Others","threshold":0},"datasource":"OpenTSDB","fontSize":"80%","format":"short","gridPos":{"h":8,"w":4,"x":0,"y":0},"id":6,"interval":null,"legend":{"percentage":false,"show":true,"values":true},"legendType":"Under graph","links":[],"maxDataPoints":3,"nullPointMode":"connected","options":{},"pieType":"donut","strokeWidth":"3","targets":[{"aggregator":"count","alias":"Tried to Connect","currentFilterGroupBy":false,"currentFilterKey":"","currentFilterType":"literal_or","currentFilterValue":"","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"nan","explicitTags":false,"filters":[],"isCounter":false,"metric":"clt.loc.association","refId":"A","shouldComputeRate":false,"shouldComputeTopN":false,"tags":{"status":"*","type":"associated"}}],"timeFrom":null,"timeShift":null,"title":"Total Clients","transparent":true,"type":"grafana-piechart-panel","valueName":"total"},{"aliasColors":{"Associated":"rgba(0, 0, 0, 0.08)","clt.loc.association{type=associated, status=success}":"#1250B0","success":"#5794F2"},"breakPoint":"50%","cacheTimeout":null,"combine":{"label":"Others","threshold":0},"datasource":"OpenTSDB","fontSize":"80%","format":"short","gridPos":{"h":8,"w":4,"x":5,"y":0},"id":11,"interval":null,"legend":{"show":true,"values":true},"legendType":"Under graph","links":[],"maxDataPoints":3,"nullPointMode":"connected","options":{},"pieType":"donut","strokeWidth":1,"targets":[{"aggregator":"count","alias":"Associated","currentFilterGroupBy":false,"currentFilterKey":"","currentFilterType":"literal_or","currentFilterValue":"","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"nan","explicitTags":false,"filters":[],"isCounter":false,"metric":"clt.loc.association","refId":"A","shouldComputeRate":false,"shouldComputeTopN":false,"tags":{"status":"*","type":"associated"}}],"timeFrom":null,"timeShift":null,"title":"Associated","transparent":true,"type":"grafana-piechart-panel","valueName":"current"},{"aliasColors":{"failure":"#FF7383","success":"rgba(0, 0, 0, 0.08)"},"breakPoint":"50%","cacheTimeout":null,"combine":{"label":"Others","threshold":0},"datasource":"OpenTSDB","fontSize":"80%","format":"short","gridPos":{"h":8,"w":4,"x":10,"y":0},"id":9,"interval":null,"legend":{"show":true,"values":true},"legendType":"Under graph","links":[],"maxDataPoints":3,"nullPointMode":"connected","options":{},"pieType":"donut","strokeWidth":"3","targets":[{"aggregator":"sum","alias":"$tag_status","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","metric":"clt.loc.association","refId":"A","shouldComputeRate":false,"tags":{"type":"associated"}}],"timeFrom":null,"timeShift":null,"title":"Authenticated","transparent":true,"type":"grafana-piechart-panel","valueName":"current"},{"aliasColors":{"failure":"#F2495C","success":"rgba(0, 0, 0, 0.09)"},"breakPoint":"50%","cacheTimeout":null,"combine":{"label":"Others","threshold":0},"datasource":"OpenTSDB","fontSize":"80%","format":"short","gridPos":{"h":8,"w":4,"x":15,"y":0},"id":8,"interval":null,"legend":{"show":true,"values":true},"legendType":"Under graph","links":[],"maxDataPoints":3,"nullPointMode":"connected","options":{},"pieType":"donut","pluginVersion":"6.5.0-pre","strokeWidth":1,"targets":[{"aggregator":"sum","alias":"success","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","metric":"clt.loc.association","refId":"A","shouldComputeRate":false,"tags":{"type":"associated"}}],"timeFrom":null,"timeShift":null,"title":"Network","transparent":true,"type":"grafana-piechart-panel","valueName":"total"},{"aliasColors":{"Online":"rgba(0, 0, 0, 0.28)","failure":"#F2495C","success":"#73BF69"},"breakPoint":"50%","cacheTimeout":null,"combine":{"label":"Others","threshold":0},"datasource":"OpenTSDB","fontSize":"80%","format":"short","gridPos":{"h":8,"w":4,"x":20,"y":0},"id":10,"interval":null,"legend":{"show":true,"sortDesc":true,"values":true},"legendType":"Under graph","links":[],"maxDataPoints":3,"nullPointMode":"connected","options":{},"pieType":"donut","strokeWidth":1,"targets":[{"aggregator":"sum","alias":"Online","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","metric":"clt.loc.association","refId":"A","shouldComputeRate":false,"tags":{"type":"associated"}}],"timeFrom":null,"timeShift":null,"title":"Online","transparent":true,"type":"grafana-piechart-panel","valueName":"current"},{"columns":[{"text":"Count","value":"count"}],"datasource":"OpenTSDB","fontSize":"100%","gridPos":{"h":8,"w":12,"x":0,"y":8},"id":15,"options":{},"pageSize":null,"showHeader":true,"sort":{"col":null,"desc":false},"styles":[{"alias":"Time","dateFormat":"YYYY-MM-DD HH:mm:ss","link":false,"pattern":"Time","type":"date"},{"alias":"client_macId","colorMode":null,"colors":["#5794F2","#C4162A","#8AB8FF"],"decimals":2,"link":false,"pattern":"Metric","thresholds":[],"type":"number","unit":"short"},{"alias":"","colorMode":null,"colors":["rgba(245, 54, 54, 0.9)","rgba(237, 129, 40, 0.89)","rgba(50, 172, 45, 0.97)"],"dateFormat":"YYYY-MM-DD HH:mm:ss","decimals":2,"mappingType":1,"pattern":"","thresholds":[],"type":"number","unit":"short"}],"targets":[{"aggregator":"count","alias":"$tag_macid","currentFilterGroupBy":false,"currentFilterKey":"","currentFilterType":"literal_or","currentFilterValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","filters":[{"filter":"$site","groupBy":false,"tagk":"site","type":"literal_or"},{"filter":"$building","groupBy":false,"tagk":"building","type":"literal_or"},{"filter":"$floor","groupBy":false,"tagk":"floor","type":"literal_or"},{"filter":"*","groupBy":true,"tagk":"macid","type":"wildcard"}],"metric":"clt.loc.association","refId":"A"}],"timeFrom":null,"timeShift":null,"title":"Clients by Most Failed Connections","transform":"timeseries_aggregations","type":"table"},{"aliasColors":{},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":8,"w":12,"x":12,"y":8},"hiddenSeries":false,"id":17,"legend":{"avg":false,"current":false,"max":false,"min":false,"show":false,"total":false,"values":false},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"count","alias":"$tag_site","counterTop":"5","currentFilterGroupBy":false,"currentFilterKey":"building","currentFilterType":"literal_or","currentFilterValue":"","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","filters":[{"filter":"$type","groupBy":false,"tagk":"type","type":"literal_or"},{"filter":"$site","groupBy":true,"tagk":"site","type":"literal_or"}],"metric":"clt.loc.association","refId":"A","shouldComputeTopN":true,"tags":{}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Top Locations Affected by Failures","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":true,"values":["total"]},"yaxes":[{"format":"short","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":"0","show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{"UHN1TKY311008":"dark-red"},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":8,"w":12,"x":0,"y":16},"hiddenSeries":false,"id":2,"legend":{"avg":false,"current":false,"max":false,"min":false,"rightSide":true,"show":true,"total":false,"values":false},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"sum","alias":"$tag_macid","counterTop":"10","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","metric":"clt.loc.traffic","refId":"A","shouldComputeTopN":true,"tags":{"building":"$building","floor":"$floor","macid":"*"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Top 10 client by traffic","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"decbytes","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":"0","show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":8,"w":12,"x":12,"y":16},"hiddenSeries":false,"id":4,"legend":{"avg":false,"current":false,"max":false,"min":false,"rightSide":true,"show":true,"total":false,"values":false},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"sum","alias":"$tag_macid","counterTop":"10","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","metric":"ap.mac.session","refId":"A","shouldComputeTopN":true,"tags":{"building":"$building","floor":"$floor","macid":"*"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Top 10 clients by session","tooltip":{"shared":true,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"s","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":"0","show":true}],"yaxis":{"align":false,"alignLevel":null}}],"refresh":false,"schemaVersion":19,"style":"dark","tags":["OpenNMS"],"templating":{"list":[{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,site)","hide":0,"includeAll":true,"label":null,"multi":false,"name":"site","options":[],"query":"tag_values(clt.loc.traffic,site)","refresh":1,"regex":"","skipUrlSync":false,"sort":1,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,building,site=$site)","hide":0,"includeAll":true,"label":"building","multi":false,"name":"building","options":[],"query":"tag_values(clt.loc.traffic,building,site=$site)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,floor)","hide":0,"includeAll":true,"label":"floor","multi":false,"name":"floor","options":[],"query":"tag_values(clt.loc.traffic,floor)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.association,type)","hide":0,"includeAll":true,"label":"type","multi":false,"name":"type","options":[],"query":"tag_values(clt.loc.association,type)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false}]},"time":{"from":"now-30d","to":"now"},"timepicker":{"refresh_intervals":["5s","10s","30s","1m","5m","15m","30m","1h","2h","1d"]},"timezone":"","title":"Connectivity Dashboard","uid":"1kKTUf1Zz","version":3}	1	2020-01-09 13:19:59	2020-01-20 14:10:59	1	1	0		0	f	f	1kKTUf1Zz
9	6	performance-dashboard	Performance Dashboard	{"annotations":{"list":[{"builtIn":1,"datasource":"-- Grafana --","enable":true,"hide":true,"iconColor":"rgba(0, 211, 255, 1)","name":"Annotations \\u0026 Alerts","type":"dashboard"}]},"editable":true,"gnetId":null,"graphTooltip":0,"id":9,"iteration":1579594035262,"links":[],"panels":[{"cacheTimeout":null,"datasource":"OpenTSDB","gridPos":{"h":8,"w":12,"x":0,"y":0},"id":8,"links":[],"options":{"fieldOptions":{"calcs":["sum"],"defaults":{"mappings":[{"id":0,"op":"=","text":"N/A","type":1,"value":"null"}],"max":100,"min":0,"nullValueMode":"connected","thresholds":[{"color":"super-light-blue","value":null},{"color":"red","value":80}],"title":"","unit":"none"},"override":{},"values":false},"orientation":"horizontal","showThresholdLabels":false,"showThresholdMarkers":false},"pluginVersion":"6.4.0-pre","targets":[{"aggregator":"count","alias":"Total Client","currentFilterGroupBy":false,"currentFilterKey":"macid","currentFilterType":"regexp","currentFilterValue":"r.*","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","filters":[],"hide":false,"metric":"ap.client.count","refId":"B","tags":{"type":"ap"}},{"aggregator":"count","alias":"$tag_type","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","hide":false,"metric":"ap.clt.health","refId":"A","tags":{"type":"$type"}}],"timeFrom":null,"timeShift":null,"title":"Client Health","type":"gauge"},{"aliasColors":{"Count":"blue","clt.loc.datarate{site=Chennai, floor=Floor3, type=client, building=SDB5}":"super-light-blue"},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":8,"w":12,"x":12,"y":0},"hiddenSeries":false,"id":2,"legend":{"avg":true,"current":false,"max":false,"min":false,"rightSide":true,"show":false,"total":false,"values":true},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"avg","alias":"","currentFilterGroupBy":false,"currentFilterKey":"","currentFilterType":"literal_or","currentFilterValue":"","currentTagKey":"floor","currentTagValue":"$floor","downsampleAggregator":"avg","downsampleFillPolicy":"none","filters":[{"filter":"$site","groupBy":false,"tagk":"site","type":"literal_or"},{"filter":"$building","groupBy":false,"tagk":"building","type":"literal_or"},{"filter":"$floor","groupBy":false,"tagk":"floor","type":"literal_or"},{"filter":"client","groupBy":false,"tagk":"type","type":"literal_or"}],"metric":"clt.loc.datarate","refId":"A","tags":{}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Clients by Average  Data Rate","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":5,"max":null,"min":0,"mode":"histogram","name":null,"show":true,"values":["total"]},"yaxes":[{"format":"short","label":"No of clients","logBase":1,"max":null,"min":"0","show":true},{"format":"Bps","label":"","logBase":1,"max":null,"min":"0","show":true}],"yaxis":{"align":true,"alignLevel":50}},{"aliasColors":{"Count":"blue","ap.clt.rssi{floor=Floor1}":"semi-dark-blue","ap.clt.rssi{floor=Floor3}":"light-blue"},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":8,"w":12,"x":0,"y":8},"hiddenSeries":false,"id":10,"legend":{"alignAsTable":false,"avg":true,"current":false,"max":false,"min":false,"rightSide":false,"show":false,"total":false,"values":true},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"avg","alias":"","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","metric":"ap.clt.rssi","refId":"A","tags":{"floor":"$floor"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Clients by RSSI","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":5,"max":null,"min":0,"mode":"histogram","name":null,"show":true,"values":["total"]},"yaxes":[{"format":"short","label":"No of clients","logBase":1,"max":null,"min":"0","show":true},{"format":"dBm","label":null,"logBase":1,"max":null,"min":"0","show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{"04-79-70-73-87-ce":"super-light-blue","20-34-fb-81-19-cd":"super-light-green","70-bb-e9-25-1c-bc":"super-light-yellow","a1-3e-0e-5e-80-a1":"super-light-blue","a10-3e-0e-5e-80-a1":"semi-dark-blue","a13-3e-0e-5e-80-a1":"rgb(130, 130, 247)","a14-3e-0e-5e-80-a1":"semi-dark-blue","a16-3e-0e-5e-80-a1":"super-light-blue","a17-3e-0e-5e-80-a1":"blue","a18-3e-0e-5e-80-a1":"light-blue","a24-3e-0e-5e-80-a1":"rgb(4, 49, 120)","a27-3e-0e-5e-80-a1":"dark-blue","a3-3e-0e-5e-80-a1":"light-blue","a37-3e-0e-5e-80-a1":"super-light-blue","a38-3e-0e-5e-80-a1":"super-light-blue","a40-3e-0e-5e-80-a1":"semi-dark-blue","a6-3e-0e-5e-80-a1":"dark-blue","a8-3e-0e-5e-80-a1":"super-light-blue"},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":8,"w":12,"x":12,"y":8},"hiddenSeries":false,"id":4,"legend":{"avg":false,"current":false,"max":false,"min":false,"rightSide":true,"show":true,"total":false,"values":false},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"sum","alias":"$tag_macid","counterTop":"5","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","metric":"clt.loc.traffic","refId":"A","shouldComputeTopN":true,"tags":{"floor":"$floor","macid":"*","ssid":"$ssid"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Clients With Most Traffic","tooltip":{"shared":true,"sort":2,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"decbytes","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":12}},{"aliasColors":{"ap.clt.health{floor=Floor1, type=LowRSSI}":"super-light-blue","ap.clt.health{floor=Floor2, type=LowRSSI}":"light-blue","ap.clt.health{floor=Floor3, type=LowRSSI}":"super-light-blue"},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":8,"w":12,"x":0,"y":16},"hiddenSeries":false,"id":12,"legend":{"avg":false,"current":false,"max":false,"min":false,"rightSide":true,"show":true,"total":false,"values":false},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"count","alias":"$tag_site","counterTop":"5","currentFilterGroupBy":false,"currentFilterKey":"","currentFilterType":"literal_or","currentFilterValue":"","currentTagKey":"","currentTagValue":"","disableDownsampling":false,"downsampleAggregator":"avg","downsampleFillPolicy":"none","filters":[{"filter":"$type","groupBy":false,"tagk":"type","type":"iliteral_or"},{"filter":"*","groupBy":true,"tagk":"site","type":"wildcard"}],"hide":false,"metric":"ap.clt.health","refId":"A","shouldComputeTopN":true,"tags":{}},{"aggregator":"count","alias":"","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","hide":true,"metric":"ap.clt.health","refId":"B","tags":{"floor":"$floor"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Top Locations Affected by Poor Performance","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"short","label":"","logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{"ap.client.count":"super-light-blue","clnt.associate{type=associated}":"dark-blue","clt.loc.traffic":"blue","test.traffic":"light-blue"},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":0,"fillGradient":0,"gridPos":{"h":8,"w":12,"x":12,"y":16},"hiddenSeries":false,"id":16,"legend":{"alignAsTable":true,"avg":false,"current":false,"max":false,"min":false,"rightSide":false,"show":false,"total":false,"values":false},"lines":true,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[{"alias":"clt.loc.traffic","bars":true,"lines":false,"points":false,"yaxis":2},{"alias":"ap.client.count","bars":false,"lines":true,"points":true},{}],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"sum","alias":"","currentTagKey":"","currentTagValue":"","disableDownsampling":false,"downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","hide":false,"metric":"clt.loc.traffic","refId":"A","tags":{}},{"aggregator":"count","downsampleAggregator":"avg","downsampleFillPolicy":"none","hide":false,"metric":"ap.client.count","refId":"C"}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Network Usage","tooltip":{"shared":true,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"time","name":null,"show":true,"values":[]},"yaxes":[{"format":"short","label":"No of clients","logBase":1,"max":null,"min":"0","show":true},{"format":"decbytes","label":"Traffic Volumes","logBase":1,"max":null,"min":"0","show":true}],"yaxis":{"align":false,"alignLevel":4}}],"refresh":false,"schemaVersion":19,"style":"dark","tags":["OpenNMS"],"templating":{"list":[{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,site)","hide":0,"includeAll":true,"label":"site","multi":false,"name":"site","options":[],"query":"tag_values(clt.loc.traffic,site)","refresh":1,"regex":"","skipUrlSync":false,"sort":3,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,building,site=$site)","hide":0,"includeAll":true,"label":"building","multi":false,"name":"building","options":[],"query":"tag_values(clt.loc.traffic,building,site=$site)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.datarate,floor)","hide":0,"includeAll":true,"label":"floor","multi":false,"name":"floor","options":[],"query":"tag_values(clt.loc.datarate,floor)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,ssid)","hide":0,"includeAll":true,"label":"ssid","multi":false,"name":"ssid","options":[],"query":"tag_values(clt.loc.traffic,ssid)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(ap.clt.health,type)","hide":0,"includeAll":true,"label":"type","multi":false,"name":"type","options":[],"query":"tag_values(ap.clt.health,type)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false}]},"time":{"from":"now-30d","to":"now"},"timepicker":{"refresh_intervals":["5s","10s","30s","1m","5m","15m","30m","1h","2h","1d"]},"timezone":"","title":"Performance Dashboard","uid":"ZDLeDT1Zk","version":6}	1	2020-01-09 13:18:04	2020-01-21 08:28:39	1	1	0		0	f	f	ZDLeDT1Zk
15	4	client-dashboard	CLIENT DASHBOARD	{"annotations":{"list":[{"builtIn":1,"datasource":"-- Grafana --","enable":true,"hide":true,"iconColor":"rgba(0, 211, 255, 1)","name":"Annotations \\u0026 Alerts","type":"dashboard"}]},"editable":true,"gnetId":null,"graphTooltip":0,"id":15,"iteration":1579617565344,"links":[],"panels":[{"aliasColors":{"20-34-fb-81-19-cd":"super-light-blue","70-bb-e9-25-1c-bc":"dark-blue"},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":7,"w":12,"x":0,"y":0},"hiddenSeries":false,"id":4,"legend":{"avg":false,"current":false,"max":false,"min":false,"rightSide":true,"show":false,"total":false,"values":false},"lines":false,"linewidth":1,"links":[],"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"sum","alias":"$tag_macid","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.traffic","refId":"A","tags":{"macid":"*"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Clients By Traffic","tooltip":{"shared":true,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"decbytes","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":7,"w":12,"x":12,"y":0},"hiddenSeries":false,"id":2,"legend":{"avg":false,"current":false,"max":false,"min":false,"rightSide":true,"show":false,"total":true,"values":true},"lines":false,"linewidth":1,"links":[],"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"sum","alias":"$tag_macid","currentTagKey":"building","currentTagValue":"$Building","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.datarate","refId":"A","tags":{"macid":"*"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Clients by Data Rate","tooltip":{"shared":true,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"short","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{"BLUE":"#3f51bf","RED":"#d32f2f"},"breakPoint":"50%","cacheTimeout":null,"combine":{"label":"Others","threshold":0},"datasource":"OpenTSDB","fontSize":"80%","format":"short","gridPos":{"h":6,"w":12,"x":0,"y":7},"id":6,"interval":null,"legend":{"header":"","percentage":false,"show":true,"sort":"current","sortDesc":true,"values":true},"legendType":"Under graph","links":[],"maxDataPoints":3,"nullPointMode":"connected","options":{},"pieType":"pie","strokeWidth":"1","targets":[{"aggregator":"count","alias":"$tag_protocol","currentTagKey":"","currentTagValue":"","disableDownsampling":false,"downsampleAggregator":"avg","downsampleFillPolicy":"none","metric":"clt.loc.datarate","refId":"A","tags":{"protocol":"*","ssid":"$SSID"}}],"timeFrom":null,"timeShift":null,"title":"Client Protocol Distribution","type":"grafana-piechart-panel","valueName":"current"},{"aliasColors":{},"breakPoint":"50%","cacheTimeout":null,"combine":{"label":"Others","threshold":0},"datasource":"OpenTSDB","fontSize":"80%","format":"short","gridPos":{"h":6,"w":12,"x":12,"y":7},"id":8,"interval":null,"legend":{"show":true,"values":true},"legendType":"Under graph","links":[],"maxDataPoints":3,"nullPointMode":"connected","options":{},"pieType":"pie","strokeWidth":1,"targets":[{"aggregator":"sum","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","metric":"clt.loc.smartdevice","refId":"A","tags":{"client_type":"*","ssid":"$SSID","type":"network"}}],"timeFrom":null,"timeShift":null,"title":"Smart Devices Distribution","type":"grafana-piechart-panel","valueName":"current"}],"refresh":false,"schemaVersion":19,"style":"dark","tags":["OpenNMS"],"templating":{"list":[{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,site)","hide":0,"includeAll":true,"label":"Site","multi":false,"name":"Site","options":[],"query":"tag_values(clt.loc.traffic,site)","refresh":1,"regex":"","skipUrlSync":false,"sort":1,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,building,site=$Site)","hide":0,"includeAll":true,"label":"Building","multi":false,"name":"Building","options":[],"query":"tag_values(clt.loc.traffic,building,site=$Site)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,floor)","hide":0,"includeAll":true,"label":"Floor","multi":false,"name":"Floor","options":[],"query":"tag_values(clt.loc.traffic,floor)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,ssid)","hide":0,"includeAll":true,"label":"SSID","multi":false,"name":"SSID","options":[],"query":"tag_values(clt.loc.traffic,ssid)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"auto":false,"auto_count":30,"auto_min":"10s","current":{"text":"1hr","value":"1hr"},"hide":0,"label":"Time","name":"Time","options":[{"selected":true,"text":"1hr","value":"1hr"},{"selected":false,"text":"2hr","value":"2hr"},{"selected":false,"text":"4hr","value":"4hr"},{"selected":false,"text":"8hr","value":"8hr"},{"selected":false,"text":"12hr","value":"12hr"}],"query":"1hr,2hr,4hr,8hr,12hr,","refresh":2,"skipUrlSync":false,"type":"interval"}]},"time":{"from":"now-30d","to":"now"},"timepicker":{"refresh_intervals":["5s","10s","30s","1m","5m","15m","30m","1h","2h","1d"],"time_options":["5m","15m","1h","6h","12h","24h","2d","7d","30d"]},"timezone":"","title":"CLIENT DASHBOARD","uid":"MECz1NcWk","version":4}	1	2020-01-21 14:35:43	2020-01-21 14:39:38	1	1	0		0	f	f	MECz1NcWk
\.


--
-- Data for Name: dashboard_acl; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dashboard_acl (id, org_id, dashboard_id, user_id, team_id, permission, role, created, updated) FROM stdin;
1	-1	-1	\N	\N	1	Viewer	2017-06-20 00:00:00	2017-06-20 00:00:00
2	-1	-1	\N	\N	2	Editor	2017-06-20 00:00:00	2017-06-20 00:00:00
\.


--
-- Data for Name: dashboard_provisioning; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dashboard_provisioning (id, dashboard_id, name, external_id, updated, check_sum) FROM stdin;
\.


--
-- Data for Name: dashboard_snapshot; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dashboard_snapshot (id, name, key, delete_key, org_id, user_id, external, external_url, dashboard, expires, created, updated, external_delete_url) FROM stdin;
\.


--
-- Data for Name: dashboard_tag; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dashboard_tag (id, dashboard_id, term) FROM stdin;
206	10	OpenNMS
209	9	OpenNMS
213	15	OpenNMS
216	14	OpenNMS
217	16	OpenNMS
\.


--
-- Data for Name: dashboard_version; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dashboard_version (id, dashboard_id, parent_version, restored_from, version, created, created_by, message, data) FROM stdin;
315	9	3	0	4	2020-01-20 14:11:15	1		{"annotations":{"list":[{"builtIn":1,"datasource":"-- Grafana --","enable":true,"hide":true,"iconColor":"rgba(0, 211, 255, 1)","name":"Annotations \\u0026 Alerts","type":"dashboard"}]},"editable":true,"gnetId":null,"graphTooltip":0,"id":9,"iteration":1579529466558,"links":[],"panels":[{"cacheTimeout":null,"datasource":"OpenTSDB","gridPos":{"h":8,"w":12,"x":0,"y":0},"id":8,"links":[],"options":{"fieldOptions":{"calcs":["sum"],"defaults":{"mappings":[{"id":0,"op":"=","text":"N/A","type":1,"value":"null"}],"max":100,"min":0,"nullValueMode":"connected","thresholds":[{"color":"super-light-blue","value":null},{"color":"red","value":80}],"title":"","unit":"none"},"override":{},"values":false},"orientation":"horizontal","showThresholdLabels":false,"showThresholdMarkers":false},"pluginVersion":"6.4.0-pre","targets":[{"aggregator":"count","alias":"Total Client","currentFilterGroupBy":false,"currentFilterKey":"macid","currentFilterType":"regexp","currentFilterValue":"r.*","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","filters":[],"hide":false,"metric":"ap.client.count","refId":"B","tags":{"type":"ap"}},{"aggregator":"count","alias":"$tag_type","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","hide":false,"metric":"ap.clt.health","refId":"A","tags":{"type":"$type"}}],"timeFrom":null,"timeShift":null,"title":"Client Health","type":"gauge"},{"aliasColors":{"Count":"blue","clt.loc.datarate{site=Chennai, floor=Floor3, type=client, building=SDB5}":"super-light-blue"},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":8,"w":12,"x":12,"y":0},"hiddenSeries":false,"id":2,"legend":{"avg":true,"current":false,"max":false,"min":false,"rightSide":true,"show":false,"total":false,"values":true},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"avg","alias":"","currentFilterGroupBy":false,"currentFilterKey":"","currentFilterType":"literal_or","currentFilterValue":"","currentTagKey":"floor","currentTagValue":"$floor","downsampleAggregator":"avg","downsampleFillPolicy":"none","filters":[{"filter":"$site","groupBy":false,"tagk":"site","type":"literal_or"},{"filter":"$building","groupBy":false,"tagk":"building","type":"literal_or"},{"filter":"$floor","groupBy":false,"tagk":"floor","type":"literal_or"},{"filter":"client","groupBy":false,"tagk":"type","type":"literal_or"}],"metric":"clt.loc.datarate","refId":"A","tags":{}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Clients by Average  Data Rate","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":5,"max":null,"min":0,"mode":"histogram","name":null,"show":true,"values":["total"]},"yaxes":[{"format":"short","label":"No of clients","logBase":1,"max":null,"min":"0","show":true},{"format":"Bps","label":"","logBase":1,"max":null,"min":"0","show":true}],"yaxis":{"align":true,"alignLevel":50}},{"aliasColors":{"Count":"blue","ap.clt.rssi{floor=Floor1}":"semi-dark-blue","ap.clt.rssi{floor=Floor3}":"light-blue"},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":8,"w":12,"x":0,"y":8},"hiddenSeries":false,"id":10,"legend":{"alignAsTable":false,"avg":true,"current":false,"max":false,"min":false,"rightSide":false,"show":false,"total":false,"values":true},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"avg","alias":"","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","metric":"ap.clt.rssi","refId":"A","tags":{"floor":"$floor"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Clients by RSSI","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":5,"max":null,"min":0,"mode":"histogram","name":null,"show":true,"values":["total"]},"yaxes":[{"format":"short","label":"No of clients","logBase":1,"max":null,"min":"0","show":true},{"format":"dBm","label":null,"logBase":1,"max":null,"min":"0","show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{"04-79-70-73-87-ce":"super-light-blue","20-34-fb-81-19-cd":"super-light-green","70-bb-e9-25-1c-bc":"super-light-yellow","a1-3e-0e-5e-80-a1":"super-light-blue","a10-3e-0e-5e-80-a1":"semi-dark-blue","a13-3e-0e-5e-80-a1":"rgb(130, 130, 247)","a14-3e-0e-5e-80-a1":"semi-dark-blue","a16-3e-0e-5e-80-a1":"super-light-blue","a17-3e-0e-5e-80-a1":"blue","a18-3e-0e-5e-80-a1":"light-blue","a24-3e-0e-5e-80-a1":"rgb(4, 49, 120)","a27-3e-0e-5e-80-a1":"dark-blue","a3-3e-0e-5e-80-a1":"light-blue","a37-3e-0e-5e-80-a1":"super-light-blue","a38-3e-0e-5e-80-a1":"super-light-blue","a40-3e-0e-5e-80-a1":"semi-dark-blue","a6-3e-0e-5e-80-a1":"dark-blue","a8-3e-0e-5e-80-a1":"super-light-blue"},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":8,"w":12,"x":12,"y":8},"hiddenSeries":false,"id":4,"legend":{"avg":false,"current":false,"max":false,"min":false,"rightSide":true,"show":true,"total":false,"values":false},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"sum","alias":"$tag_macid","counterTop":"5","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","metric":"clt.loc.traffic","refId":"A","shouldComputeTopN":true,"tags":{"floor":"$floor","macid":"*","ssid":"$ssid"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Clients With Most Traffic","tooltip":{"shared":true,"sort":2,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"decbytes","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":12}},{"aliasColors":{"ap.clt.health{floor=Floor1, type=LowRSSI}":"super-light-blue","ap.clt.health{floor=Floor2, type=LowRSSI}":"light-blue","ap.clt.health{floor=Floor3, type=LowRSSI}":"super-light-blue"},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":8,"w":12,"x":0,"y":16},"hiddenSeries":false,"id":12,"legend":{"avg":false,"current":false,"max":false,"min":false,"rightSide":true,"show":true,"total":false,"values":false},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"count","alias":"$tag_site","counterTop":"5","currentFilterGroupBy":false,"currentFilterKey":"","currentFilterType":"literal_or","currentFilterValue":"","currentTagKey":"","currentTagValue":"","disableDownsampling":false,"downsampleAggregator":"avg","downsampleFillPolicy":"none","filters":[{"filter":"$type","groupBy":false,"tagk":"type","type":"iliteral_or"},{"filter":"*","groupBy":true,"tagk":"site","type":"wildcard"}],"hide":false,"metric":"ap.clt.health","refId":"A","shouldComputeTopN":true,"tags":{}},{"aggregator":"count","alias":"","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","hide":true,"metric":"ap.clt.health","refId":"B","tags":{"floor":"$floor"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Top Locations Affected by Poor Performance","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"short","label":"","logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{"ap.client.count":"super-light-blue","clnt.associate{type=associated}":"dark-blue","clt.loc.traffic":"blue","test.traffic":"light-blue"},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":0,"fillGradient":0,"gridPos":{"h":8,"w":12,"x":12,"y":16},"hiddenSeries":false,"id":16,"legend":{"alignAsTable":true,"avg":false,"current":false,"max":false,"min":false,"rightSide":false,"show":false,"total":false,"values":false},"lines":true,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[{"alias":"clt.loc.traffic","bars":true,"lines":false,"points":false,"yaxis":2},{"alias":"ap.client.count","bars":false,"lines":true,"points":true},{}],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"sum","alias":"","currentTagKey":"","currentTagValue":"","disableDownsampling":false,"downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","hide":false,"metric":"clt.loc.traffic","refId":"A","tags":{}},{"aggregator":"count","downsampleAggregator":"avg","downsampleFillPolicy":"none","hide":false,"metric":"ap.client.count","refId":"C"}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Network Usage","tooltip":{"shared":true,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"time","name":null,"show":true,"values":[]},"yaxes":[{"format":"short","label":"No of clients","logBase":1,"max":null,"min":"0","show":true},{"format":"decbytes","label":"Traffic Volumes","logBase":1,"max":null,"min":"0","show":true}],"yaxis":{"align":false,"alignLevel":4}}],"refresh":false,"schemaVersion":19,"style":"dark","tags":["OpenNMS"],"templating":{"list":[{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,site)","hide":0,"includeAll":true,"label":"site","multi":false,"name":"site","options":[],"query":"tag_values(clt.loc.traffic,site)","refresh":1,"regex":"","skipUrlSync":false,"sort":3,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,building,site=$site)","hide":0,"includeAll":true,"label":"building","multi":false,"name":"building","options":[],"query":"tag_values(clt.loc.traffic,building,site=$site)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.datarate,floor)","hide":0,"includeAll":true,"label":"floor","multi":false,"name":"floor","options":[],"query":"tag_values(clt.loc.datarate,floor)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,ssid)","hide":0,"includeAll":true,"label":"ssid","multi":false,"name":"ssid","options":[],"query":"tag_values(clt.loc.traffic,ssid)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(ap.clt.health,type)","hide":0,"includeAll":true,"label":"type","multi":false,"name":"type","options":[],"query":"tag_values(ap.clt.health,type)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false}]},"time":{"from":"now-30d","to":"now"},"timepicker":{"refresh_intervals":["5s","10s","30s","1m","5m","15m","30m","1h","2h","1d"]},"timezone":"","title":"Performance Dashboard","uid":"ZDLeDT1Zk","version":4}
320	15	2	0	1	2020-01-21 14:35:43	1		{"__requires":[{"id":"grafana","name":"Grafana","type":"grafana","version":"6.5.0-pre"},{"id":"grafana-piechart-panel","name":"Pie Chart","type":"panel","version":"1.3.9"},{"id":"graph","name":"Graph","type":"panel","version":""},{"id":"opentsdb","name":"OpenTSDB","type":"datasource","version":"1.0.0"}],"annotations":{"list":[{"builtIn":1,"datasource":"-- Grafana --","enable":true,"hide":true,"iconColor":"rgba(0, 211, 255, 1)","name":"Annotations \\u0026 Alerts","type":"dashboard"}]},"editable":true,"gnetId":null,"graphTooltip":0,"id":null,"iteration":1579615478762,"links":[],"panels":[{"aliasColors":{"20-34-fb-81-19-cd":"super-light-blue","70-bb-e9-25-1c-bc":"dark-blue"},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":7,"w":12,"x":0,"y":0},"hiddenSeries":false,"id":4,"legend":{"avg":false,"current":false,"max":false,"min":false,"rightSide":true,"show":false,"total":false,"values":false},"lines":false,"linewidth":1,"links":[],"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"sum","alias":"$tag_macid","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.traffic","refId":"A","tags":{"macid":"*"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Clients By Traffic","tooltip":{"shared":true,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"decbytes","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":7,"w":12,"x":12,"y":0},"hiddenSeries":false,"id":2,"legend":{"avg":false,"current":false,"max":false,"min":false,"rightSide":true,"show":false,"total":true,"values":true},"lines":false,"linewidth":1,"links":[],"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"sum","alias":"$tag_macid","currentTagKey":"building","currentTagValue":"$Building","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.datarate","refId":"A","tags":{"macid":"*"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Clients by Data Rate","tooltip":{"shared":true,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"short","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{"BLUE":"#3f51bf","RED":"#d32f2f"},"breakPoint":"50%","cacheTimeout":null,"combine":{"label":"Others","threshold":0},"datasource":"OpenTSDB","fontSize":"80%","format":"short","gridPos":{"h":6,"w":12,"x":0,"y":7},"id":6,"interval":null,"legend":{"header":"","percentage":false,"show":true,"sort":"current","sortDesc":true,"values":true},"legendType":"Under graph","links":[],"maxDataPoints":3,"nullPointMode":"connected","options":{},"pieType":"pie","strokeWidth":"1","targets":[{"aggregator":"count","alias":"$tag_protocol","currentTagKey":"","currentTagValue":"","disableDownsampling":false,"downsampleAggregator":"avg","downsampleFillPolicy":"none","metric":"clt.loc.datarate","refId":"A","tags":{"protocol":"*","ssid":"$SSID"}}],"timeFrom":null,"timeShift":null,"title":"Client Protocol Distribution","type":"grafana-piechart-panel","valueName":"current"},{"aliasColors":{},"breakPoint":"50%","cacheTimeout":null,"combine":{"label":"Others","threshold":0},"datasource":"OpenTSDB","fontSize":"80%","format":"short","gridPos":{"h":6,"w":12,"x":12,"y":7},"id":8,"interval":null,"legend":{"show":true,"values":true},"legendType":"Under graph","links":[],"maxDataPoints":3,"nullPointMode":"connected","options":{},"pieType":"pie","strokeWidth":1,"targets":[{"aggregator":"sum","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","metric":"clt.loc.smartdevice","refId":"A","tags":{"client_type":"*","ssid":"$SSID","type":"network"}}],"timeFrom":null,"timeShift":null,"title":"Smart Devices Distribution","type":"grafana-piechart-panel","valueName":"current"}],"refresh":false,"schemaVersion":20,"style":"dark","tags":[],"templating":{"list":[{"allValue":null,"current":{},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,site)","hide":0,"includeAll":true,"label":"Site","multi":false,"name":"Site","options":[],"query":"tag_values(clt.loc.traffic,site)","refresh":1,"regex":"","skipUrlSync":false,"sort":1,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,building,site=$Site)","hide":0,"includeAll":true,"label":"Building","multi":false,"name":"Building","options":[],"query":"tag_values(clt.loc.traffic,building,site=$Site)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,floor)","hide":0,"includeAll":true,"label":"Floor","multi":false,"name":"Floor","options":[],"query":"tag_values(clt.loc.traffic,floor)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,ssid)","hide":0,"includeAll":true,"label":"SSID","multi":false,"name":"SSID","options":[],"query":"tag_values(clt.loc.traffic,ssid)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"auto":false,"auto_count":30,"auto_min":"10s","current":{"selected":false,"text":"1hr","value":"1hr"},"hide":0,"label":"Time","name":"Time","options":[{"selected":true,"text":"1hr","value":"1hr"},{"selected":false,"text":"2hr","value":"2hr"},{"selected":false,"text":"4hr","value":"4hr"},{"selected":false,"text":"8hr","value":"8hr"},{"selected":false,"text":"12hr","value":"12hr"}],"query":"1hr,2hr,4hr,8hr,12hr,","refresh":2,"skipUrlSync":false,"type":"interval"}]},"time":{"from":"now-30d","to":"now"},"timepicker":{"refresh_intervals":["5s","10s","30s","1m","5m","15m","30m","1h","2h","1d"],"time_options":["5m","15m","1h","6h","12h","24h","2d","7d","30d"]},"timezone":"","title":"CLIENT DASHBOARD","uid":"MECz1NcWk","version":1}
321	15	1	0	2	2020-01-21 14:36:00	1		{"annotations":{"list":[{"builtIn":1,"datasource":"-- Grafana --","enable":true,"hide":true,"iconColor":"rgba(0, 211, 255, 1)","name":"Annotations \\u0026 Alerts","type":"dashboard"}]},"editable":true,"gnetId":null,"graphTooltip":0,"id":15,"iteration":1579617343840,"links":[],"panels":[{"aliasColors":{"20-34-fb-81-19-cd":"super-light-blue","70-bb-e9-25-1c-bc":"dark-blue"},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":7,"w":12,"x":0,"y":0},"hiddenSeries":false,"id":4,"legend":{"avg":false,"current":false,"max":false,"min":false,"rightSide":true,"show":false,"total":false,"values":false},"lines":false,"linewidth":1,"links":[],"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"sum","alias":"$tag_macid","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.traffic","refId":"A","tags":{"macid":"*"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Clients By Traffic","tooltip":{"shared":true,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"decbytes","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":7,"w":12,"x":12,"y":0},"hiddenSeries":false,"id":2,"legend":{"avg":false,"current":false,"max":false,"min":false,"rightSide":true,"show":false,"total":true,"values":true},"lines":false,"linewidth":1,"links":[],"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"sum","alias":"$tag_macid","currentTagKey":"building","currentTagValue":"$Building","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.datarate","refId":"A","tags":{"macid":"*"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Clients by Data Rate","tooltip":{"shared":true,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"short","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{"BLUE":"#3f51bf","RED":"#d32f2f"},"breakPoint":"50%","cacheTimeout":null,"combine":{"label":"Others","threshold":0},"datasource":"OpenTSDB","fontSize":"80%","format":"short","gridPos":{"h":6,"w":12,"x":0,"y":7},"id":6,"interval":null,"legend":{"header":"","percentage":false,"show":true,"sort":"current","sortDesc":true,"values":true},"legendType":"Under graph","links":[],"maxDataPoints":3,"nullPointMode":"connected","options":{},"pieType":"pie","strokeWidth":"1","targets":[{"aggregator":"count","alias":"$tag_protocol","currentTagKey":"","currentTagValue":"","disableDownsampling":false,"downsampleAggregator":"avg","downsampleFillPolicy":"none","metric":"clt.loc.datarate","refId":"A","tags":{"protocol":"*","ssid":"$SSID"}}],"timeFrom":null,"timeShift":null,"title":"Client Protocol Distribution","type":"grafana-piechart-panel","valueName":"current"},{"aliasColors":{},"breakPoint":"50%","cacheTimeout":null,"combine":{"label":"Others","threshold":0},"datasource":"OpenTSDB","fontSize":"80%","format":"short","gridPos":{"h":6,"w":12,"x":12,"y":7},"id":8,"interval":null,"legend":{"show":true,"values":true},"legendType":"Under graph","links":[],"maxDataPoints":3,"nullPointMode":"connected","options":{},"pieType":"pie","strokeWidth":1,"targets":[{"aggregator":"sum","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","metric":"clt.loc.smartdevice","refId":"A","tags":{"client_type":"*","ssid":"$SSID","type":"network"}}],"timeFrom":null,"timeShift":null,"title":"Smart Devices Distribution","type":"grafana-piechart-panel","valueName":"current"}],"refresh":false,"schemaVersion":19,"style":"dark","tags":[],"templating":{"list":[{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,site)","hide":0,"includeAll":true,"label":"Site","multi":false,"name":"Site","options":[],"query":"tag_values(clt.loc.traffic,site)","refresh":1,"regex":"","skipUrlSync":false,"sort":1,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,building,site=$Site)","hide":0,"includeAll":true,"label":"Building","multi":false,"name":"Building","options":[],"query":"tag_values(clt.loc.traffic,building,site=$Site)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,floor)","hide":0,"includeAll":true,"label":"Floor","multi":false,"name":"Floor","options":[],"query":"tag_values(clt.loc.traffic,floor)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,ssid)","hide":0,"includeAll":true,"label":"SSID","multi":false,"name":"SSID","options":[],"query":"tag_values(clt.loc.traffic,ssid)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"auto":false,"auto_count":30,"auto_min":"10s","current":{"text":"1hr","value":"1hr"},"hide":0,"label":"Time","name":"Time","options":[{"selected":true,"text":"1hr","value":"1hr"},{"selected":false,"text":"2hr","value":"2hr"},{"selected":false,"text":"4hr","value":"4hr"},{"selected":false,"text":"8hr","value":"8hr"},{"selected":false,"text":"12hr","value":"12hr"}],"query":"1hr,2hr,4hr,8hr,12hr,","refresh":2,"skipUrlSync":false,"type":"interval"}]},"time":{"from":"now-30d","to":"now"},"timepicker":{"refresh_intervals":["5s","10s","30s","1m","5m","15m","30m","1h","2h","1d"],"time_options":["5m","15m","1h","6h","12h","24h","2d","7d","30d"]},"timezone":"","title":"CLIENT DASHBOARD","uid":"MECz1NcWk","version":2}
322	16	4	0	1	2020-01-21 14:36:16	1		{"__requires":[{"id":"grafana","name":"Grafana","type":"grafana","version":"6.5.0-pre"},{"id":"grafana-piechart-panel","name":"Pie Chart","type":"panel","version":"1.3.9"},{"id":"graph","name":"Graph","type":"panel","version":""},{"id":"opentsdb","name":"OpenTSDB","type":"datasource","version":"1.0.0"}],"annotations":{"list":[{"builtIn":1,"datasource":"-- Grafana --","enable":true,"hide":true,"iconColor":"rgba(0, 211, 255, 1)","name":"Annotations \\u0026 Alerts","type":"dashboard"}]},"editable":true,"gnetId":null,"graphTooltip":0,"id":null,"iteration":1579615330473,"links":[],"panels":[{"aliasColors":{},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":6,"w":12,"x":0,"y":0},"hiddenSeries":false,"id":18,"legend":{"avg":false,"current":false,"max":false,"min":false,"show":false,"total":false,"values":false},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"sum","alias":"$tag_aphost","counterTop":"10","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.datarate","refId":"A","shouldComputeTopN":true,"tags":{"macid":"*"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"CLIENT HEALTH METRIC, POSITION, PROFILE","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":true,"values":["total"]},"yaxes":[{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":6,"w":12,"x":12,"y":0},"hiddenSeries":false,"id":8,"legend":{"avg":false,"current":false,"max":false,"min":false,"show":true,"total":true,"values":true},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"sum","alias":"$tag_aphost","counterTop":"10","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.traffic","refId":"A","shouldComputeTopN":true,"tags":{"building":"$Building","floor":"$Floor","site":"$Site","ssid":"*","type":"ssid"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Data transfer By SSID","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"short","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":6,"w":12,"x":0,"y":6},"hiddenSeries":false,"id":22,"legend":{"alignAsTable":false,"avg":false,"current":false,"max":false,"min":false,"rightSide":true,"show":true,"total":true,"values":true},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"sum","alias":"$tag_site","counterTop":"10","currentTagKey":"type","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.smartdevice","refId":"A","shouldComputeTopN":true,"tags":{"building":"$Building","floor":"$Floor","site":"$Site"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Location by APs","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"short","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{},"bars":false,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":6,"w":12,"x":12,"y":6},"hiddenSeries":false,"id":4,"legend":{"avg":true,"current":false,"max":false,"min":false,"show":false,"total":false,"values":true},"lines":true,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":true,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"avg","alias":"$tag_ssid","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","metric":"clt.loc.datarate","refId":"A","tags":{"building":"$Building","floor":"$Floor","site":"$Site","ssid":"$SSID"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"AP Data Transfer Trend","tooltip":{"shared":true,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"time","name":null,"show":true,"values":[]},"yaxes":[{"format":"decbytes","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":6,"w":12,"x":0,"y":12},"hiddenSeries":false,"id":14,"legend":{"alignAsTable":false,"avg":false,"current":false,"max":false,"min":false,"rightSide":true,"show":false,"sideWidth":null,"total":false,"values":false},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"avg","alias":"$tag_site","counterTop":"10","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.traffic","refId":"A","shouldComputeTopN":true,"tags":{"aphost":"*","building":"$Building","floor":"$Floor","site":"$Site","ssid":"$SSID","type":"client"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Average Data Transfer","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"decbytes","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{},"breakPoint":"50%","cacheTimeout":null,"combine":{"label":"Others","threshold":0},"datasource":"OpenTSDB","fontSize":"80%","format":"short","gridPos":{"h":6,"w":12,"x":12,"y":12},"id":6,"interval":null,"legend":{"show":true,"values":true},"legendType":"Under graph","links":[],"maxDataPoints":3,"nullPointMode":"connected","options":{},"pieType":"pie","strokeWidth":1,"targets":[{"aggregator":"sum","currentTagKey":"ssid","currentTagValue":"Rakuten-PPP","downsampleAggregator":"avg","downsampleFillPolicy":"none","metric":"clt.loc.smartdevice","refId":"A","tags":{"building":"$Building","client_type":"*","floor":"$Floor"}}],"timeFrom":null,"timeShift":null,"title":"Smart Device Association By SSID","type":"grafana-piechart-panel","valueName":"current"},{"aliasColors":{},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":6,"w":12,"x":0,"y":18},"hiddenSeries":false,"id":12,"legend":{"alignAsTable":false,"avg":false,"current":false,"max":false,"min":false,"rightSide":true,"show":false,"total":true,"values":true},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"count","alias":"$tag_site","counterTop":"10","currentTagKey":"ssid","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.association","refId":"A","shouldComputeTopN":true,"tags":{"building":"$Building","floor":"$Floor","site":"$Site","status":"success","type":"network"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Locations By Associations","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"short","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{},"bars":false,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":6,"w":12,"x":12,"y":18},"hiddenSeries":false,"id":2,"legend":{"alignAsTable":false,"avg":false,"current":false,"max":false,"min":false,"rightSide":false,"show":false,"total":false,"values":false},"lines":true,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"count","alias":"$tag_aphost","counterTop":"10","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.association","refId":"A","shouldComputeTopN":false,"tags":{"status":"success","type":"network"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Association Trend","tooltip":{"shared":true,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"time","name":null,"show":true,"values":[]},"yaxes":[{"format":"short","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{},"breakPoint":"50%","cacheTimeout":null,"combine":{"label":"Others","threshold":0},"datasource":"OpenTSDB","fontSize":"80%","format":"short","gridPos":{"h":6,"w":12,"x":0,"y":24},"id":10,"interval":null,"legend":{"show":true,"values":true},"legendType":"Under graph","links":[],"maxDataPoints":3,"nullPointMode":"connected","options":{},"pieType":"pie","strokeWidth":1,"targets":[{"aggregator":"avg","alias":"$tag_macid","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.smartdevice","refId":"A","tags":{"building":"$Building","floor":"$Floor","site":"$Site","ssid":"*","type":"network"}}],"timeFrom":null,"timeShift":null,"title":"Average Associations By SSID","type":"grafana-piechart-panel","valueName":"current"},{"aliasColors":{},"bars":false,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":6,"w":12,"x":12,"y":24},"hiddenSeries":false,"id":20,"legend":{"avg":false,"current":false,"max":false,"min":false,"show":true,"total":false,"values":false},"lines":true,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"sum","alias":"$tag_aphost","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"ap.loc.apstatus","refId":"A","tags":{"status":"active"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Active APs Trend","tooltip":{"shared":true,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"time","name":null,"show":true,"values":[]},"yaxes":[{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}}],"refresh":false,"schemaVersion":20,"style":"dark","tags":[],"templating":{"list":[{"allValue":null,"current":{},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,site)","hide":0,"includeAll":true,"label":"Site","multi":false,"name":"Site","options":[],"query":"tag_values(clt.loc.traffic,site)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,building,site=$Site)","hide":0,"includeAll":true,"label":"Building","multi":false,"name":"Building","options":[],"query":"tag_values(clt.loc.traffic,building,site=$Site)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,floor)","hide":0,"includeAll":true,"label":"Floor","multi":false,"name":"Floor","options":[],"query":"tag_values(clt.loc.traffic,floor)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,ssid)","hide":0,"includeAll":true,"label":"SSID","multi":false,"name":"SSID","options":[],"query":"tag_values(clt.loc.traffic,ssid)","refresh":1,"regex":"","skipUrlSync":false,"sort":1,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,macid)","hide":0,"includeAll":true,"label":"Client","multi":false,"name":"Client","options":[],"query":"tag_values(clt.loc.traffic,macid)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"auto":false,"auto_count":30,"auto_min":"10s","current":{"selected":false,"text":"1hr","value":"1hr"},"hide":0,"label":null,"name":"Time","options":[{"selected":true,"text":"1hr","value":"1hr"},{"selected":false,"text":"2hr","value":"2hr"},{"selected":false,"text":"4hr","value":"4hr"},{"selected":false,"text":"8hr","value":"8hr"},{"selected":false,"text":"12hr","value":"12hr"}],"query":"1hr,2hr,4hr,8hr,12hr,","refresh":2,"skipUrlSync":false,"type":"interval"}]},"time":{"from":"now-90d","to":"now"},"timepicker":{"refresh_intervals":["5s","10s","30s","1m","5m","15m","30m","1h","2h","1d"]},"timezone":"","title":"NETWORK DASHBOARD","uid":"iSG-OzhZk","version":1}
323	16	1	0	2	2020-01-21 14:36:22	1		{"annotations":{"list":[{"builtIn":1,"datasource":"-- Grafana --","enable":true,"hide":true,"iconColor":"rgba(0, 211, 255, 1)","name":"Annotations \\u0026 Alerts","type":"dashboard"}]},"editable":true,"gnetId":null,"graphTooltip":0,"id":16,"iteration":1579617376843,"links":[],"panels":[{"aliasColors":{},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":6,"w":12,"x":0,"y":0},"hiddenSeries":false,"id":18,"legend":{"avg":false,"current":false,"max":false,"min":false,"show":false,"total":false,"values":false},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"sum","alias":"$tag_aphost","counterTop":"10","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.datarate","refId":"A","shouldComputeTopN":true,"tags":{"macid":"*"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"CLIENT HEALTH METRIC, POSITION, PROFILE","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":true,"values":["total"]},"yaxes":[{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":6,"w":12,"x":12,"y":0},"hiddenSeries":false,"id":8,"legend":{"avg":false,"current":false,"max":false,"min":false,"show":true,"total":true,"values":true},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"sum","alias":"$tag_aphost","counterTop":"10","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.traffic","refId":"A","shouldComputeTopN":true,"tags":{"building":"$Building","floor":"$Floor","site":"$Site","ssid":"*","type":"ssid"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Data transfer By SSID","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"short","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":6,"w":12,"x":0,"y":6},"hiddenSeries":false,"id":22,"legend":{"alignAsTable":false,"avg":false,"current":false,"max":false,"min":false,"rightSide":true,"show":true,"total":true,"values":true},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"sum","alias":"$tag_site","counterTop":"10","currentTagKey":"type","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.smartdevice","refId":"A","shouldComputeTopN":true,"tags":{"building":"$Building","floor":"$Floor","site":"$Site"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Location by APs","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"short","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{},"bars":false,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":6,"w":12,"x":12,"y":6},"hiddenSeries":false,"id":4,"legend":{"avg":true,"current":false,"max":false,"min":false,"show":false,"total":false,"values":true},"lines":true,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":true,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"avg","alias":"$tag_ssid","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","metric":"clt.loc.datarate","refId":"A","tags":{"building":"$Building","floor":"$Floor","site":"$Site","ssid":"$SSID"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"AP Data Transfer Trend","tooltip":{"shared":true,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"time","name":null,"show":true,"values":[]},"yaxes":[{"format":"decbytes","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":6,"w":12,"x":0,"y":12},"hiddenSeries":false,"id":14,"legend":{"alignAsTable":false,"avg":false,"current":false,"max":false,"min":false,"rightSide":true,"show":false,"sideWidth":null,"total":false,"values":false},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"avg","alias":"$tag_site","counterTop":"10","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.traffic","refId":"A","shouldComputeTopN":true,"tags":{"aphost":"*","building":"$Building","floor":"$Floor","site":"$Site","ssid":"$SSID","type":"client"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Average Data Transfer","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"decbytes","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{},"breakPoint":"50%","cacheTimeout":null,"combine":{"label":"Others","threshold":0},"datasource":"OpenTSDB","fontSize":"80%","format":"short","gridPos":{"h":6,"w":12,"x":12,"y":12},"id":6,"interval":null,"legend":{"show":true,"values":true},"legendType":"Under graph","links":[],"maxDataPoints":3,"nullPointMode":"connected","options":{},"pieType":"pie","strokeWidth":1,"targets":[{"aggregator":"sum","currentTagKey":"ssid","currentTagValue":"Rakuten-PPP","downsampleAggregator":"avg","downsampleFillPolicy":"none","metric":"clt.loc.smartdevice","refId":"A","tags":{"building":"$Building","client_type":"*","floor":"$Floor"}}],"timeFrom":null,"timeShift":null,"title":"Smart Device Association By SSID","type":"grafana-piechart-panel","valueName":"current"},{"aliasColors":{},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":6,"w":12,"x":0,"y":18},"hiddenSeries":false,"id":12,"legend":{"alignAsTable":false,"avg":false,"current":false,"max":false,"min":false,"rightSide":true,"show":false,"total":true,"values":true},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"count","alias":"$tag_site","counterTop":"10","currentTagKey":"ssid","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.association","refId":"A","shouldComputeTopN":true,"tags":{"building":"$Building","floor":"$Floor","site":"$Site","status":"success","type":"network"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Locations By Associations","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"short","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{},"bars":false,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":6,"w":12,"x":12,"y":18},"hiddenSeries":false,"id":2,"legend":{"alignAsTable":false,"avg":false,"current":false,"max":false,"min":false,"rightSide":false,"show":false,"total":false,"values":false},"lines":true,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"count","alias":"$tag_aphost","counterTop":"10","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.association","refId":"A","shouldComputeTopN":false,"tags":{"status":"success","type":"network"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Association Trend","tooltip":{"shared":true,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"time","name":null,"show":true,"values":[]},"yaxes":[{"format":"short","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{},"breakPoint":"50%","cacheTimeout":null,"combine":{"label":"Others","threshold":0},"datasource":"OpenTSDB","fontSize":"80%","format":"short","gridPos":{"h":6,"w":12,"x":0,"y":24},"id":10,"interval":null,"legend":{"show":true,"values":true},"legendType":"Under graph","links":[],"maxDataPoints":3,"nullPointMode":"connected","options":{},"pieType":"pie","strokeWidth":1,"targets":[{"aggregator":"avg","alias":"$tag_macid","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.smartdevice","refId":"A","tags":{"building":"$Building","floor":"$Floor","site":"$Site","ssid":"*","type":"network"}}],"timeFrom":null,"timeShift":null,"title":"Average Associations By SSID","type":"grafana-piechart-panel","valueName":"current"},{"aliasColors":{},"bars":false,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":6,"w":12,"x":12,"y":24},"hiddenSeries":false,"id":20,"legend":{"avg":false,"current":false,"max":false,"min":false,"show":true,"total":false,"values":false},"lines":true,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"sum","alias":"$tag_aphost","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"ap.loc.apstatus","refId":"A","tags":{"status":"active"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Active APs Trend","tooltip":{"shared":true,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"time","name":null,"show":true,"values":[]},"yaxes":[{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}}],"refresh":false,"schemaVersion":19,"style":"dark","tags":[],"templating":{"list":[{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,site)","hide":0,"includeAll":true,"label":"Site","multi":false,"name":"Site","options":[],"query":"tag_values(clt.loc.traffic,site)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,building,site=$Site)","hide":0,"includeAll":true,"label":"Building","multi":false,"name":"Building","options":[],"query":"tag_values(clt.loc.traffic,building,site=$Site)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,floor)","hide":0,"includeAll":true,"label":"Floor","multi":false,"name":"Floor","options":[],"query":"tag_values(clt.loc.traffic,floor)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,ssid)","hide":0,"includeAll":true,"label":"SSID","multi":false,"name":"SSID","options":[],"query":"tag_values(clt.loc.traffic,ssid)","refresh":1,"regex":"","skipUrlSync":false,"sort":1,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,macid)","hide":0,"includeAll":true,"label":"Client","multi":false,"name":"Client","options":[],"query":"tag_values(clt.loc.traffic,macid)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"auto":false,"auto_count":30,"auto_min":"10s","current":{"text":"1hr","value":"1hr"},"hide":0,"label":null,"name":"Time","options":[{"selected":true,"text":"1hr","value":"1hr"},{"selected":false,"text":"2hr","value":"2hr"},{"selected":false,"text":"4hr","value":"4hr"},{"selected":false,"text":"8hr","value":"8hr"},{"selected":false,"text":"12hr","value":"12hr"}],"query":"1hr,2hr,4hr,8hr,12hr,","refresh":2,"skipUrlSync":false,"type":"interval"}]},"time":{"from":"now-90d","to":"now"},"timepicker":{"refresh_intervals":["5s","10s","30s","1m","5m","15m","30m","1h","2h","1d"]},"timezone":"","title":"NETWORK DASHBOARD","uid":"iSG-OzhZk","version":2}
324	16	2	0	3	2020-01-21 14:39:14	1		{"annotations":{"list":[{"builtIn":1,"datasource":"-- Grafana --","enable":true,"hide":true,"iconColor":"rgba(0, 211, 255, 1)","name":"Annotations \\u0026 Alerts","type":"dashboard"}]},"editable":true,"gnetId":null,"graphTooltip":0,"id":16,"iteration":1579617538735,"links":[],"panels":[{"aliasColors":{},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":6,"w":12,"x":0,"y":0},"hiddenSeries":false,"id":18,"legend":{"avg":false,"current":false,"max":false,"min":false,"show":false,"total":false,"values":false},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"sum","alias":"$tag_aphost","counterTop":"10","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.datarate","refId":"A","shouldComputeTopN":true,"tags":{"macid":"*"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"CLIENT HEALTH METRIC, POSITION, PROFILE","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":true,"values":["total"]},"yaxes":[{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":6,"w":12,"x":12,"y":0},"hiddenSeries":false,"id":8,"legend":{"avg":false,"current":false,"max":false,"min":false,"show":true,"total":true,"values":true},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"sum","alias":"$tag_aphost","counterTop":"10","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.traffic","refId":"A","shouldComputeTopN":true,"tags":{"building":"$Building","floor":"$Floor","site":"$Site","ssid":"*","type":"ssid"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Data transfer By SSID","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"short","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":6,"w":12,"x":0,"y":6},"hiddenSeries":false,"id":22,"legend":{"alignAsTable":false,"avg":false,"current":false,"max":false,"min":false,"rightSide":true,"show":true,"total":true,"values":true},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"sum","alias":"$tag_site","counterTop":"10","currentTagKey":"type","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.smartdevice","refId":"A","shouldComputeTopN":true,"tags":{"building":"$Building","floor":"$Floor","site":"$Site"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Location by APs","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"short","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{},"bars":false,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":6,"w":12,"x":12,"y":6},"hiddenSeries":false,"id":4,"legend":{"avg":true,"current":false,"max":false,"min":false,"show":false,"total":false,"values":true},"lines":true,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":true,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"avg","alias":"$tag_ssid","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","metric":"clt.loc.datarate","refId":"A","tags":{"building":"$Building","floor":"$Floor","site":"$Site","ssid":"$SSID"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"AP Data Transfer Trend","tooltip":{"shared":true,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"time","name":null,"show":true,"values":[]},"yaxes":[{"format":"decbytes","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":6,"w":12,"x":0,"y":12},"hiddenSeries":false,"id":14,"legend":{"alignAsTable":false,"avg":false,"current":false,"max":false,"min":false,"rightSide":true,"show":false,"sideWidth":null,"total":false,"values":false},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"avg","alias":"$tag_site","counterTop":"10","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.traffic","refId":"A","shouldComputeTopN":true,"tags":{"aphost":"*","building":"$Building","floor":"$Floor","site":"$Site","ssid":"$SSID","type":"client"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Average Data Transfer","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"decbytes","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{},"breakPoint":"50%","cacheTimeout":null,"combine":{"label":"Others","threshold":0},"datasource":"OpenTSDB","fontSize":"80%","format":"short","gridPos":{"h":6,"w":12,"x":12,"y":12},"id":6,"interval":null,"legend":{"show":true,"values":true},"legendType":"Under graph","links":[],"maxDataPoints":3,"nullPointMode":"connected","options":{},"pieType":"pie","strokeWidth":1,"targets":[{"aggregator":"sum","currentTagKey":"ssid","currentTagValue":"Rakuten-PPP","downsampleAggregator":"avg","downsampleFillPolicy":"none","metric":"clt.loc.smartdevice","refId":"A","tags":{"building":"$Building","client_type":"*","floor":"$Floor"}}],"timeFrom":null,"timeShift":null,"title":"Smart Device Association By SSID","type":"grafana-piechart-panel","valueName":"current"},{"aliasColors":{},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":6,"w":12,"x":0,"y":18},"hiddenSeries":false,"id":12,"legend":{"alignAsTable":false,"avg":false,"current":false,"max":false,"min":false,"rightSide":true,"show":false,"total":true,"values":true},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"count","alias":"$tag_site","counterTop":"10","currentTagKey":"ssid","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.association","refId":"A","shouldComputeTopN":true,"tags":{"building":"$Building","floor":"$Floor","site":"$Site","status":"success","type":"network"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Locations By Associations","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"short","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{},"bars":false,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":6,"w":12,"x":12,"y":18},"hiddenSeries":false,"id":2,"legend":{"alignAsTable":false,"avg":false,"current":false,"max":false,"min":false,"rightSide":false,"show":false,"total":false,"values":false},"lines":true,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"count","alias":"$tag_aphost","counterTop":"10","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.association","refId":"A","shouldComputeTopN":false,"tags":{"status":"success","type":"network"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Association Trend","tooltip":{"shared":true,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"time","name":null,"show":true,"values":[]},"yaxes":[{"format":"short","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{},"breakPoint":"50%","cacheTimeout":null,"combine":{"label":"Others","threshold":0},"datasource":"OpenTSDB","fontSize":"80%","format":"short","gridPos":{"h":6,"w":12,"x":0,"y":24},"id":10,"interval":null,"legend":{"show":true,"values":true},"legendType":"Under graph","links":[],"maxDataPoints":3,"nullPointMode":"connected","options":{},"pieType":"pie","strokeWidth":1,"targets":[{"aggregator":"avg","alias":"$tag_macid","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.smartdevice","refId":"A","tags":{"building":"$Building","floor":"$Floor","site":"$Site","ssid":"*","type":"network"}}],"timeFrom":null,"timeShift":null,"title":"Average Associations By SSID","type":"grafana-piechart-panel","valueName":"current"},{"aliasColors":{},"bars":false,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":6,"w":12,"x":12,"y":24},"hiddenSeries":false,"id":20,"legend":{"avg":false,"current":false,"max":false,"min":false,"show":true,"total":false,"values":false},"lines":true,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"sum","alias":"$tag_aphost","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"ap.loc.apstatus","refId":"A","tags":{"status":"active"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Active APs Trend","tooltip":{"shared":true,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"time","name":null,"show":true,"values":[]},"yaxes":[{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}}],"refresh":false,"schemaVersion":19,"style":"dark","tags":["OpenNMS"],"templating":{"list":[{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,site)","hide":0,"includeAll":true,"label":"Site","multi":false,"name":"Site","options":[],"query":"tag_values(clt.loc.traffic,site)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,building,site=$Site)","hide":0,"includeAll":true,"label":"Building","multi":false,"name":"Building","options":[],"query":"tag_values(clt.loc.traffic,building,site=$Site)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,floor)","hide":0,"includeAll":true,"label":"Floor","multi":false,"name":"Floor","options":[],"query":"tag_values(clt.loc.traffic,floor)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,ssid)","hide":0,"includeAll":true,"label":"SSID","multi":false,"name":"SSID","options":[],"query":"tag_values(clt.loc.traffic,ssid)","refresh":1,"regex":"","skipUrlSync":false,"sort":1,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,macid)","hide":0,"includeAll":true,"label":"Client","multi":false,"name":"Client","options":[],"query":"tag_values(clt.loc.traffic,macid)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"auto":false,"auto_count":30,"auto_min":"10s","current":{"text":"1hr","value":"1hr"},"hide":0,"label":null,"name":"Time","options":[{"selected":true,"text":"1hr","value":"1hr"},{"selected":false,"text":"2hr","value":"2hr"},{"selected":false,"text":"4hr","value":"4hr"},{"selected":false,"text":"8hr","value":"8hr"},{"selected":false,"text":"12hr","value":"12hr"}],"query":"1hr,2hr,4hr,8hr,12hr,","refresh":2,"skipUrlSync":false,"type":"interval"}]},"time":{"from":"now-90d","to":"now"},"timepicker":{"refresh_intervals":["5s","10s","30s","1m","5m","15m","30m","1h","2h","1d"]},"timezone":"","title":"NETWORK DASHBOARD","uid":"iSG-OzhZk","version":3}
325	16	3	0	4	2020-01-21 14:39:18	1		{"annotations":{"list":[{"builtIn":1,"datasource":"-- Grafana --","enable":true,"hide":true,"iconColor":"rgba(0, 211, 255, 1)","name":"Annotations \\u0026 Alerts","type":"dashboard"}]},"editable":true,"gnetId":null,"graphTooltip":0,"id":16,"iteration":1579617538735,"links":[],"panels":[{"aliasColors":{},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":6,"w":12,"x":0,"y":0},"hiddenSeries":false,"id":18,"legend":{"avg":false,"current":false,"max":false,"min":false,"show":false,"total":false,"values":false},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"sum","alias":"$tag_aphost","counterTop":"10","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.datarate","refId":"A","shouldComputeTopN":true,"tags":{"macid":"*"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"CLIENT HEALTH METRIC, POSITION, PROFILE","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":true,"values":["total"]},"yaxes":[{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":6,"w":12,"x":12,"y":0},"hiddenSeries":false,"id":8,"legend":{"avg":false,"current":false,"max":false,"min":false,"show":true,"total":true,"values":true},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"sum","alias":"$tag_aphost","counterTop":"10","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.traffic","refId":"A","shouldComputeTopN":true,"tags":{"building":"$Building","floor":"$Floor","site":"$Site","ssid":"*","type":"ssid"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Data transfer By SSID","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"short","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":6,"w":12,"x":0,"y":6},"hiddenSeries":false,"id":22,"legend":{"alignAsTable":false,"avg":false,"current":false,"max":false,"min":false,"rightSide":true,"show":true,"total":true,"values":true},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"sum","alias":"$tag_site","counterTop":"10","currentTagKey":"type","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.smartdevice","refId":"A","shouldComputeTopN":true,"tags":{"building":"$Building","floor":"$Floor","site":"$Site"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Location by APs","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"short","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{},"bars":false,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":6,"w":12,"x":12,"y":6},"hiddenSeries":false,"id":4,"legend":{"avg":true,"current":false,"max":false,"min":false,"show":false,"total":false,"values":true},"lines":true,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":true,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"avg","alias":"$tag_ssid","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","metric":"clt.loc.datarate","refId":"A","tags":{"building":"$Building","floor":"$Floor","site":"$Site","ssid":"$SSID"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"AP Data Transfer Trend","tooltip":{"shared":true,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"time","name":null,"show":true,"values":[]},"yaxes":[{"format":"decbytes","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":6,"w":12,"x":0,"y":12},"hiddenSeries":false,"id":14,"legend":{"alignAsTable":false,"avg":false,"current":false,"max":false,"min":false,"rightSide":true,"show":false,"sideWidth":null,"total":false,"values":false},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"avg","alias":"$tag_site","counterTop":"10","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.traffic","refId":"A","shouldComputeTopN":true,"tags":{"aphost":"*","building":"$Building","floor":"$Floor","site":"$Site","ssid":"$SSID","type":"client"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Average Data Transfer","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"decbytes","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{},"breakPoint":"50%","cacheTimeout":null,"combine":{"label":"Others","threshold":0},"datasource":"OpenTSDB","fontSize":"80%","format":"short","gridPos":{"h":6,"w":12,"x":12,"y":12},"id":6,"interval":null,"legend":{"show":true,"values":true},"legendType":"Under graph","links":[],"maxDataPoints":3,"nullPointMode":"connected","options":{},"pieType":"pie","strokeWidth":1,"targets":[{"aggregator":"sum","currentTagKey":"ssid","currentTagValue":"Rakuten-PPP","downsampleAggregator":"avg","downsampleFillPolicy":"none","metric":"clt.loc.smartdevice","refId":"A","tags":{"building":"$Building","client_type":"*","floor":"$Floor"}}],"timeFrom":null,"timeShift":null,"title":"Smart Device Association By SSID","type":"grafana-piechart-panel","valueName":"current"},{"aliasColors":{},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":6,"w":12,"x":0,"y":18},"hiddenSeries":false,"id":12,"legend":{"alignAsTable":false,"avg":false,"current":false,"max":false,"min":false,"rightSide":true,"show":false,"total":true,"values":true},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"count","alias":"$tag_site","counterTop":"10","currentTagKey":"ssid","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.association","refId":"A","shouldComputeTopN":true,"tags":{"building":"$Building","floor":"$Floor","site":"$Site","status":"success","type":"network"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Locations By Associations","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"short","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{},"bars":false,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":6,"w":12,"x":12,"y":18},"hiddenSeries":false,"id":2,"legend":{"alignAsTable":false,"avg":false,"current":false,"max":false,"min":false,"rightSide":false,"show":false,"total":false,"values":false},"lines":true,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"count","alias":"$tag_aphost","counterTop":"10","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.association","refId":"A","shouldComputeTopN":false,"tags":{"status":"success","type":"network"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Association Trend","tooltip":{"shared":true,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"time","name":null,"show":true,"values":[]},"yaxes":[{"format":"short","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{},"breakPoint":"50%","cacheTimeout":null,"combine":{"label":"Others","threshold":0},"datasource":"OpenTSDB","fontSize":"80%","format":"short","gridPos":{"h":6,"w":12,"x":0,"y":24},"id":10,"interval":null,"legend":{"show":true,"values":true},"legendType":"Under graph","links":[],"maxDataPoints":3,"nullPointMode":"connected","options":{},"pieType":"pie","strokeWidth":1,"targets":[{"aggregator":"avg","alias":"$tag_macid","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.smartdevice","refId":"A","tags":{"building":"$Building","floor":"$Floor","site":"$Site","ssid":"*","type":"network"}}],"timeFrom":null,"timeShift":null,"title":"Average Associations By SSID","type":"grafana-piechart-panel","valueName":"current"},{"aliasColors":{},"bars":false,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":6,"w":12,"x":12,"y":24},"hiddenSeries":false,"id":20,"legend":{"avg":false,"current":false,"max":false,"min":false,"show":true,"total":false,"values":false},"lines":true,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"sum","alias":"$tag_aphost","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"ap.loc.apstatus","refId":"A","tags":{"status":"active"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Active APs Trend","tooltip":{"shared":true,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"time","name":null,"show":true,"values":[]},"yaxes":[{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}}],"refresh":false,"schemaVersion":19,"style":"dark","tags":["OpenNMS"],"templating":{"list":[{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,site)","hide":0,"includeAll":true,"label":"Site","multi":false,"name":"Site","options":[],"query":"tag_values(clt.loc.traffic,site)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,building,site=$Site)","hide":0,"includeAll":true,"label":"Building","multi":false,"name":"Building","options":[],"query":"tag_values(clt.loc.traffic,building,site=$Site)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,floor)","hide":0,"includeAll":true,"label":"Floor","multi":false,"name":"Floor","options":[],"query":"tag_values(clt.loc.traffic,floor)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,ssid)","hide":0,"includeAll":true,"label":"SSID","multi":false,"name":"SSID","options":[],"query":"tag_values(clt.loc.traffic,ssid)","refresh":1,"regex":"","skipUrlSync":false,"sort":1,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,macid)","hide":0,"includeAll":true,"label":"Client","multi":false,"name":"Client","options":[],"query":"tag_values(clt.loc.traffic,macid)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"auto":false,"auto_count":30,"auto_min":"10s","current":{"text":"1hr","value":"1hr"},"hide":0,"label":null,"name":"Time","options":[{"selected":true,"text":"1hr","value":"1hr"},{"selected":false,"text":"2hr","value":"2hr"},{"selected":false,"text":"4hr","value":"4hr"},{"selected":false,"text":"8hr","value":"8hr"},{"selected":false,"text":"12hr","value":"12hr"}],"query":"1hr,2hr,4hr,8hr,12hr,","refresh":2,"skipUrlSync":false,"type":"interval"}]},"time":{"from":"now-90d","to":"now"},"timepicker":{"refresh_intervals":["5s","10s","30s","1m","5m","15m","30m","1h","2h","1d"]},"timezone":"","title":"NETWORK DASHBOARD","uid":"iSG-OzhZk","version":4}
331	16	4	0	5	2020-01-21 14:40:32	1		{"annotations":{"list":[{"builtIn":1,"datasource":"-- Grafana --","enable":true,"hide":true,"iconColor":"rgba(0, 211, 255, 1)","name":"Annotations \\u0026 Alerts","type":"dashboard"}]},"editable":true,"gnetId":null,"graphTooltip":0,"id":16,"iteration":1579617627575,"links":[],"panels":[{"aliasColors":{},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":6,"w":12,"x":0,"y":0},"hiddenSeries":false,"id":18,"legend":{"avg":false,"current":false,"max":false,"min":false,"show":false,"total":false,"values":false},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"sum","alias":"$tag_aphost","counterTop":"10","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.datarate","refId":"A","shouldComputeTopN":true,"tags":{"macid":"*"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"CLIENT HEALTH METRIC, POSITION, PROFILE","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":true,"values":["total"]},"yaxes":[{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":6,"w":12,"x":12,"y":0},"hiddenSeries":false,"id":8,"legend":{"avg":false,"current":false,"max":false,"min":false,"show":true,"total":true,"values":true},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"sum","alias":"$tag_aphost","counterTop":"10","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.traffic","refId":"A","shouldComputeTopN":true,"tags":{"building":"$Building","floor":"$Floor","site":"$Site","ssid":"*","type":"ssid"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Data transfer By SSID","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"short","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":6,"w":12,"x":0,"y":6},"hiddenSeries":false,"id":22,"legend":{"alignAsTable":false,"avg":false,"current":false,"max":false,"min":false,"rightSide":true,"show":true,"total":true,"values":true},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"sum","alias":"$tag_site","counterTop":"10","currentTagKey":"type","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.smartdevice","refId":"A","shouldComputeTopN":true,"tags":{"building":"$Building","floor":"$Floor","site":"$Site"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Location by APs","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"short","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{},"bars":false,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":6,"w":12,"x":12,"y":6},"hiddenSeries":false,"id":4,"legend":{"avg":true,"current":false,"max":false,"min":false,"show":false,"total":false,"values":true},"lines":true,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":true,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"avg","alias":"$tag_ssid","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","metric":"clt.loc.datarate","refId":"A","tags":{"building":"$Building","floor":"$Floor","site":"$Site","ssid":"$SSID"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"AP Data Transfer Trend","tooltip":{"shared":true,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"time","name":null,"show":true,"values":[]},"yaxes":[{"format":"decbytes","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":6,"w":12,"x":0,"y":12},"hiddenSeries":false,"id":14,"legend":{"alignAsTable":false,"avg":false,"current":false,"max":false,"min":false,"rightSide":true,"show":false,"sideWidth":null,"total":false,"values":false},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"avg","alias":"$tag_site","counterTop":"10","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.traffic","refId":"A","shouldComputeTopN":true,"tags":{"aphost":"*","building":"$Building","floor":"$Floor","site":"$Site","ssid":"$SSID","type":"client"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Average Data Transfer","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"decbytes","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{},"breakPoint":"50%","cacheTimeout":null,"combine":{"label":"Others","threshold":0},"datasource":"OpenTSDB","fontSize":"80%","format":"short","gridPos":{"h":6,"w":12,"x":12,"y":12},"id":6,"interval":null,"legend":{"show":true,"values":true},"legendType":"Under graph","links":[],"maxDataPoints":3,"nullPointMode":"connected","options":{},"pieType":"pie","strokeWidth":1,"targets":[{"aggregator":"sum","currentTagKey":"ssid","currentTagValue":"Rakuten-PPP","downsampleAggregator":"avg","downsampleFillPolicy":"none","metric":"clt.loc.smartdevice","refId":"A","tags":{"building":"$Building","client_type":"*","floor":"$Floor"}}],"timeFrom":null,"timeShift":null,"title":"Smart Device Association By SSID","type":"grafana-piechart-panel","valueName":"current"},{"aliasColors":{},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":6,"w":12,"x":0,"y":18},"hiddenSeries":false,"id":12,"legend":{"alignAsTable":false,"avg":false,"current":false,"max":false,"min":false,"rightSide":true,"show":false,"total":true,"values":true},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"count","alias":"$tag_site","counterTop":"10","currentTagKey":"ssid","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.association","refId":"A","shouldComputeTopN":true,"tags":{"building":"$Building","floor":"$Floor","site":"$Site","status":"success","type":"network"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Locations By Associations","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"short","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{},"bars":false,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":6,"w":12,"x":12,"y":18},"hiddenSeries":false,"id":2,"legend":{"alignAsTable":false,"avg":false,"current":false,"max":false,"min":false,"rightSide":false,"show":false,"total":false,"values":false},"lines":true,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"count","alias":"$tag_aphost","counterTop":"10","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.association","refId":"A","shouldComputeTopN":false,"tags":{"status":"success","type":"network"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Association Trend","tooltip":{"shared":true,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"time","name":null,"show":true,"values":[]},"yaxes":[{"format":"short","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{},"breakPoint":"50%","cacheTimeout":null,"combine":{"label":"Others","threshold":0},"datasource":"OpenTSDB","fontSize":"80%","format":"short","gridPos":{"h":6,"w":12,"x":0,"y":24},"id":10,"interval":null,"legend":{"show":true,"values":true},"legendType":"Under graph","links":[],"maxDataPoints":3,"nullPointMode":"connected","options":{},"pieType":"pie","strokeWidth":1,"targets":[{"aggregator":"avg","alias":"$tag_macid","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.smartdevice","refId":"A","tags":{"building":"$Building","floor":"$Floor","site":"$Site","ssid":"*","type":"network"}}],"timeFrom":null,"timeShift":null,"title":"Average Associations By SSID","type":"grafana-piechart-panel","valueName":"current"},{"aliasColors":{},"bars":false,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":6,"w":12,"x":12,"y":24},"hiddenSeries":false,"id":20,"legend":{"avg":false,"current":false,"max":false,"min":false,"show":true,"total":false,"values":false},"lines":true,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"sum","alias":"$tag_aphost","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"ap.loc.apstatus","refId":"A","tags":{"status":"active"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Active APs Trend","tooltip":{"shared":true,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"time","name":null,"show":true,"values":[]},"yaxes":[{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}}],"refresh":false,"schemaVersion":19,"style":"dark","tags":["OpenNMS"],"templating":{"list":[{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,site)","hide":0,"includeAll":true,"label":"Site","multi":false,"name":"Site","options":[],"query":"tag_values(clt.loc.traffic,site)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,building,site=$Site)","hide":0,"includeAll":true,"label":"Building","multi":false,"name":"Building","options":[],"query":"tag_values(clt.loc.traffic,building,site=$Site)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,floor)","hide":0,"includeAll":true,"label":"Floor","multi":false,"name":"Floor","options":[],"query":"tag_values(clt.loc.traffic,floor)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,ssid)","hide":0,"includeAll":true,"label":"SSID","multi":false,"name":"SSID","options":[],"query":"tag_values(clt.loc.traffic,ssid)","refresh":1,"regex":"","skipUrlSync":false,"sort":1,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,macid)","hide":0,"includeAll":true,"label":"Client","multi":false,"name":"Client","options":[],"query":"tag_values(clt.loc.traffic,macid)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"auto":false,"auto_count":30,"auto_min":"10s","current":{"text":"1hr","value":"1hr"},"hide":0,"label":null,"name":"Time","options":[{"selected":true,"text":"1hr","value":"1hr"},{"selected":false,"text":"2hr","value":"2hr"},{"selected":false,"text":"4hr","value":"4hr"},{"selected":false,"text":"8hr","value":"8hr"},{"selected":false,"text":"12hr","value":"12hr"}],"query":"1hr,2hr,4hr,8hr,12hr,","refresh":2,"skipUrlSync":false,"type":"interval"}]},"time":{"from":"now-90d","to":"now"},"timepicker":{"refresh_intervals":["5s","10s","30s","1m","5m","15m","30m","1h","2h","1d"]},"timezone":"","title":"NETWORK DASHBOARD","uid":"iSG-OzhZk","version":5}
306	9	2	0	3	2020-01-20 14:07:43	1		{"annotations":{"list":[{"builtIn":1,"datasource":"-- Grafana --","enable":true,"hide":true,"iconColor":"rgba(0, 211, 255, 1)","name":"Annotations \\u0026 Alerts","type":"dashboard"}]},"editable":true,"gnetId":null,"graphTooltip":0,"id":9,"iteration":1579529235126,"links":[],"panels":[{"cacheTimeout":null,"datasource":"OpenTSDB","gridPos":{"h":8,"w":12,"x":0,"y":0},"id":8,"links":[],"options":{"fieldOptions":{"calcs":["sum"],"defaults":{"mappings":[{"id":0,"op":"=","text":"N/A","type":1,"value":"null"}],"max":100,"min":0,"nullValueMode":"connected","thresholds":[{"color":"super-light-blue","value":null},{"color":"red","value":80}],"title":"","unit":"none"},"override":{},"values":false},"orientation":"horizontal","showThresholdLabels":false,"showThresholdMarkers":false},"pluginVersion":"6.4.0-pre","targets":[{"aggregator":"count","alias":"Total Client","currentFilterGroupBy":false,"currentFilterKey":"macid","currentFilterType":"regexp","currentFilterValue":"r.*","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","filters":[],"hide":false,"metric":"ap.client.count","refId":"B","tags":{"type":"ap"}},{"aggregator":"count","alias":"$tag_type","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","hide":false,"metric":"ap.clt.health","refId":"A","tags":{"type":"$type"}}],"timeFrom":null,"timeShift":null,"title":"Client Health","type":"gauge"},{"aliasColors":{"Count":"blue","clt.loc.datarate{site=Chennai, floor=Floor3, type=client, building=SDB5}":"super-light-blue"},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":8,"w":12,"x":12,"y":0},"hiddenSeries":false,"id":2,"legend":{"avg":true,"current":false,"max":false,"min":false,"rightSide":true,"show":false,"total":false,"values":true},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"avg","alias":"","currentFilterGroupBy":false,"currentFilterKey":"","currentFilterType":"literal_or","currentFilterValue":"","currentTagKey":"floor","currentTagValue":"$floor","downsampleAggregator":"avg","downsampleFillPolicy":"none","filters":[{"filter":"$site","groupBy":false,"tagk":"site","type":"literal_or"},{"filter":"$building","groupBy":false,"tagk":"building","type":"literal_or"},{"filter":"$floor","groupBy":false,"tagk":"floor","type":"literal_or"},{"filter":"client","groupBy":false,"tagk":"type","type":"literal_or"}],"metric":"clt.loc.datarate","refId":"A","tags":{}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Clients by Average  Data Rate","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":5,"max":null,"min":0,"mode":"histogram","name":null,"show":true,"values":["total"]},"yaxes":[{"format":"short","label":"No of clients","logBase":1,"max":null,"min":"0","show":true},{"format":"Bps","label":"","logBase":1,"max":null,"min":"0","show":true}],"yaxis":{"align":true,"alignLevel":50}},{"aliasColors":{"Count":"blue","ap.clt.rssi{floor=Floor1}":"semi-dark-blue","ap.clt.rssi{floor=Floor3}":"light-blue"},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":8,"w":12,"x":0,"y":8},"hiddenSeries":false,"id":10,"legend":{"alignAsTable":false,"avg":true,"current":false,"max":false,"min":false,"rightSide":false,"show":false,"total":false,"values":true},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"avg","alias":"","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","metric":"ap.clt.rssi","refId":"A","tags":{"floor":"$floor"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Clients by RSSI","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":5,"max":null,"min":0,"mode":"histogram","name":null,"show":true,"values":["total"]},"yaxes":[{"format":"short","label":"No of clients","logBase":1,"max":null,"min":"0","show":true},{"format":"dBm","label":null,"logBase":1,"max":null,"min":"0","show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{"04-79-70-73-87-ce":"super-light-blue","20-34-fb-81-19-cd":"super-light-green","70-bb-e9-25-1c-bc":"super-light-yellow","a1-3e-0e-5e-80-a1":"super-light-blue","a10-3e-0e-5e-80-a1":"semi-dark-blue","a13-3e-0e-5e-80-a1":"rgb(130, 130, 247)","a14-3e-0e-5e-80-a1":"semi-dark-blue","a16-3e-0e-5e-80-a1":"super-light-blue","a17-3e-0e-5e-80-a1":"blue","a18-3e-0e-5e-80-a1":"light-blue","a24-3e-0e-5e-80-a1":"rgb(4, 49, 120)","a27-3e-0e-5e-80-a1":"dark-blue","a3-3e-0e-5e-80-a1":"light-blue","a37-3e-0e-5e-80-a1":"super-light-blue","a38-3e-0e-5e-80-a1":"super-light-blue","a40-3e-0e-5e-80-a1":"semi-dark-blue","a6-3e-0e-5e-80-a1":"dark-blue","a8-3e-0e-5e-80-a1":"super-light-blue"},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":8,"w":12,"x":12,"y":8},"hiddenSeries":false,"id":4,"legend":{"avg":false,"current":false,"max":false,"min":false,"rightSide":true,"show":true,"total":false,"values":false},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"sum","alias":"$tag_macid","counterTop":"5","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","metric":"clt.loc.traffic","refId":"A","shouldComputeTopN":true,"tags":{"floor":"$floor","macid":"*","ssid":"$ssid"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Clients With Most Traffic","tooltip":{"shared":true,"sort":2,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"decbytes","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":12}},{"aliasColors":{"ap.clt.health{floor=Floor1, type=LowRSSI}":"super-light-blue","ap.clt.health{floor=Floor2, type=LowRSSI}":"light-blue","ap.clt.health{floor=Floor3, type=LowRSSI}":"super-light-blue"},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":8,"w":12,"x":0,"y":16},"hiddenSeries":false,"id":12,"legend":{"avg":false,"current":false,"max":false,"min":false,"rightSide":true,"show":true,"total":false,"values":false},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"count","alias":"$tag_site","counterTop":"5","currentFilterGroupBy":false,"currentFilterKey":"","currentFilterType":"literal_or","currentFilterValue":"","currentTagKey":"","currentTagValue":"","disableDownsampling":false,"downsampleAggregator":"avg","downsampleFillPolicy":"none","filters":[{"filter":"$type","groupBy":false,"tagk":"type","type":"iliteral_or"},{"filter":"*","groupBy":true,"tagk":"site","type":"wildcard"}],"hide":false,"metric":"ap.clt.health","refId":"A","shouldComputeTopN":true,"tags":{}},{"aggregator":"count","alias":"","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","hide":true,"metric":"ap.clt.health","refId":"B","tags":{"floor":"$floor"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Top Locations Affected by Poor Performance","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"short","label":"","logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{"ap.client.count":"super-light-blue","clnt.associate{type=associated}":"dark-blue","clt.loc.traffic":"blue","test.traffic":"light-blue"},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":0,"fillGradient":0,"gridPos":{"h":8,"w":12,"x":12,"y":16},"hiddenSeries":false,"id":16,"legend":{"alignAsTable":true,"avg":false,"current":false,"max":false,"min":false,"rightSide":false,"show":false,"total":false,"values":false},"lines":true,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[{"alias":"clt.loc.traffic","bars":true,"lines":false,"points":false,"yaxis":2},{"alias":"ap.client.count","bars":false,"lines":true,"points":true},{}],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"sum","alias":"","currentTagKey":"","currentTagValue":"","disableDownsampling":false,"downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","hide":false,"metric":"clt.loc.traffic","refId":"A","tags":{}},{"aggregator":"count","downsampleAggregator":"avg","downsampleFillPolicy":"none","hide":false,"metric":"ap.client.count","refId":"C"}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Network Usage","tooltip":{"shared":true,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"time","name":null,"show":true,"values":[]},"yaxes":[{"format":"short","label":"No of clients","logBase":1,"max":null,"min":"0","show":true},{"format":"decbytes","label":"Traffic Volumes","logBase":1,"max":null,"min":"0","show":true}],"yaxis":{"align":false,"alignLevel":4}}],"refresh":false,"schemaVersion":19,"style":"dark","tags":[],"templating":{"list":[{"allValue":null,"current":{},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,site)","hide":0,"includeAll":true,"label":"site","multi":false,"name":"site","options":[],"query":"tag_values(clt.loc.traffic,site)","refresh":1,"regex":"","skipUrlSync":false,"sort":3,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,building,site=$site)","hide":0,"includeAll":true,"label":"building","multi":false,"name":"building","options":[],"query":"tag_values(clt.loc.traffic,building,site=$site)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.datarate,floor)","hide":0,"includeAll":true,"label":"floor","multi":false,"name":"floor","options":[],"query":"tag_values(clt.loc.datarate,floor)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,ssid)","hide":0,"includeAll":true,"label":"ssid","multi":false,"name":"ssid","options":[],"query":"tag_values(clt.loc.traffic,ssid)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{},"datasource":"OpenTSDB","definition":"tag_values(ap.clt.health,type)","hide":0,"includeAll":true,"label":"type","multi":false,"name":"type","options":[],"query":"tag_values(ap.clt.health,type)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false}]},"time":{"from":"now-30d","to":"now"},"timepicker":{"refresh_intervals":["5s","10s","30s","1m","5m","15m","30m","1h","2h","1d"]},"timezone":"","title":"Performance Dashboard","uid":"ZDLeDT1Zk","version":3}
314	10	2	0	3	2020-01-20 14:10:59	1		{"annotations":{"list":[{"builtIn":1,"datasource":"-- Grafana --","enable":true,"hide":true,"iconColor":"rgba(0, 211, 255, 1)","name":"Annotations \\u0026 Alerts","type":"dashboard"}]},"editable":true,"gnetId":null,"graphTooltip":0,"id":10,"iteration":1579529450534,"links":[],"panels":[{"aliasColors":{"Tried to Connect":"rgba(0, 0, 0, 0.77)","clt.loc.association{type=associated, status=success}":"#1250B0","success":"#5794F2"},"breakPoint":"100%","cacheTimeout":null,"combine":{"label":"Others","threshold":0},"datasource":"OpenTSDB","fontSize":"80%","format":"short","gridPos":{"h":8,"w":4,"x":0,"y":0},"id":6,"interval":null,"legend":{"percentage":false,"show":true,"values":true},"legendType":"Under graph","links":[],"maxDataPoints":3,"nullPointMode":"connected","options":{},"pieType":"donut","strokeWidth":"3","targets":[{"aggregator":"count","alias":"Tried to Connect","currentFilterGroupBy":false,"currentFilterKey":"","currentFilterType":"literal_or","currentFilterValue":"","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"nan","explicitTags":false,"filters":[],"isCounter":false,"metric":"clt.loc.association","refId":"A","shouldComputeRate":false,"shouldComputeTopN":false,"tags":{"status":"*","type":"associated"}}],"timeFrom":null,"timeShift":null,"title":"Total Clients","transparent":true,"type":"grafana-piechart-panel","valueName":"total"},{"aliasColors":{"Associated":"rgba(0, 0, 0, 0.08)","clt.loc.association{type=associated, status=success}":"#1250B0","success":"#5794F2"},"breakPoint":"50%","cacheTimeout":null,"combine":{"label":"Others","threshold":0},"datasource":"OpenTSDB","fontSize":"80%","format":"short","gridPos":{"h":8,"w":4,"x":5,"y":0},"id":11,"interval":null,"legend":{"show":true,"values":true},"legendType":"Under graph","links":[],"maxDataPoints":3,"nullPointMode":"connected","options":{},"pieType":"donut","strokeWidth":1,"targets":[{"aggregator":"count","alias":"Associated","currentFilterGroupBy":false,"currentFilterKey":"","currentFilterType":"literal_or","currentFilterValue":"","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"nan","explicitTags":false,"filters":[],"isCounter":false,"metric":"clt.loc.association","refId":"A","shouldComputeRate":false,"shouldComputeTopN":false,"tags":{"status":"*","type":"associated"}}],"timeFrom":null,"timeShift":null,"title":"Associated","transparent":true,"type":"grafana-piechart-panel","valueName":"current"},{"aliasColors":{"failure":"#FF7383","success":"rgba(0, 0, 0, 0.08)"},"breakPoint":"50%","cacheTimeout":null,"combine":{"label":"Others","threshold":0},"datasource":"OpenTSDB","fontSize":"80%","format":"short","gridPos":{"h":8,"w":4,"x":10,"y":0},"id":9,"interval":null,"legend":{"show":true,"values":true},"legendType":"Under graph","links":[],"maxDataPoints":3,"nullPointMode":"connected","options":{},"pieType":"donut","strokeWidth":"3","targets":[{"aggregator":"sum","alias":"$tag_status","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","metric":"clt.loc.association","refId":"A","shouldComputeRate":false,"tags":{"type":"associated"}}],"timeFrom":null,"timeShift":null,"title":"Authenticated","transparent":true,"type":"grafana-piechart-panel","valueName":"current"},{"aliasColors":{"failure":"#F2495C","success":"rgba(0, 0, 0, 0.09)"},"breakPoint":"50%","cacheTimeout":null,"combine":{"label":"Others","threshold":0},"datasource":"OpenTSDB","fontSize":"80%","format":"short","gridPos":{"h":8,"w":4,"x":15,"y":0},"id":8,"interval":null,"legend":{"show":true,"values":true},"legendType":"Under graph","links":[],"maxDataPoints":3,"nullPointMode":"connected","options":{},"pieType":"donut","pluginVersion":"6.5.0-pre","strokeWidth":1,"targets":[{"aggregator":"sum","alias":"success","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","metric":"clt.loc.association","refId":"A","shouldComputeRate":false,"tags":{"type":"associated"}}],"timeFrom":null,"timeShift":null,"title":"Network","transparent":true,"type":"grafana-piechart-panel","valueName":"total"},{"aliasColors":{"Online":"rgba(0, 0, 0, 0.28)","failure":"#F2495C","success":"#73BF69"},"breakPoint":"50%","cacheTimeout":null,"combine":{"label":"Others","threshold":0},"datasource":"OpenTSDB","fontSize":"80%","format":"short","gridPos":{"h":8,"w":4,"x":20,"y":0},"id":10,"interval":null,"legend":{"show":true,"sortDesc":true,"values":true},"legendType":"Under graph","links":[],"maxDataPoints":3,"nullPointMode":"connected","options":{},"pieType":"donut","strokeWidth":1,"targets":[{"aggregator":"sum","alias":"Online","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","metric":"clt.loc.association","refId":"A","shouldComputeRate":false,"tags":{"type":"associated"}}],"timeFrom":null,"timeShift":null,"title":"Online","transparent":true,"type":"grafana-piechart-panel","valueName":"current"},{"columns":[{"text":"Count","value":"count"}],"datasource":"OpenTSDB","fontSize":"100%","gridPos":{"h":8,"w":12,"x":0,"y":8},"id":15,"options":{},"pageSize":null,"showHeader":true,"sort":{"col":null,"desc":false},"styles":[{"alias":"Time","dateFormat":"YYYY-MM-DD HH:mm:ss","link":false,"pattern":"Time","type":"date"},{"alias":"client_macId","colorMode":null,"colors":["#5794F2","#C4162A","#8AB8FF"],"decimals":2,"link":false,"pattern":"Metric","thresholds":[],"type":"number","unit":"short"},{"alias":"","colorMode":null,"colors":["rgba(245, 54, 54, 0.9)","rgba(237, 129, 40, 0.89)","rgba(50, 172, 45, 0.97)"],"dateFormat":"YYYY-MM-DD HH:mm:ss","decimals":2,"mappingType":1,"pattern":"","thresholds":[],"type":"number","unit":"short"}],"targets":[{"aggregator":"count","alias":"$tag_macid","currentFilterGroupBy":false,"currentFilterKey":"","currentFilterType":"literal_or","currentFilterValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","filters":[{"filter":"$site","groupBy":false,"tagk":"site","type":"literal_or"},{"filter":"$building","groupBy":false,"tagk":"building","type":"literal_or"},{"filter":"$floor","groupBy":false,"tagk":"floor","type":"literal_or"},{"filter":"*","groupBy":true,"tagk":"macid","type":"wildcard"}],"metric":"clt.loc.association","refId":"A"}],"timeFrom":null,"timeShift":null,"title":"Clients by Most Failed Connections","transform":"timeseries_aggregations","type":"table"},{"aliasColors":{},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":8,"w":12,"x":12,"y":8},"hiddenSeries":false,"id":17,"legend":{"avg":false,"current":false,"max":false,"min":false,"show":false,"total":false,"values":false},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"count","alias":"$tag_site","counterTop":"5","currentFilterGroupBy":false,"currentFilterKey":"building","currentFilterType":"literal_or","currentFilterValue":"","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","filters":[{"filter":"$type","groupBy":false,"tagk":"type","type":"literal_or"},{"filter":"$site","groupBy":true,"tagk":"site","type":"literal_or"}],"metric":"clt.loc.association","refId":"A","shouldComputeTopN":true,"tags":{}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Top Locations Affected by Failures","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":true,"values":["total"]},"yaxes":[{"format":"short","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":"0","show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{"UHN1TKY311008":"dark-red"},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":8,"w":12,"x":0,"y":16},"hiddenSeries":false,"id":2,"legend":{"avg":false,"current":false,"max":false,"min":false,"rightSide":true,"show":true,"total":false,"values":false},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"sum","alias":"$tag_macid","counterTop":"10","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","metric":"clt.loc.traffic","refId":"A","shouldComputeTopN":true,"tags":{"building":"$building","floor":"$floor","macid":"*"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Top 10 client by traffic","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"decbytes","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":"0","show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":8,"w":12,"x":12,"y":16},"hiddenSeries":false,"id":4,"legend":{"avg":false,"current":false,"max":false,"min":false,"rightSide":true,"show":true,"total":false,"values":false},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"sum","alias":"$tag_macid","counterTop":"10","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","metric":"ap.mac.session","refId":"A","shouldComputeTopN":true,"tags":{"building":"$building","floor":"$floor","macid":"*"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Top 10 clients by session","tooltip":{"shared":true,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"s","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":"0","show":true}],"yaxis":{"align":false,"alignLevel":null}}],"refresh":false,"schemaVersion":19,"style":"dark","tags":["OpenNMS"],"templating":{"list":[{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,site)","hide":0,"includeAll":true,"label":null,"multi":false,"name":"site","options":[],"query":"tag_values(clt.loc.traffic,site)","refresh":1,"regex":"","skipUrlSync":false,"sort":1,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,building,site=$site)","hide":0,"includeAll":true,"label":"building","multi":false,"name":"building","options":[],"query":"tag_values(clt.loc.traffic,building,site=$site)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,floor)","hide":0,"includeAll":true,"label":"floor","multi":false,"name":"floor","options":[],"query":"tag_values(clt.loc.traffic,floor)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.association,type)","hide":0,"includeAll":true,"label":"type","multi":false,"name":"type","options":[],"query":"tag_values(clt.loc.association,type)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false}]},"time":{"from":"now-30d","to":"now"},"timepicker":{"refresh_intervals":["5s","10s","30s","1m","5m","15m","30m","1h","2h","1d"]},"timezone":"","title":"Connectivity Dashboard","uid":"1kKTUf1Zz","version":3}
316	9	4	0	5	2020-01-21 08:09:27	1		{"annotations":{"list":[{"builtIn":1,"datasource":"-- Grafana --","enable":true,"hide":true,"iconColor":"rgba(0, 211, 255, 1)","name":"Annotations \\u0026 Alerts","type":"dashboard"}]},"editable":true,"gnetId":null,"graphTooltip":0,"id":9,"iteration":1579594035262,"links":[],"panels":[{"cacheTimeout":null,"datasource":"OpenTSDB","gridPos":{"h":8,"w":12,"x":0,"y":0},"id":8,"links":[],"options":{"fieldOptions":{"calcs":["sum"],"defaults":{"mappings":[{"id":0,"op":"=","text":"N/A","type":1,"value":"null"}],"max":100,"min":0,"nullValueMode":"connected","thresholds":[{"color":"super-light-blue","value":null},{"color":"red","value":80}],"title":"","unit":"none"},"override":{},"values":false},"orientation":"horizontal","showThresholdLabels":false,"showThresholdMarkers":false},"pluginVersion":"6.4.0-pre","targets":[{"aggregator":"count","alias":"Total Client","currentFilterGroupBy":false,"currentFilterKey":"macid","currentFilterType":"regexp","currentFilterValue":"r.*","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","filters":[],"hide":false,"metric":"ap.client.count","refId":"B","tags":{"type":"ap"}},{"aggregator":"count","alias":"$tag_type","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","hide":false,"metric":"ap.clt.health","refId":"A","tags":{"type":"$type"}}],"timeFrom":null,"timeShift":null,"title":"Client Health","type":"gauge"},{"aliasColors":{"Count":"blue","clt.loc.datarate{site=Chennai, floor=Floor3, type=client, building=SDB5}":"super-light-blue"},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":8,"w":12,"x":12,"y":0},"hiddenSeries":false,"id":2,"legend":{"avg":true,"current":false,"max":false,"min":false,"rightSide":true,"show":false,"total":false,"values":true},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"avg","alias":"","currentFilterGroupBy":false,"currentFilterKey":"","currentFilterType":"literal_or","currentFilterValue":"","currentTagKey":"floor","currentTagValue":"$floor","downsampleAggregator":"avg","downsampleFillPolicy":"none","filters":[{"filter":"$site","groupBy":false,"tagk":"site","type":"literal_or"},{"filter":"$building","groupBy":false,"tagk":"building","type":"literal_or"},{"filter":"$floor","groupBy":false,"tagk":"floor","type":"literal_or"},{"filter":"client","groupBy":false,"tagk":"type","type":"literal_or"}],"metric":"clt.loc.datarate","refId":"A","tags":{}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Clients by Average  Data Rate","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":5,"max":null,"min":0,"mode":"histogram","name":null,"show":true,"values":["total"]},"yaxes":[{"format":"short","label":"No of clients","logBase":1,"max":null,"min":"0","show":true},{"format":"Bps","label":"","logBase":1,"max":null,"min":"0","show":true}],"yaxis":{"align":true,"alignLevel":50}},{"aliasColors":{"Count":"blue","ap.clt.rssi{floor=Floor1}":"semi-dark-blue","ap.clt.rssi{floor=Floor3}":"light-blue"},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":8,"w":12,"x":0,"y":8},"hiddenSeries":false,"id":10,"legend":{"alignAsTable":false,"avg":true,"current":false,"max":false,"min":false,"rightSide":false,"show":false,"total":false,"values":true},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"avg","alias":"","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","metric":"ap.clt.rssi","refId":"A","tags":{"floor":"$floor"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Clients by RSSI","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":5,"max":null,"min":0,"mode":"histogram","name":null,"show":true,"values":["total"]},"yaxes":[{"format":"short","label":"No of clients","logBase":1,"max":null,"min":"0","show":true},{"format":"dBm","label":null,"logBase":1,"max":null,"min":"0","show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{"04-79-70-73-87-ce":"super-light-blue","20-34-fb-81-19-cd":"super-light-green","70-bb-e9-25-1c-bc":"super-light-yellow","a1-3e-0e-5e-80-a1":"super-light-blue","a10-3e-0e-5e-80-a1":"semi-dark-blue","a13-3e-0e-5e-80-a1":"rgb(130, 130, 247)","a14-3e-0e-5e-80-a1":"semi-dark-blue","a16-3e-0e-5e-80-a1":"super-light-blue","a17-3e-0e-5e-80-a1":"blue","a18-3e-0e-5e-80-a1":"light-blue","a24-3e-0e-5e-80-a1":"rgb(4, 49, 120)","a27-3e-0e-5e-80-a1":"dark-blue","a3-3e-0e-5e-80-a1":"light-blue","a37-3e-0e-5e-80-a1":"super-light-blue","a38-3e-0e-5e-80-a1":"super-light-blue","a40-3e-0e-5e-80-a1":"semi-dark-blue","a6-3e-0e-5e-80-a1":"dark-blue","a8-3e-0e-5e-80-a1":"super-light-blue"},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":8,"w":12,"x":12,"y":8},"hiddenSeries":false,"id":4,"legend":{"avg":false,"current":false,"max":false,"min":false,"rightSide":true,"show":true,"total":false,"values":false},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"sum","alias":"$tag_macid","counterTop":"5","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","metric":"clt.loc.traffic","refId":"A","shouldComputeTopN":true,"tags":{"floor":"$floor","macid":"*","ssid":"$ssid"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Clients With Most Traffic","tooltip":{"shared":true,"sort":2,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"decbytes","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":12}},{"aliasColors":{"ap.clt.health{floor=Floor1, type=LowRSSI}":"super-light-blue","ap.clt.health{floor=Floor2, type=LowRSSI}":"light-blue","ap.clt.health{floor=Floor3, type=LowRSSI}":"super-light-blue"},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":8,"w":12,"x":0,"y":16},"hiddenSeries":false,"id":12,"legend":{"avg":false,"current":false,"max":false,"min":false,"rightSide":true,"show":true,"total":false,"values":false},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"count","alias":"$tag_site","counterTop":"5","currentFilterGroupBy":false,"currentFilterKey":"","currentFilterType":"literal_or","currentFilterValue":"","currentTagKey":"","currentTagValue":"","disableDownsampling":false,"downsampleAggregator":"avg","downsampleFillPolicy":"none","filters":[{"filter":"$type","groupBy":false,"tagk":"type","type":"iliteral_or"},{"filter":"*","groupBy":true,"tagk":"site","type":"wildcard"}],"hide":false,"metric":"ap.clt.health","refId":"A","shouldComputeTopN":true,"tags":{}},{"aggregator":"count","alias":"","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","hide":true,"metric":"ap.clt.health","refId":"B","tags":{"floor":"$floor"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Top Locations Affected by Poor Performance","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"short","label":"","logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{"ap.client.count":"super-light-blue","clnt.associate{type=associated}":"dark-blue","clt.loc.traffic":"blue","test.traffic":"light-blue"},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":0,"fillGradient":0,"gridPos":{"h":8,"w":12,"x":12,"y":16},"hiddenSeries":false,"id":16,"legend":{"alignAsTable":true,"avg":false,"current":false,"max":false,"min":false,"rightSide":false,"show":false,"total":false,"values":false},"lines":true,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[{"alias":"clt.loc.traffic","bars":true,"lines":false,"points":false,"yaxis":2},{"alias":"ap.client.count","bars":false,"lines":true,"points":true},{}],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"sum","alias":"","currentTagKey":"","currentTagValue":"","disableDownsampling":false,"downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","hide":false,"metric":"clt.loc.traffic","refId":"A","tags":{}},{"aggregator":"count","downsampleAggregator":"avg","downsampleFillPolicy":"none","hide":false,"metric":"ap.client.count","refId":"C"}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Network Usage","tooltip":{"shared":true,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"time","name":null,"show":true,"values":[]},"yaxes":[{"format":"short","label":"No of clients","logBase":1,"max":null,"min":"0","show":true},{"format":"decbytes","label":"Traffic Volumes","logBase":1,"max":null,"min":"0","show":true}],"yaxis":{"align":false,"alignLevel":4}}],"refresh":false,"schemaVersion":19,"style":"dark","tags":["OpenNMS"],"templating":{"list":[{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,site)","hide":0,"includeAll":true,"label":"site","multi":false,"name":"site","options":[],"query":"tag_values(clt.loc.traffic,site)","refresh":1,"regex":"","skipUrlSync":false,"sort":3,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,building,site=$site)","hide":0,"includeAll":true,"label":"building","multi":false,"name":"building","options":[],"query":"tag_values(clt.loc.traffic,building,site=$site)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.datarate,floor)","hide":0,"includeAll":true,"label":"floor","multi":false,"name":"floor","options":[],"query":"tag_values(clt.loc.datarate,floor)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,ssid)","hide":0,"includeAll":true,"label":"ssid","multi":false,"name":"ssid","options":[],"query":"tag_values(clt.loc.traffic,ssid)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(ap.clt.health,type)","hide":0,"includeAll":true,"label":"type","multi":false,"name":"type","options":[],"query":"tag_values(ap.clt.health,type)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false}]},"time":{"from":"now-30d","to":"now"},"timepicker":{"refresh_intervals":["5s","10s","30s","1m","5m","15m","30m","1h","2h","1d"]},"timezone":"","title":"Performance Dashboard","uid":"ZDLeDT1Zk","version":5}
317	9	5	0	6	2020-01-21 08:28:39	1		{"annotations":{"list":[{"builtIn":1,"datasource":"-- Grafana --","enable":true,"hide":true,"iconColor":"rgba(0, 211, 255, 1)","name":"Annotations \\u0026 Alerts","type":"dashboard"}]},"editable":true,"gnetId":null,"graphTooltip":0,"id":9,"iteration":1579594035262,"links":[],"panels":[{"cacheTimeout":null,"datasource":"OpenTSDB","gridPos":{"h":8,"w":12,"x":0,"y":0},"id":8,"links":[],"options":{"fieldOptions":{"calcs":["sum"],"defaults":{"mappings":[{"id":0,"op":"=","text":"N/A","type":1,"value":"null"}],"max":100,"min":0,"nullValueMode":"connected","thresholds":[{"color":"super-light-blue","value":null},{"color":"red","value":80}],"title":"","unit":"none"},"override":{},"values":false},"orientation":"horizontal","showThresholdLabels":false,"showThresholdMarkers":false},"pluginVersion":"6.4.0-pre","targets":[{"aggregator":"count","alias":"Total Client","currentFilterGroupBy":false,"currentFilterKey":"macid","currentFilterType":"regexp","currentFilterValue":"r.*","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","filters":[],"hide":false,"metric":"ap.client.count","refId":"B","tags":{"type":"ap"}},{"aggregator":"count","alias":"$tag_type","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","hide":false,"metric":"ap.clt.health","refId":"A","tags":{"type":"$type"}}],"timeFrom":null,"timeShift":null,"title":"Client Health","type":"gauge"},{"aliasColors":{"Count":"blue","clt.loc.datarate{site=Chennai, floor=Floor3, type=client, building=SDB5}":"super-light-blue"},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":8,"w":12,"x":12,"y":0},"hiddenSeries":false,"id":2,"legend":{"avg":true,"current":false,"max":false,"min":false,"rightSide":true,"show":false,"total":false,"values":true},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"avg","alias":"","currentFilterGroupBy":false,"currentFilterKey":"","currentFilterType":"literal_or","currentFilterValue":"","currentTagKey":"floor","currentTagValue":"$floor","downsampleAggregator":"avg","downsampleFillPolicy":"none","filters":[{"filter":"$site","groupBy":false,"tagk":"site","type":"literal_or"},{"filter":"$building","groupBy":false,"tagk":"building","type":"literal_or"},{"filter":"$floor","groupBy":false,"tagk":"floor","type":"literal_or"},{"filter":"client","groupBy":false,"tagk":"type","type":"literal_or"}],"metric":"clt.loc.datarate","refId":"A","tags":{}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Clients by Average  Data Rate","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":5,"max":null,"min":0,"mode":"histogram","name":null,"show":true,"values":["total"]},"yaxes":[{"format":"short","label":"No of clients","logBase":1,"max":null,"min":"0","show":true},{"format":"Bps","label":"","logBase":1,"max":null,"min":"0","show":true}],"yaxis":{"align":true,"alignLevel":50}},{"aliasColors":{"Count":"blue","ap.clt.rssi{floor=Floor1}":"semi-dark-blue","ap.clt.rssi{floor=Floor3}":"light-blue"},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":8,"w":12,"x":0,"y":8},"hiddenSeries":false,"id":10,"legend":{"alignAsTable":false,"avg":true,"current":false,"max":false,"min":false,"rightSide":false,"show":false,"total":false,"values":true},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"avg","alias":"","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","metric":"ap.clt.rssi","refId":"A","tags":{"floor":"$floor"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Clients by RSSI","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":5,"max":null,"min":0,"mode":"histogram","name":null,"show":true,"values":["total"]},"yaxes":[{"format":"short","label":"No of clients","logBase":1,"max":null,"min":"0","show":true},{"format":"dBm","label":null,"logBase":1,"max":null,"min":"0","show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{"04-79-70-73-87-ce":"super-light-blue","20-34-fb-81-19-cd":"super-light-green","70-bb-e9-25-1c-bc":"super-light-yellow","a1-3e-0e-5e-80-a1":"super-light-blue","a10-3e-0e-5e-80-a1":"semi-dark-blue","a13-3e-0e-5e-80-a1":"rgb(130, 130, 247)","a14-3e-0e-5e-80-a1":"semi-dark-blue","a16-3e-0e-5e-80-a1":"super-light-blue","a17-3e-0e-5e-80-a1":"blue","a18-3e-0e-5e-80-a1":"light-blue","a24-3e-0e-5e-80-a1":"rgb(4, 49, 120)","a27-3e-0e-5e-80-a1":"dark-blue","a3-3e-0e-5e-80-a1":"light-blue","a37-3e-0e-5e-80-a1":"super-light-blue","a38-3e-0e-5e-80-a1":"super-light-blue","a40-3e-0e-5e-80-a1":"semi-dark-blue","a6-3e-0e-5e-80-a1":"dark-blue","a8-3e-0e-5e-80-a1":"super-light-blue"},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":8,"w":12,"x":12,"y":8},"hiddenSeries":false,"id":4,"legend":{"avg":false,"current":false,"max":false,"min":false,"rightSide":true,"show":true,"total":false,"values":false},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"sum","alias":"$tag_macid","counterTop":"5","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","metric":"clt.loc.traffic","refId":"A","shouldComputeTopN":true,"tags":{"floor":"$floor","macid":"*","ssid":"$ssid"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Clients With Most Traffic","tooltip":{"shared":true,"sort":2,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"decbytes","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":12}},{"aliasColors":{"ap.clt.health{floor=Floor1, type=LowRSSI}":"super-light-blue","ap.clt.health{floor=Floor2, type=LowRSSI}":"light-blue","ap.clt.health{floor=Floor3, type=LowRSSI}":"super-light-blue"},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":8,"w":12,"x":0,"y":16},"hiddenSeries":false,"id":12,"legend":{"avg":false,"current":false,"max":false,"min":false,"rightSide":true,"show":true,"total":false,"values":false},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"count","alias":"$tag_site","counterTop":"5","currentFilterGroupBy":false,"currentFilterKey":"","currentFilterType":"literal_or","currentFilterValue":"","currentTagKey":"","currentTagValue":"","disableDownsampling":false,"downsampleAggregator":"avg","downsampleFillPolicy":"none","filters":[{"filter":"$type","groupBy":false,"tagk":"type","type":"iliteral_or"},{"filter":"*","groupBy":true,"tagk":"site","type":"wildcard"}],"hide":false,"metric":"ap.clt.health","refId":"A","shouldComputeTopN":true,"tags":{}},{"aggregator":"count","alias":"","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","hide":true,"metric":"ap.clt.health","refId":"B","tags":{"floor":"$floor"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Top Locations Affected by Poor Performance","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"short","label":"","logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{"ap.client.count":"super-light-blue","clnt.associate{type=associated}":"dark-blue","clt.loc.traffic":"blue","test.traffic":"light-blue"},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":0,"fillGradient":0,"gridPos":{"h":8,"w":12,"x":12,"y":16},"hiddenSeries":false,"id":16,"legend":{"alignAsTable":true,"avg":false,"current":false,"max":false,"min":false,"rightSide":false,"show":false,"total":false,"values":false},"lines":true,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[{"alias":"clt.loc.traffic","bars":true,"lines":false,"points":false,"yaxis":2},{"alias":"ap.client.count","bars":false,"lines":true,"points":true},{}],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"sum","alias":"","currentTagKey":"","currentTagValue":"","disableDownsampling":false,"downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","hide":false,"metric":"clt.loc.traffic","refId":"A","tags":{}},{"aggregator":"count","downsampleAggregator":"avg","downsampleFillPolicy":"none","hide":false,"metric":"ap.client.count","refId":"C"}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Network Usage","tooltip":{"shared":true,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"time","name":null,"show":true,"values":[]},"yaxes":[{"format":"short","label":"No of clients","logBase":1,"max":null,"min":"0","show":true},{"format":"decbytes","label":"Traffic Volumes","logBase":1,"max":null,"min":"0","show":true}],"yaxis":{"align":false,"alignLevel":4}}],"refresh":false,"schemaVersion":19,"style":"dark","tags":["OpenNMS"],"templating":{"list":[{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,site)","hide":0,"includeAll":true,"label":"site","multi":false,"name":"site","options":[],"query":"tag_values(clt.loc.traffic,site)","refresh":1,"regex":"","skipUrlSync":false,"sort":3,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,building,site=$site)","hide":0,"includeAll":true,"label":"building","multi":false,"name":"building","options":[],"query":"tag_values(clt.loc.traffic,building,site=$site)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.datarate,floor)","hide":0,"includeAll":true,"label":"floor","multi":false,"name":"floor","options":[],"query":"tag_values(clt.loc.datarate,floor)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,ssid)","hide":0,"includeAll":true,"label":"ssid","multi":false,"name":"ssid","options":[],"query":"tag_values(clt.loc.traffic,ssid)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(ap.clt.health,type)","hide":0,"includeAll":true,"label":"type","multi":false,"name":"type","options":[],"query":"tag_values(ap.clt.health,type)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false}]},"time":{"from":"now-30d","to":"now"},"timepicker":{"refresh_intervals":["5s","10s","30s","1m","5m","15m","30m","1h","2h","1d"]},"timezone":"","title":"Performance Dashboard","uid":"ZDLeDT1Zk","version":6}
298	9	274	0	1	2020-01-09 13:18:04	1		{"__requires":[{"id":"gauge","name":"Gauge","type":"panel","version":""},{"id":"grafana","name":"Grafana","type":"grafana","version":"6.5.0-pre"},{"id":"graph","name":"Graph","type":"panel","version":""},{"id":"opentsdb","name":"OpenTSDB","type":"datasource","version":"1.0.0"}],"annotations":{"list":[{"builtIn":1,"datasource":"-- Grafana --","enable":true,"hide":true,"iconColor":"rgba(0, 211, 255, 1)","name":"Annotations \\u0026 Alerts","type":"dashboard"}]},"editable":true,"gnetId":null,"graphTooltip":0,"id":null,"iteration":1578575780638,"links":[],"panels":[{"cacheTimeout":null,"datasource":"OpenTSDB","gridPos":{"h":8,"w":12,"x":0,"y":0},"id":8,"links":[],"options":{"fieldOptions":{"calcs":["sum"],"defaults":{"mappings":[{"id":0,"op":"=","text":"N/A","type":1,"value":"null"}],"max":100,"min":0,"nullValueMode":"connected","thresholds":[{"color":"super-light-blue","value":null},{"color":"red","value":80}],"title":"","unit":"none"},"override":{},"values":false},"orientation":"horizontal","showThresholdLabels":false,"showThresholdMarkers":false},"pluginVersion":"6.5.0-pre","targets":[{"aggregator":"count","alias":"Total Client","currentFilterGroupBy":false,"currentFilterKey":"macid","currentFilterType":"regexp","currentFilterValue":"r.*","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","filters":[],"hide":false,"metric":"ap.client.count","refId":"B","tags":{"type":"ap"}},{"aggregator":"count","alias":"$tag_type","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","hide":false,"metric":"ap.clt.health","refId":"A","tags":{"type":"$type"}}],"timeFrom":null,"timeShift":null,"title":"Client Health","type":"gauge"},{"aliasColors":{"Count":"blue","clt.loc.datarate{site=Chennai, floor=Floor3, type=client, building=SDB5}":"super-light-blue"},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":8,"w":12,"x":12,"y":0},"hiddenSeries":false,"id":2,"legend":{"avg":true,"current":false,"max":false,"min":false,"rightSide":true,"show":false,"total":false,"values":true},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"avg","alias":"","currentFilterGroupBy":false,"currentFilterKey":"","currentFilterType":"literal_or","currentFilterValue":"","currentTagKey":"floor","currentTagValue":"$floor","downsampleAggregator":"avg","downsampleFillPolicy":"none","filters":[{"filter":"$site","groupBy":false,"tagk":"site","type":"literal_or"},{"filter":"$building","groupBy":false,"tagk":"building","type":"literal_or"},{"filter":"$floor","groupBy":false,"tagk":"floor","type":"literal_or"},{"filter":"client","groupBy":false,"tagk":"type","type":"literal_or"}],"metric":"clt.loc.datarate","refId":"A","tags":{}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Clients by Average  Data Rate","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":5,"max":null,"min":0,"mode":"histogram","name":null,"show":true,"values":["total"]},"yaxes":[{"format":"short","label":"No of clients","logBase":1,"max":null,"min":"0","show":true},{"format":"Bps","label":"","logBase":1,"max":null,"min":"0","show":true}],"yaxis":{"align":true,"alignLevel":50}},{"aliasColors":{"Count":"blue","ap.clt.rssi{floor=Floor1}":"semi-dark-blue","ap.clt.rssi{floor=Floor3}":"light-blue"},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":8,"w":12,"x":0,"y":8},"hiddenSeries":false,"id":10,"legend":{"alignAsTable":false,"avg":true,"current":false,"max":false,"min":false,"rightSide":false,"show":false,"total":false,"values":true},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"avg","alias":"","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","metric":"ap.clt.rssi","refId":"A","tags":{"floor":"$floor"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Clients by RSSI","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":5,"max":null,"min":0,"mode":"histogram","name":null,"show":true,"values":["total"]},"yaxes":[{"format":"short","label":"No of clients","logBase":1,"max":null,"min":"0","show":true},{"format":"dBm","label":null,"logBase":1,"max":null,"min":"0","show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{"04-79-70-73-87-ce":"super-light-blue","20-34-fb-81-19-cd":"super-light-green","70-bb-e9-25-1c-bc":"super-light-yellow","a1-3e-0e-5e-80-a1":"super-light-blue","a10-3e-0e-5e-80-a1":"semi-dark-blue","a13-3e-0e-5e-80-a1":"rgb(130, 130, 247)","a14-3e-0e-5e-80-a1":"semi-dark-blue","a16-3e-0e-5e-80-a1":"super-light-blue","a17-3e-0e-5e-80-a1":"blue","a18-3e-0e-5e-80-a1":"light-blue","a24-3e-0e-5e-80-a1":"rgb(4, 49, 120)","a27-3e-0e-5e-80-a1":"dark-blue","a3-3e-0e-5e-80-a1":"light-blue","a37-3e-0e-5e-80-a1":"super-light-blue","a38-3e-0e-5e-80-a1":"super-light-blue","a40-3e-0e-5e-80-a1":"semi-dark-blue","a6-3e-0e-5e-80-a1":"dark-blue","a8-3e-0e-5e-80-a1":"super-light-blue"},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":8,"w":12,"x":12,"y":8},"hiddenSeries":false,"id":4,"legend":{"avg":false,"current":false,"max":false,"min":false,"rightSide":true,"show":true,"total":false,"values":false},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"sum","alias":"$tag_macid","counterTop":"5","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","metric":"clt.loc.traffic","refId":"A","shouldComputeTopN":true,"tags":{"floor":"$floor","macid":"*","ssid":"$ssid"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Clients With Most Traffic","tooltip":{"shared":true,"sort":2,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"decbytes","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":12}},{"aliasColors":{"ap.clt.health{floor=Floor1, type=LowRSSI}":"super-light-blue","ap.clt.health{floor=Floor2, type=LowRSSI}":"light-blue","ap.clt.health{floor=Floor3, type=LowRSSI}":"super-light-blue"},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":8,"w":12,"x":0,"y":16},"hiddenSeries":false,"id":12,"legend":{"avg":false,"current":false,"max":false,"min":false,"rightSide":true,"show":true,"total":false,"values":false},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"count","alias":"$tag_site","counterTop":"5","currentFilterGroupBy":false,"currentFilterKey":"","currentFilterType":"literal_or","currentFilterValue":"","currentTagKey":"","currentTagValue":"","disableDownsampling":false,"downsampleAggregator":"avg","downsampleFillPolicy":"none","filters":[{"filter":"$type","groupBy":false,"tagk":"type","type":"iliteral_or"},{"filter":"*","groupBy":true,"tagk":"site","type":"wildcard"}],"hide":false,"metric":"ap.clt.health","refId":"A","shouldComputeTopN":true,"tags":{}},{"aggregator":"count","alias":"","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","hide":true,"metric":"ap.clt.health","refId":"B","tags":{"floor":"$floor"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Top Locations Affected by Poor Performance","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"short","label":"","logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{"ap.client.count":"super-light-blue","clnt.associate{type=associated}":"dark-blue","clt.loc.traffic":"blue","test.traffic":"light-blue"},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":0,"fillGradient":0,"gridPos":{"h":8,"w":12,"x":12,"y":16},"hiddenSeries":false,"id":16,"legend":{"alignAsTable":true,"avg":false,"current":false,"max":false,"min":false,"rightSide":false,"show":false,"total":false,"values":false},"lines":true,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[{"alias":"clt.loc.traffic","bars":true,"lines":false,"points":false,"yaxis":2},{"alias":"ap.client.count","bars":false,"lines":true,"points":true},{}],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"sum","alias":"","currentTagKey":"","currentTagValue":"","disableDownsampling":false,"downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","hide":false,"metric":"clt.loc.traffic","refId":"A","tags":{}},{"aggregator":"count","downsampleAggregator":"avg","downsampleFillPolicy":"none","hide":false,"metric":"ap.client.count","refId":"C"}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Network Usage","tooltip":{"shared":true,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"time","name":null,"show":true,"values":[]},"yaxes":[{"format":"short","label":"No of clients","logBase":1,"max":null,"min":"0","show":true},{"format":"decbytes","label":"Traffic Volumes","logBase":1,"max":null,"min":"0","show":true}],"yaxis":{"align":false,"alignLevel":4}}],"refresh":false,"schemaVersion":20,"style":"dark","tags":[],"templating":{"list":[{"allValue":null,"current":{},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,site)","hide":0,"includeAll":true,"label":"site","multi":false,"name":"site","options":[],"query":"tag_values(clt.loc.traffic,site)","refresh":1,"regex":"","skipUrlSync":false,"sort":3,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,building,site=$site)","hide":0,"includeAll":true,"label":"building","multi":false,"name":"building","options":[],"query":"tag_values(clt.loc.traffic,building,site=$site)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.datarate,floor)","hide":0,"includeAll":true,"label":"floor","multi":false,"name":"floor","options":[],"query":"tag_values(clt.loc.datarate,floor)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,ssid)","hide":0,"includeAll":true,"label":"ssid","multi":false,"name":"ssid","options":[],"query":"tag_values(clt.loc.traffic,ssid)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{},"datasource":"OpenTSDB","definition":"tag_values(ap.clt.health,type)","hide":0,"includeAll":true,"label":"type","multi":false,"name":"type","options":[],"query":"tag_values(ap.clt.health,type)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false}]},"time":{"from":"now-6h","to":"now"},"timepicker":{"refresh_intervals":["5s","10s","30s","1m","5m","15m","30m","1h","2h","1d"]},"timezone":"","title":"Performance Dashboard","uid":"ZDLeDT1Zk","version":1}
299	9	1	0	2	2020-01-09 13:18:52	1		{"annotations":{"list":[{"builtIn":1,"datasource":"-- Grafana --","enable":true,"hide":true,"iconColor":"rgba(0, 211, 255, 1)","name":"Annotations \\u0026 Alerts","type":"dashboard"}]},"editable":true,"gnetId":null,"graphTooltip":0,"id":9,"iteration":1578575884556,"links":[],"panels":[{"cacheTimeout":null,"datasource":"OpenTSDB","gridPos":{"h":8,"w":12,"x":0,"y":0},"id":8,"links":[],"options":{"fieldOptions":{"calcs":["sum"],"defaults":{"mappings":[{"id":0,"op":"=","text":"N/A","type":1,"value":"null"}],"max":100,"min":0,"nullValueMode":"connected","thresholds":[{"color":"super-light-blue","value":null},{"color":"red","value":80}],"title":"","unit":"none"},"override":{},"values":false},"orientation":"horizontal","showThresholdLabels":false,"showThresholdMarkers":false},"pluginVersion":"6.4.0-pre","targets":[{"aggregator":"count","alias":"Total Client","currentFilterGroupBy":false,"currentFilterKey":"macid","currentFilterType":"regexp","currentFilterValue":"r.*","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","filters":[],"hide":false,"metric":"ap.client.count","refId":"B","tags":{"type":"ap"}},{"aggregator":"count","alias":"$tag_type","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","hide":false,"metric":"ap.clt.health","refId":"A","tags":{"type":"$type"}}],"timeFrom":null,"timeShift":null,"title":"Client Health","type":"gauge"},{"aliasColors":{"Count":"blue","clt.loc.datarate{site=Chennai, floor=Floor3, type=client, building=SDB5}":"super-light-blue"},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":8,"w":12,"x":12,"y":0},"hiddenSeries":false,"id":2,"legend":{"avg":true,"current":false,"max":false,"min":false,"rightSide":true,"show":false,"total":false,"values":true},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"avg","alias":"","currentFilterGroupBy":false,"currentFilterKey":"","currentFilterType":"literal_or","currentFilterValue":"","currentTagKey":"floor","currentTagValue":"$floor","downsampleAggregator":"avg","downsampleFillPolicy":"none","filters":[{"filter":"$site","groupBy":false,"tagk":"site","type":"literal_or"},{"filter":"$building","groupBy":false,"tagk":"building","type":"literal_or"},{"filter":"$floor","groupBy":false,"tagk":"floor","type":"literal_or"},{"filter":"client","groupBy":false,"tagk":"type","type":"literal_or"}],"metric":"clt.loc.datarate","refId":"A","tags":{}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Clients by Average  Data Rate","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":5,"max":null,"min":0,"mode":"histogram","name":null,"show":true,"values":["total"]},"yaxes":[{"format":"short","label":"No of clients","logBase":1,"max":null,"min":"0","show":true},{"format":"Bps","label":"","logBase":1,"max":null,"min":"0","show":true}],"yaxis":{"align":true,"alignLevel":50}},{"aliasColors":{"Count":"blue","ap.clt.rssi{floor=Floor1}":"semi-dark-blue","ap.clt.rssi{floor=Floor3}":"light-blue"},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":8,"w":12,"x":0,"y":8},"hiddenSeries":false,"id":10,"legend":{"alignAsTable":false,"avg":true,"current":false,"max":false,"min":false,"rightSide":false,"show":false,"total":false,"values":true},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"avg","alias":"","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","metric":"ap.clt.rssi","refId":"A","tags":{"floor":"$floor"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Clients by RSSI","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":5,"max":null,"min":0,"mode":"histogram","name":null,"show":true,"values":["total"]},"yaxes":[{"format":"short","label":"No of clients","logBase":1,"max":null,"min":"0","show":true},{"format":"dBm","label":null,"logBase":1,"max":null,"min":"0","show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{"04-79-70-73-87-ce":"super-light-blue","20-34-fb-81-19-cd":"super-light-green","70-bb-e9-25-1c-bc":"super-light-yellow","a1-3e-0e-5e-80-a1":"super-light-blue","a10-3e-0e-5e-80-a1":"semi-dark-blue","a13-3e-0e-5e-80-a1":"rgb(130, 130, 247)","a14-3e-0e-5e-80-a1":"semi-dark-blue","a16-3e-0e-5e-80-a1":"super-light-blue","a17-3e-0e-5e-80-a1":"blue","a18-3e-0e-5e-80-a1":"light-blue","a24-3e-0e-5e-80-a1":"rgb(4, 49, 120)","a27-3e-0e-5e-80-a1":"dark-blue","a3-3e-0e-5e-80-a1":"light-blue","a37-3e-0e-5e-80-a1":"super-light-blue","a38-3e-0e-5e-80-a1":"super-light-blue","a40-3e-0e-5e-80-a1":"semi-dark-blue","a6-3e-0e-5e-80-a1":"dark-blue","a8-3e-0e-5e-80-a1":"super-light-blue"},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":8,"w":12,"x":12,"y":8},"hiddenSeries":false,"id":4,"legend":{"avg":false,"current":false,"max":false,"min":false,"rightSide":true,"show":true,"total":false,"values":false},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"sum","alias":"$tag_macid","counterTop":"5","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","metric":"clt.loc.traffic","refId":"A","shouldComputeTopN":true,"tags":{"floor":"$floor","macid":"*","ssid":"$ssid"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Clients With Most Traffic","tooltip":{"shared":true,"sort":2,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"decbytes","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":12}},{"aliasColors":{"ap.clt.health{floor=Floor1, type=LowRSSI}":"super-light-blue","ap.clt.health{floor=Floor2, type=LowRSSI}":"light-blue","ap.clt.health{floor=Floor3, type=LowRSSI}":"super-light-blue"},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":8,"w":12,"x":0,"y":16},"hiddenSeries":false,"id":12,"legend":{"avg":false,"current":false,"max":false,"min":false,"rightSide":true,"show":true,"total":false,"values":false},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"count","alias":"$tag_site","counterTop":"5","currentFilterGroupBy":false,"currentFilterKey":"","currentFilterType":"literal_or","currentFilterValue":"","currentTagKey":"","currentTagValue":"","disableDownsampling":false,"downsampleAggregator":"avg","downsampleFillPolicy":"none","filters":[{"filter":"$type","groupBy":false,"tagk":"type","type":"iliteral_or"},{"filter":"*","groupBy":true,"tagk":"site","type":"wildcard"}],"hide":false,"metric":"ap.clt.health","refId":"A","shouldComputeTopN":true,"tags":{}},{"aggregator":"count","alias":"","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","hide":true,"metric":"ap.clt.health","refId":"B","tags":{"floor":"$floor"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Top Locations Affected by Poor Performance","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"short","label":"","logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{"ap.client.count":"super-light-blue","clnt.associate{type=associated}":"dark-blue","clt.loc.traffic":"blue","test.traffic":"light-blue"},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":0,"fillGradient":0,"gridPos":{"h":8,"w":12,"x":12,"y":16},"hiddenSeries":false,"id":16,"legend":{"alignAsTable":true,"avg":false,"current":false,"max":false,"min":false,"rightSide":false,"show":false,"total":false,"values":false},"lines":true,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[{"alias":"clt.loc.traffic","bars":true,"lines":false,"points":false,"yaxis":2},{"alias":"ap.client.count","bars":false,"lines":true,"points":true},{}],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"sum","alias":"","currentTagKey":"","currentTagValue":"","disableDownsampling":false,"downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","hide":false,"metric":"clt.loc.traffic","refId":"A","tags":{}},{"aggregator":"count","downsampleAggregator":"avg","downsampleFillPolicy":"none","hide":false,"metric":"ap.client.count","refId":"C"}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Network Usage","tooltip":{"shared":true,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"time","name":null,"show":true,"values":[]},"yaxes":[{"format":"short","label":"No of clients","logBase":1,"max":null,"min":"0","show":true},{"format":"decbytes","label":"Traffic Volumes","logBase":1,"max":null,"min":"0","show":true}],"yaxis":{"align":false,"alignLevel":4}}],"refresh":false,"schemaVersion":19,"style":"dark","tags":[],"templating":{"list":[{"allValue":null,"current":{},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,site)","hide":0,"includeAll":true,"label":"site","multi":false,"name":"site","options":[],"query":"tag_values(clt.loc.traffic,site)","refresh":1,"regex":"","skipUrlSync":false,"sort":3,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,building,site=$site)","hide":0,"includeAll":true,"label":"building","multi":false,"name":"building","options":[],"query":"tag_values(clt.loc.traffic,building,site=$site)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.datarate,floor)","hide":0,"includeAll":true,"label":"floor","multi":false,"name":"floor","options":[],"query":"tag_values(clt.loc.datarate,floor)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,ssid)","hide":0,"includeAll":true,"label":"ssid","multi":false,"name":"ssid","options":[],"query":"tag_values(clt.loc.traffic,ssid)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{},"datasource":"OpenTSDB","definition":"tag_values(ap.clt.health,type)","hide":0,"includeAll":true,"label":"type","multi":false,"name":"type","options":[],"query":"tag_values(ap.clt.health,type)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false}]},"time":{"from":"now-6h","to":"now"},"timepicker":{"refresh_intervals":["5s","10s","30s","1m","5m","15m","30m","1h","2h","1d"]},"timezone":"","title":"Performance Dashboard","uid":"ZDLeDT1Zk","version":2}
300	10	108	0	1	2020-01-09 13:19:59	1		{"__requires":[{"id":"grafana","name":"Grafana","type":"grafana","version":"6.5.0-pre"},{"id":"grafana-piechart-panel","name":"Pie Chart","type":"panel","version":"1.3.9"},{"id":"graph","name":"Graph","type":"panel","version":""},{"id":"opentsdb","name":"OpenTSDB","type":"datasource","version":"1.0.0"},{"id":"table","name":"Table","type":"panel","version":""}],"annotations":{"list":[{"builtIn":1,"datasource":"-- Grafana --","enable":true,"hide":true,"iconColor":"rgba(0, 211, 255, 1)","name":"Annotations \\u0026 Alerts","type":"dashboard"}]},"editable":true,"gnetId":null,"graphTooltip":0,"id":null,"iteration":1578575969065,"links":[],"panels":[{"aliasColors":{"Tried to Connect":"rgba(0, 0, 0, 0.77)","clt.loc.association{type=associated, status=success}":"#1250B0","success":"#5794F2"},"breakPoint":"100%","cacheTimeout":null,"combine":{"label":"Others","threshold":0},"datasource":"OpenTSDB","fontSize":"80%","format":"short","gridPos":{"h":8,"w":4,"x":0,"y":0},"id":6,"interval":null,"legend":{"percentage":false,"show":true,"values":true},"legendType":"Under graph","links":[],"maxDataPoints":3,"nullPointMode":"connected","options":{},"pieType":"donut","strokeWidth":"3","targets":[{"aggregator":"count","alias":"Tried to Connect","currentFilterGroupBy":false,"currentFilterKey":"","currentFilterType":"literal_or","currentFilterValue":"","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"nan","explicitTags":false,"filters":[],"isCounter":false,"metric":"clt.loc.association","refId":"A","shouldComputeRate":false,"shouldComputeTopN":false,"tags":{"status":"*","type":"associated"}}],"timeFrom":null,"timeShift":null,"title":"Total Clients","transparent":true,"type":"grafana-piechart-panel","valueName":"total"},{"aliasColors":{"Associated":"rgba(0, 0, 0, 0.08)","clt.loc.association{type=associated, status=success}":"#1250B0","success":"#5794F2"},"breakPoint":"50%","cacheTimeout":null,"combine":{"label":"Others","threshold":0},"datasource":"OpenTSDB","fontSize":"80%","format":"short","gridPos":{"h":8,"w":4,"x":5,"y":0},"id":11,"interval":null,"legend":{"show":true,"values":true},"legendType":"Under graph","links":[],"maxDataPoints":3,"nullPointMode":"connected","options":{},"pieType":"donut","strokeWidth":1,"targets":[{"aggregator":"count","alias":"Associated","currentFilterGroupBy":false,"currentFilterKey":"","currentFilterType":"literal_or","currentFilterValue":"","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"nan","explicitTags":false,"filters":[],"isCounter":false,"metric":"clt.loc.association","refId":"A","shouldComputeRate":false,"shouldComputeTopN":false,"tags":{"status":"*","type":"associated"}}],"timeFrom":null,"timeShift":null,"title":"Associated","transparent":true,"type":"grafana-piechart-panel","valueName":"current"},{"aliasColors":{"failure":"#FF7383","success":"rgba(0, 0, 0, 0.08)"},"breakPoint":"50%","cacheTimeout":null,"combine":{"label":"Others","threshold":0},"datasource":"OpenTSDB","fontSize":"80%","format":"short","gridPos":{"h":8,"w":4,"x":10,"y":0},"id":9,"interval":null,"legend":{"show":true,"values":true},"legendType":"Under graph","links":[],"maxDataPoints":3,"nullPointMode":"connected","options":{},"pieType":"donut","strokeWidth":"3","targets":[{"aggregator":"sum","alias":"$tag_status","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","metric":"clt.loc.association","refId":"A","shouldComputeRate":false,"tags":{"type":"associated"}}],"timeFrom":null,"timeShift":null,"title":"Authenticated","transparent":true,"type":"grafana-piechart-panel","valueName":"current"},{"aliasColors":{"failure":"#F2495C","success":"rgba(0, 0, 0, 0.09)"},"breakPoint":"50%","cacheTimeout":null,"combine":{"label":"Others","threshold":0},"datasource":"OpenTSDB","fontSize":"80%","format":"short","gridPos":{"h":8,"w":4,"x":15,"y":0},"id":8,"interval":null,"legend":{"show":true,"values":true},"legendType":"Under graph","links":[],"maxDataPoints":3,"nullPointMode":"connected","options":{},"pieType":"donut","pluginVersion":"6.5.0-pre","strokeWidth":1,"targets":[{"aggregator":"sum","alias":"success","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","metric":"clt.loc.association","refId":"A","shouldComputeRate":false,"tags":{"type":"associated"}}],"timeFrom":null,"timeShift":null,"title":"Network","transparent":true,"type":"grafana-piechart-panel","valueName":"total"},{"aliasColors":{"Online":"rgba(0, 0, 0, 0.28)","failure":"#F2495C","success":"#73BF69"},"breakPoint":"50%","cacheTimeout":null,"combine":{"label":"Others","threshold":0},"datasource":"OpenTSDB","fontSize":"80%","format":"short","gridPos":{"h":8,"w":4,"x":20,"y":0},"id":10,"interval":null,"legend":{"show":true,"sortDesc":true,"values":true},"legendType":"Under graph","links":[],"maxDataPoints":3,"nullPointMode":"connected","options":{},"pieType":"donut","strokeWidth":1,"targets":[{"aggregator":"sum","alias":"Online","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","metric":"clt.loc.association","refId":"A","shouldComputeRate":false,"tags":{"type":"associated"}}],"timeFrom":null,"timeShift":null,"title":"Online","transparent":true,"type":"grafana-piechart-panel","valueName":"current"},{"columns":[{"text":"Count","value":"count"}],"datasource":"OpenTSDB","fontSize":"100%","gridPos":{"h":8,"w":12,"x":0,"y":8},"id":15,"options":{},"pageSize":null,"showHeader":true,"sort":{"col":null,"desc":false},"styles":[{"alias":"Time","dateFormat":"YYYY-MM-DD HH:mm:ss","link":false,"pattern":"Time","type":"date"},{"alias":"client_macId","colorMode":null,"colors":["#5794F2","#C4162A","#8AB8FF"],"decimals":2,"link":false,"pattern":"Metric","thresholds":[],"type":"number","unit":"short"},{"alias":"","colorMode":null,"colors":["rgba(245, 54, 54, 0.9)","rgba(237, 129, 40, 0.89)","rgba(50, 172, 45, 0.97)"],"dateFormat":"YYYY-MM-DD HH:mm:ss","decimals":2,"mappingType":1,"pattern":"","thresholds":[],"type":"number","unit":"short"}],"targets":[{"aggregator":"count","alias":"$tag_macid","currentFilterGroupBy":false,"currentFilterKey":"","currentFilterType":"literal_or","currentFilterValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","filters":[{"filter":"$site","groupBy":false,"tagk":"site","type":"literal_or"},{"filter":"$building","groupBy":false,"tagk":"building","type":"literal_or"},{"filter":"$floor","groupBy":false,"tagk":"floor","type":"literal_or"},{"filter":"*","groupBy":true,"tagk":"macid","type":"wildcard"}],"metric":"clt.loc.association","refId":"A"}],"timeFrom":null,"timeShift":null,"title":"Clients by Most Failed Connections","transform":"timeseries_aggregations","type":"table"},{"aliasColors":{},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":8,"w":12,"x":12,"y":8},"hiddenSeries":false,"id":17,"legend":{"avg":false,"current":false,"max":false,"min":false,"show":false,"total":false,"values":false},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"count","alias":"$tag_site","counterTop":"5","currentFilterGroupBy":false,"currentFilterKey":"building","currentFilterType":"literal_or","currentFilterValue":"","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","filters":[{"filter":"$type","groupBy":false,"tagk":"type","type":"literal_or"},{"filter":"$site","groupBy":true,"tagk":"site","type":"literal_or"}],"metric":"clt.loc.association","refId":"A","shouldComputeTopN":true,"tags":{}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Top Locations Affected by Failures","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":true,"values":["total"]},"yaxes":[{"format":"short","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":"0","show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{"UHN1TKY311008":"dark-red"},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":8,"w":12,"x":0,"y":16},"hiddenSeries":false,"id":2,"legend":{"avg":false,"current":false,"max":false,"min":false,"rightSide":true,"show":true,"total":false,"values":false},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"sum","alias":"$tag_macid","counterTop":"10","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","metric":"clt.loc.traffic","refId":"A","shouldComputeTopN":true,"tags":{"building":"$building","floor":"$floor","macid":"*"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Top 10 client by traffic","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"decbytes","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":"0","show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":8,"w":12,"x":12,"y":16},"hiddenSeries":false,"id":4,"legend":{"avg":false,"current":false,"max":false,"min":false,"rightSide":true,"show":true,"total":false,"values":false},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"sum","alias":"$tag_macid","counterTop":"10","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","metric":"ap.mac.session","refId":"A","shouldComputeTopN":true,"tags":{"building":"$building","floor":"$floor","macid":"*"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Top 10 clients by session","tooltip":{"shared":true,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"s","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":"0","show":true}],"yaxis":{"align":false,"alignLevel":null}}],"refresh":false,"schemaVersion":20,"style":"dark","tags":[],"templating":{"list":[{"allValue":null,"current":{},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,site)","hide":0,"includeAll":true,"label":null,"multi":false,"name":"site","options":[],"query":"tag_values(clt.loc.traffic,site)","refresh":1,"regex":"","skipUrlSync":false,"sort":1,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,building,site=$site)","hide":0,"includeAll":true,"label":"building","multi":false,"name":"building","options":[],"query":"tag_values(clt.loc.traffic,building,site=$site)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,floor)","hide":0,"includeAll":true,"label":"floor","multi":false,"name":"floor","options":[],"query":"tag_values(clt.loc.traffic,floor)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.association,type)","hide":0,"includeAll":true,"label":"type","multi":false,"name":"type","options":[],"query":"tag_values(clt.loc.association,type)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false}]},"time":{"from":"now-6h","to":"now"},"timepicker":{"refresh_intervals":["5s","10s","30s","1m","5m","15m","30m","1h","2h","1d"]},"timezone":"","title":"Connectivity Dashboard","uid":"1kKTUf1Zz","version":1}
308	10	1	0	2	2020-01-20 14:08:35	1		{"annotations":{"list":[{"builtIn":1,"datasource":"-- Grafana --","enable":true,"hide":true,"iconColor":"rgba(0, 211, 255, 1)","name":"Annotations \\u0026 Alerts","type":"dashboard"}]},"editable":true,"gnetId":null,"graphTooltip":0,"id":10,"iteration":1579529304405,"links":[],"panels":[{"aliasColors":{"Tried to Connect":"rgba(0, 0, 0, 0.77)","clt.loc.association{type=associated, status=success}":"#1250B0","success":"#5794F2"},"breakPoint":"100%","cacheTimeout":null,"combine":{"label":"Others","threshold":0},"datasource":"OpenTSDB","fontSize":"80%","format":"short","gridPos":{"h":8,"w":4,"x":0,"y":0},"id":6,"interval":null,"legend":{"percentage":false,"show":true,"values":true},"legendType":"Under graph","links":[],"maxDataPoints":3,"nullPointMode":"connected","options":{},"pieType":"donut","strokeWidth":"3","targets":[{"aggregator":"count","alias":"Tried to Connect","currentFilterGroupBy":false,"currentFilterKey":"","currentFilterType":"literal_or","currentFilterValue":"","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"nan","explicitTags":false,"filters":[],"isCounter":false,"metric":"clt.loc.association","refId":"A","shouldComputeRate":false,"shouldComputeTopN":false,"tags":{"status":"*","type":"associated"}}],"timeFrom":null,"timeShift":null,"title":"Total Clients","transparent":true,"type":"grafana-piechart-panel","valueName":"total"},{"aliasColors":{"Associated":"rgba(0, 0, 0, 0.08)","clt.loc.association{type=associated, status=success}":"#1250B0","success":"#5794F2"},"breakPoint":"50%","cacheTimeout":null,"combine":{"label":"Others","threshold":0},"datasource":"OpenTSDB","fontSize":"80%","format":"short","gridPos":{"h":8,"w":4,"x":5,"y":0},"id":11,"interval":null,"legend":{"show":true,"values":true},"legendType":"Under graph","links":[],"maxDataPoints":3,"nullPointMode":"connected","options":{},"pieType":"donut","strokeWidth":1,"targets":[{"aggregator":"count","alias":"Associated","currentFilterGroupBy":false,"currentFilterKey":"","currentFilterType":"literal_or","currentFilterValue":"","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"nan","explicitTags":false,"filters":[],"isCounter":false,"metric":"clt.loc.association","refId":"A","shouldComputeRate":false,"shouldComputeTopN":false,"tags":{"status":"*","type":"associated"}}],"timeFrom":null,"timeShift":null,"title":"Associated","transparent":true,"type":"grafana-piechart-panel","valueName":"current"},{"aliasColors":{"failure":"#FF7383","success":"rgba(0, 0, 0, 0.08)"},"breakPoint":"50%","cacheTimeout":null,"combine":{"label":"Others","threshold":0},"datasource":"OpenTSDB","fontSize":"80%","format":"short","gridPos":{"h":8,"w":4,"x":10,"y":0},"id":9,"interval":null,"legend":{"show":true,"values":true},"legendType":"Under graph","links":[],"maxDataPoints":3,"nullPointMode":"connected","options":{},"pieType":"donut","strokeWidth":"3","targets":[{"aggregator":"sum","alias":"$tag_status","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","metric":"clt.loc.association","refId":"A","shouldComputeRate":false,"tags":{"type":"associated"}}],"timeFrom":null,"timeShift":null,"title":"Authenticated","transparent":true,"type":"grafana-piechart-panel","valueName":"current"},{"aliasColors":{"failure":"#F2495C","success":"rgba(0, 0, 0, 0.09)"},"breakPoint":"50%","cacheTimeout":null,"combine":{"label":"Others","threshold":0},"datasource":"OpenTSDB","fontSize":"80%","format":"short","gridPos":{"h":8,"w":4,"x":15,"y":0},"id":8,"interval":null,"legend":{"show":true,"values":true},"legendType":"Under graph","links":[],"maxDataPoints":3,"nullPointMode":"connected","options":{},"pieType":"donut","pluginVersion":"6.5.0-pre","strokeWidth":1,"targets":[{"aggregator":"sum","alias":"success","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","metric":"clt.loc.association","refId":"A","shouldComputeRate":false,"tags":{"type":"associated"}}],"timeFrom":null,"timeShift":null,"title":"Network","transparent":true,"type":"grafana-piechart-panel","valueName":"total"},{"aliasColors":{"Online":"rgba(0, 0, 0, 0.28)","failure":"#F2495C","success":"#73BF69"},"breakPoint":"50%","cacheTimeout":null,"combine":{"label":"Others","threshold":0},"datasource":"OpenTSDB","fontSize":"80%","format":"short","gridPos":{"h":8,"w":4,"x":20,"y":0},"id":10,"interval":null,"legend":{"show":true,"sortDesc":true,"values":true},"legendType":"Under graph","links":[],"maxDataPoints":3,"nullPointMode":"connected","options":{},"pieType":"donut","strokeWidth":1,"targets":[{"aggregator":"sum","alias":"Online","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","metric":"clt.loc.association","refId":"A","shouldComputeRate":false,"tags":{"type":"associated"}}],"timeFrom":null,"timeShift":null,"title":"Online","transparent":true,"type":"grafana-piechart-panel","valueName":"current"},{"columns":[{"text":"Count","value":"count"}],"datasource":"OpenTSDB","fontSize":"100%","gridPos":{"h":8,"w":12,"x":0,"y":8},"id":15,"options":{},"pageSize":null,"showHeader":true,"sort":{"col":null,"desc":false},"styles":[{"alias":"Time","dateFormat":"YYYY-MM-DD HH:mm:ss","link":false,"pattern":"Time","type":"date"},{"alias":"client_macId","colorMode":null,"colors":["#5794F2","#C4162A","#8AB8FF"],"decimals":2,"link":false,"pattern":"Metric","thresholds":[],"type":"number","unit":"short"},{"alias":"","colorMode":null,"colors":["rgba(245, 54, 54, 0.9)","rgba(237, 129, 40, 0.89)","rgba(50, 172, 45, 0.97)"],"dateFormat":"YYYY-MM-DD HH:mm:ss","decimals":2,"mappingType":1,"pattern":"","thresholds":[],"type":"number","unit":"short"}],"targets":[{"aggregator":"count","alias":"$tag_macid","currentFilterGroupBy":false,"currentFilterKey":"","currentFilterType":"literal_or","currentFilterValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","filters":[{"filter":"$site","groupBy":false,"tagk":"site","type":"literal_or"},{"filter":"$building","groupBy":false,"tagk":"building","type":"literal_or"},{"filter":"$floor","groupBy":false,"tagk":"floor","type":"literal_or"},{"filter":"*","groupBy":true,"tagk":"macid","type":"wildcard"}],"metric":"clt.loc.association","refId":"A"}],"timeFrom":null,"timeShift":null,"title":"Clients by Most Failed Connections","transform":"timeseries_aggregations","type":"table"},{"aliasColors":{},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":8,"w":12,"x":12,"y":8},"hiddenSeries":false,"id":17,"legend":{"avg":false,"current":false,"max":false,"min":false,"show":false,"total":false,"values":false},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"count","alias":"$tag_site","counterTop":"5","currentFilterGroupBy":false,"currentFilterKey":"building","currentFilterType":"literal_or","currentFilterValue":"","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","filters":[{"filter":"$type","groupBy":false,"tagk":"type","type":"literal_or"},{"filter":"$site","groupBy":true,"tagk":"site","type":"literal_or"}],"metric":"clt.loc.association","refId":"A","shouldComputeTopN":true,"tags":{}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Top Locations Affected by Failures","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":true,"values":["total"]},"yaxes":[{"format":"short","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":"0","show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{"UHN1TKY311008":"dark-red"},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":8,"w":12,"x":0,"y":16},"hiddenSeries":false,"id":2,"legend":{"avg":false,"current":false,"max":false,"min":false,"rightSide":true,"show":true,"total":false,"values":false},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"sum","alias":"$tag_macid","counterTop":"10","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","metric":"clt.loc.traffic","refId":"A","shouldComputeTopN":true,"tags":{"building":"$building","floor":"$floor","macid":"*"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Top 10 client by traffic","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"decbytes","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":"0","show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":8,"w":12,"x":12,"y":16},"hiddenSeries":false,"id":4,"legend":{"avg":false,"current":false,"max":false,"min":false,"rightSide":true,"show":true,"total":false,"values":false},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"sum","alias":"$tag_macid","counterTop":"10","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","metric":"ap.mac.session","refId":"A","shouldComputeTopN":true,"tags":{"building":"$building","floor":"$floor","macid":"*"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Top 10 clients by session","tooltip":{"shared":true,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"s","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":"0","show":true}],"yaxis":{"align":false,"alignLevel":null}}],"refresh":false,"schemaVersion":19,"style":"dark","tags":[],"templating":{"list":[{"allValue":null,"current":{},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,site)","hide":0,"includeAll":true,"label":null,"multi":false,"name":"site","options":[],"query":"tag_values(clt.loc.traffic,site)","refresh":1,"regex":"","skipUrlSync":false,"sort":1,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,building,site=$site)","hide":0,"includeAll":true,"label":"building","multi":false,"name":"building","options":[],"query":"tag_values(clt.loc.traffic,building,site=$site)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,floor)","hide":0,"includeAll":true,"label":"floor","multi":false,"name":"floor","options":[],"query":"tag_values(clt.loc.traffic,floor)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.association,type)","hide":0,"includeAll":true,"label":"type","multi":false,"name":"type","options":[],"query":"tag_values(clt.loc.association,type)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false}]},"time":{"from":"now-30d","to":"now"},"timepicker":{"refresh_intervals":["5s","10s","30s","1m","5m","15m","30m","1h","2h","1d"]},"timezone":"","title":"Connectivity Dashboard","uid":"1kKTUf1Zz","version":2}
318	14	3	0	1	2020-01-21 14:35:14	1		{"__requires":[{"id":"grafana","name":"Grafana","type":"grafana","version":"6.5.0-pre"},{"id":"grafana-piechart-panel","name":"Pie Chart","type":"panel","version":"1.3.9"},{"id":"graph","name":"Graph","type":"panel","version":""},{"id":"opentsdb","name":"OpenTSDB","type":"datasource","version":"1.0.0"}],"annotations":{"list":[{"builtIn":1,"datasource":"-- Grafana --","enable":true,"hide":true,"iconColor":"rgba(0, 211, 255, 1)","name":"Annotations \\u0026 Alerts","type":"dashboard"}]},"editable":true,"gnetId":null,"graphTooltip":0,"id":null,"iteration":1579615432860,"links":[],"panels":[{"aliasColors":{},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":8,"w":12,"x":0,"y":0},"hiddenSeries":false,"id":10,"legend":{"avg":false,"current":false,"max":false,"min":false,"show":false,"total":false,"values":false},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"sum","alias":"$tag_aphost","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","metric":"ap.loc.bandwidth","refId":"A","tags":{"aphost":"*","building":"$Building","floor":"$Floor","site":"$Site"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"APs by Utilization","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"short","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":8,"w":12,"x":12,"y":0},"hiddenSeries":false,"id":6,"legend":{"avg":false,"current":false,"max":false,"min":false,"rightSide":true,"show":false,"total":true,"values":true},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"sum","alias":"$tag_aphost","counterTop":"10","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.traffic","refId":"A","shouldComputeTopN":true,"tags":{"aphost":"*","building":"$Building","floor":"$Floor","site":"$Site","type":"ap"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"APs by Traffic","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"decbytes","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":9,"w":12,"x":0,"y":8},"hiddenSeries":false,"id":8,"legend":{"avg":false,"current":false,"max":false,"min":false,"rightSide":true,"show":false,"total":true,"values":true},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"count","alias":"$tag_aphost","counterTop":"10","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.association","refId":"A","shouldComputeTopN":true,"tags":{"aphost":"*","building":"$Building","floor":"$Floor","site":"$Site","status":"success","type":"network"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"APs By Associations","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"short","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{},"breakPoint":"50%","cacheTimeout":null,"combine":{"label":"Others","threshold":0},"datasource":"OpenTSDB","fontSize":"80%","format":"short","gridPos":{"h":9,"w":12,"x":12,"y":8},"id":2,"interval":null,"legend":{"show":true,"values":true},"legendType":"Under graph","links":[],"maxDataPoints":3,"nullPointMode":"connected","options":{},"pieType":"pie","strokeWidth":1,"targets":[{"aggregator":"count","alias":"$tag_ssid_security","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.traffic","refId":"A","tags":{"building":"$Building","floor":"$Floor","site":"$Site","ssid_security":"*","type":"ssid"}}],"timeFrom":null,"timeShift":null,"title":"Security Distribution","type":"grafana-piechart-panel","valueName":"current"},{"aliasColors":{},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":9,"w":12,"x":0,"y":17},"hiddenSeries":false,"id":4,"legend":{"avg":false,"current":false,"max":false,"min":false,"rightSide":true,"show":false,"total":false,"values":false},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"avg","alias":"$tag_aphost","counterTop":"10","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.datarate","refId":"A","shouldComputeTopN":true,"tags":{"aphost":"*","building":"$Building","floor":"$Floor","site":"$Site","type":"ap"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"APs By Data Rate","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"decbytes","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}}],"refresh":"","schemaVersion":20,"style":"dark","tags":[],"templating":{"list":[{"allValue":null,"current":{},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.datarate,site)","hide":0,"includeAll":true,"label":"Site","multi":false,"name":"Site","options":[],"query":"tag_values(clt.loc.datarate,site)","refresh":1,"regex":"","skipUrlSync":false,"sort":1,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.datarate,building,site=$Site)","hide":0,"includeAll":true,"label":"Building","multi":false,"name":"Building","options":[],"query":"tag_values(clt.loc.datarate,building,site=$Site)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.datarate,floor)","hide":0,"includeAll":true,"label":"Floor","multi":false,"name":"Floor","options":[],"query":"tag_values(clt.loc.datarate,floor)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"auto":false,"auto_count":30,"auto_min":"10s","current":{"selected":false,"text":"1hr","value":"1hr"},"hide":0,"label":null,"name":"Time","options":[{"selected":true,"text":"1hr","value":"1hr"},{"selected":false,"text":"2hr","value":"2hr"},{"selected":false,"text":"4hr","value":"4hr"},{"selected":false,"text":"8hr","value":"8hr"},{"selected":false,"text":"12hr","value":"12hr"}],"query":"1hr,2hr,4hr,8hr,12hr,","refresh":2,"skipUrlSync":false,"type":"interval"}]},"time":{"from":"now-90d","to":"now"},"timepicker":{"refresh_intervals":["5s","10s","30s","1m","5m","15m","30m","1h","2h","1d"]},"timezone":"","title":"AP DASHBOARD","uid":"pMMRvzhWz","version":1}
319	14	1	0	2	2020-01-21 14:35:22	1		{"annotations":{"list":[{"builtIn":1,"datasource":"-- Grafana --","enable":true,"hide":true,"iconColor":"rgba(0, 211, 255, 1)","name":"Annotations \\u0026 Alerts","type":"dashboard"}]},"editable":true,"gnetId":null,"graphTooltip":0,"id":14,"iteration":1579617314334,"links":[],"panels":[{"aliasColors":{},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":8,"w":12,"x":0,"y":0},"hiddenSeries":false,"id":10,"legend":{"avg":false,"current":false,"max":false,"min":false,"show":false,"total":false,"values":false},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"sum","alias":"$tag_aphost","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","metric":"ap.loc.bandwidth","refId":"A","tags":{"aphost":"*","building":"$Building","floor":"$Floor","site":"$Site"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"APs by Utilization","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"short","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":8,"w":12,"x":12,"y":0},"hiddenSeries":false,"id":6,"legend":{"avg":false,"current":false,"max":false,"min":false,"rightSide":true,"show":false,"total":true,"values":true},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"sum","alias":"$tag_aphost","counterTop":"10","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.traffic","refId":"A","shouldComputeTopN":true,"tags":{"aphost":"*","building":"$Building","floor":"$Floor","site":"$Site","type":"ap"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"APs by Traffic","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"decbytes","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":9,"w":12,"x":0,"y":8},"hiddenSeries":false,"id":8,"legend":{"avg":false,"current":false,"max":false,"min":false,"rightSide":true,"show":false,"total":true,"values":true},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"count","alias":"$tag_aphost","counterTop":"10","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.association","refId":"A","shouldComputeTopN":true,"tags":{"aphost":"*","building":"$Building","floor":"$Floor","site":"$Site","status":"success","type":"network"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"APs By Associations","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"short","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{},"breakPoint":"50%","cacheTimeout":null,"combine":{"label":"Others","threshold":0},"datasource":"OpenTSDB","fontSize":"80%","format":"short","gridPos":{"h":9,"w":12,"x":12,"y":8},"id":2,"interval":null,"legend":{"show":true,"values":true},"legendType":"Under graph","links":[],"maxDataPoints":3,"nullPointMode":"connected","options":{},"pieType":"pie","strokeWidth":1,"targets":[{"aggregator":"count","alias":"$tag_ssid_security","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.traffic","refId":"A","tags":{"building":"$Building","floor":"$Floor","site":"$Site","ssid_security":"*","type":"ssid"}}],"timeFrom":null,"timeShift":null,"title":"Security Distribution","type":"grafana-piechart-panel","valueName":"current"},{"aliasColors":{},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":9,"w":12,"x":0,"y":17},"hiddenSeries":false,"id":4,"legend":{"avg":false,"current":false,"max":false,"min":false,"rightSide":true,"show":false,"total":false,"values":false},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"avg","alias":"$tag_aphost","counterTop":"10","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.datarate","refId":"A","shouldComputeTopN":true,"tags":{"aphost":"*","building":"$Building","floor":"$Floor","site":"$Site","type":"ap"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"APs By Data Rate","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"decbytes","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}}],"refresh":"","schemaVersion":19,"style":"dark","tags":[],"templating":{"list":[{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.datarate,site)","hide":0,"includeAll":true,"label":"Site","multi":false,"name":"Site","options":[],"query":"tag_values(clt.loc.datarate,site)","refresh":1,"regex":"","skipUrlSync":false,"sort":1,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.datarate,building,site=$Site)","hide":0,"includeAll":true,"label":"Building","multi":false,"name":"Building","options":[],"query":"tag_values(clt.loc.datarate,building,site=$Site)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.datarate,floor)","hide":0,"includeAll":true,"label":"Floor","multi":false,"name":"Floor","options":[],"query":"tag_values(clt.loc.datarate,floor)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"auto":false,"auto_count":30,"auto_min":"10s","current":{"text":"1hr","value":"1hr"},"hide":0,"label":null,"name":"Time","options":[{"selected":true,"text":"1hr","value":"1hr"},{"selected":false,"text":"2hr","value":"2hr"},{"selected":false,"text":"4hr","value":"4hr"},{"selected":false,"text":"8hr","value":"8hr"},{"selected":false,"text":"12hr","value":"12hr"}],"query":"1hr,2hr,4hr,8hr,12hr,","refresh":2,"skipUrlSync":false,"type":"interval"}]},"time":{"from":"now-90d","to":"now"},"timepicker":{"refresh_intervals":["5s","10s","30s","1m","5m","15m","30m","1h","2h","1d"]},"timezone":"","title":"AP DASHBOARD","uid":"pMMRvzhWz","version":2}
326	15	2	0	3	2020-01-21 14:39:35	1		{"annotations":{"list":[{"builtIn":1,"datasource":"-- Grafana --","enable":true,"hide":true,"iconColor":"rgba(0, 211, 255, 1)","name":"Annotations \\u0026 Alerts","type":"dashboard"}]},"editable":true,"gnetId":null,"graphTooltip":0,"id":15,"iteration":1579617565344,"links":[],"panels":[{"aliasColors":{"20-34-fb-81-19-cd":"super-light-blue","70-bb-e9-25-1c-bc":"dark-blue"},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":7,"w":12,"x":0,"y":0},"hiddenSeries":false,"id":4,"legend":{"avg":false,"current":false,"max":false,"min":false,"rightSide":true,"show":false,"total":false,"values":false},"lines":false,"linewidth":1,"links":[],"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"sum","alias":"$tag_macid","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.traffic","refId":"A","tags":{"macid":"*"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Clients By Traffic","tooltip":{"shared":true,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"decbytes","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":7,"w":12,"x":12,"y":0},"hiddenSeries":false,"id":2,"legend":{"avg":false,"current":false,"max":false,"min":false,"rightSide":true,"show":false,"total":true,"values":true},"lines":false,"linewidth":1,"links":[],"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"sum","alias":"$tag_macid","currentTagKey":"building","currentTagValue":"$Building","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.datarate","refId":"A","tags":{"macid":"*"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Clients by Data Rate","tooltip":{"shared":true,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"short","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{"BLUE":"#3f51bf","RED":"#d32f2f"},"breakPoint":"50%","cacheTimeout":null,"combine":{"label":"Others","threshold":0},"datasource":"OpenTSDB","fontSize":"80%","format":"short","gridPos":{"h":6,"w":12,"x":0,"y":7},"id":6,"interval":null,"legend":{"header":"","percentage":false,"show":true,"sort":"current","sortDesc":true,"values":true},"legendType":"Under graph","links":[],"maxDataPoints":3,"nullPointMode":"connected","options":{},"pieType":"pie","strokeWidth":"1","targets":[{"aggregator":"count","alias":"$tag_protocol","currentTagKey":"","currentTagValue":"","disableDownsampling":false,"downsampleAggregator":"avg","downsampleFillPolicy":"none","metric":"clt.loc.datarate","refId":"A","tags":{"protocol":"*","ssid":"$SSID"}}],"timeFrom":null,"timeShift":null,"title":"Client Protocol Distribution","type":"grafana-piechart-panel","valueName":"current"},{"aliasColors":{},"breakPoint":"50%","cacheTimeout":null,"combine":{"label":"Others","threshold":0},"datasource":"OpenTSDB","fontSize":"80%","format":"short","gridPos":{"h":6,"w":12,"x":12,"y":7},"id":8,"interval":null,"legend":{"show":true,"values":true},"legendType":"Under graph","links":[],"maxDataPoints":3,"nullPointMode":"connected","options":{},"pieType":"pie","strokeWidth":1,"targets":[{"aggregator":"sum","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","metric":"clt.loc.smartdevice","refId":"A","tags":{"client_type":"*","ssid":"$SSID","type":"network"}}],"timeFrom":null,"timeShift":null,"title":"Smart Devices Distribution","type":"grafana-piechart-panel","valueName":"current"}],"refresh":false,"schemaVersion":19,"style":"dark","tags":["OpenNMS"],"templating":{"list":[{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,site)","hide":0,"includeAll":true,"label":"Site","multi":false,"name":"Site","options":[],"query":"tag_values(clt.loc.traffic,site)","refresh":1,"regex":"","skipUrlSync":false,"sort":1,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,building,site=$Site)","hide":0,"includeAll":true,"label":"Building","multi":false,"name":"Building","options":[],"query":"tag_values(clt.loc.traffic,building,site=$Site)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,floor)","hide":0,"includeAll":true,"label":"Floor","multi":false,"name":"Floor","options":[],"query":"tag_values(clt.loc.traffic,floor)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,ssid)","hide":0,"includeAll":true,"label":"SSID","multi":false,"name":"SSID","options":[],"query":"tag_values(clt.loc.traffic,ssid)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"auto":false,"auto_count":30,"auto_min":"10s","current":{"text":"1hr","value":"1hr"},"hide":0,"label":"Time","name":"Time","options":[{"selected":true,"text":"1hr","value":"1hr"},{"selected":false,"text":"2hr","value":"2hr"},{"selected":false,"text":"4hr","value":"4hr"},{"selected":false,"text":"8hr","value":"8hr"},{"selected":false,"text":"12hr","value":"12hr"}],"query":"1hr,2hr,4hr,8hr,12hr,","refresh":2,"skipUrlSync":false,"type":"interval"}]},"time":{"from":"now-30d","to":"now"},"timepicker":{"refresh_intervals":["5s","10s","30s","1m","5m","15m","30m","1h","2h","1d"],"time_options":["5m","15m","1h","6h","12h","24h","2d","7d","30d"]},"timezone":"","title":"CLIENT DASHBOARD","uid":"MECz1NcWk","version":3}
327	15	3	0	4	2020-01-21 14:39:38	1		{"annotations":{"list":[{"builtIn":1,"datasource":"-- Grafana --","enable":true,"hide":true,"iconColor":"rgba(0, 211, 255, 1)","name":"Annotations \\u0026 Alerts","type":"dashboard"}]},"editable":true,"gnetId":null,"graphTooltip":0,"id":15,"iteration":1579617565344,"links":[],"panels":[{"aliasColors":{"20-34-fb-81-19-cd":"super-light-blue","70-bb-e9-25-1c-bc":"dark-blue"},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":7,"w":12,"x":0,"y":0},"hiddenSeries":false,"id":4,"legend":{"avg":false,"current":false,"max":false,"min":false,"rightSide":true,"show":false,"total":false,"values":false},"lines":false,"linewidth":1,"links":[],"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"sum","alias":"$tag_macid","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.traffic","refId":"A","tags":{"macid":"*"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Clients By Traffic","tooltip":{"shared":true,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"decbytes","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":7,"w":12,"x":12,"y":0},"hiddenSeries":false,"id":2,"legend":{"avg":false,"current":false,"max":false,"min":false,"rightSide":true,"show":false,"total":true,"values":true},"lines":false,"linewidth":1,"links":[],"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"sum","alias":"$tag_macid","currentTagKey":"building","currentTagValue":"$Building","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.datarate","refId":"A","tags":{"macid":"*"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"Clients by Data Rate","tooltip":{"shared":true,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"short","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{"BLUE":"#3f51bf","RED":"#d32f2f"},"breakPoint":"50%","cacheTimeout":null,"combine":{"label":"Others","threshold":0},"datasource":"OpenTSDB","fontSize":"80%","format":"short","gridPos":{"h":6,"w":12,"x":0,"y":7},"id":6,"interval":null,"legend":{"header":"","percentage":false,"show":true,"sort":"current","sortDesc":true,"values":true},"legendType":"Under graph","links":[],"maxDataPoints":3,"nullPointMode":"connected","options":{},"pieType":"pie","strokeWidth":"1","targets":[{"aggregator":"count","alias":"$tag_protocol","currentTagKey":"","currentTagValue":"","disableDownsampling":false,"downsampleAggregator":"avg","downsampleFillPolicy":"none","metric":"clt.loc.datarate","refId":"A","tags":{"protocol":"*","ssid":"$SSID"}}],"timeFrom":null,"timeShift":null,"title":"Client Protocol Distribution","type":"grafana-piechart-panel","valueName":"current"},{"aliasColors":{},"breakPoint":"50%","cacheTimeout":null,"combine":{"label":"Others","threshold":0},"datasource":"OpenTSDB","fontSize":"80%","format":"short","gridPos":{"h":6,"w":12,"x":12,"y":7},"id":8,"interval":null,"legend":{"show":true,"values":true},"legendType":"Under graph","links":[],"maxDataPoints":3,"nullPointMode":"connected","options":{},"pieType":"pie","strokeWidth":1,"targets":[{"aggregator":"sum","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","metric":"clt.loc.smartdevice","refId":"A","tags":{"client_type":"*","ssid":"$SSID","type":"network"}}],"timeFrom":null,"timeShift":null,"title":"Smart Devices Distribution","type":"grafana-piechart-panel","valueName":"current"}],"refresh":false,"schemaVersion":19,"style":"dark","tags":["OpenNMS"],"templating":{"list":[{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,site)","hide":0,"includeAll":true,"label":"Site","multi":false,"name":"Site","options":[],"query":"tag_values(clt.loc.traffic,site)","refresh":1,"regex":"","skipUrlSync":false,"sort":1,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,building,site=$Site)","hide":0,"includeAll":true,"label":"Building","multi":false,"name":"Building","options":[],"query":"tag_values(clt.loc.traffic,building,site=$Site)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,floor)","hide":0,"includeAll":true,"label":"Floor","multi":false,"name":"Floor","options":[],"query":"tag_values(clt.loc.traffic,floor)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.traffic,ssid)","hide":0,"includeAll":true,"label":"SSID","multi":false,"name":"SSID","options":[],"query":"tag_values(clt.loc.traffic,ssid)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"auto":false,"auto_count":30,"auto_min":"10s","current":{"text":"1hr","value":"1hr"},"hide":0,"label":"Time","name":"Time","options":[{"selected":true,"text":"1hr","value":"1hr"},{"selected":false,"text":"2hr","value":"2hr"},{"selected":false,"text":"4hr","value":"4hr"},{"selected":false,"text":"8hr","value":"8hr"},{"selected":false,"text":"12hr","value":"12hr"}],"query":"1hr,2hr,4hr,8hr,12hr,","refresh":2,"skipUrlSync":false,"type":"interval"}]},"time":{"from":"now-30d","to":"now"},"timepicker":{"refresh_intervals":["5s","10s","30s","1m","5m","15m","30m","1h","2h","1d"],"time_options":["5m","15m","1h","6h","12h","24h","2d","7d","30d"]},"timezone":"","title":"CLIENT DASHBOARD","uid":"MECz1NcWk","version":4}
328	14	2	0	3	2020-01-21 14:39:59	1		{"annotations":{"list":[{"builtIn":1,"datasource":"-- Grafana --","enable":true,"hide":true,"iconColor":"rgba(0, 211, 255, 1)","name":"Annotations \\u0026 Alerts","type":"dashboard"}]},"editable":true,"gnetId":null,"graphTooltip":0,"id":14,"iteration":1579617582215,"links":[],"panels":[{"aliasColors":{},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":8,"w":12,"x":0,"y":0},"hiddenSeries":false,"id":10,"legend":{"avg":false,"current":false,"max":false,"min":false,"show":false,"total":false,"values":false},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"sum","alias":"$tag_aphost","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","metric":"ap.loc.bandwidth","refId":"A","tags":{"aphost":"*","building":"$Building","floor":"$Floor","site":"$Site"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"APs by Utilization","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"short","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":8,"w":12,"x":12,"y":0},"hiddenSeries":false,"id":6,"legend":{"avg":false,"current":false,"max":false,"min":false,"rightSide":true,"show":false,"total":true,"values":true},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"sum","alias":"$tag_aphost","counterTop":"10","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.traffic","refId":"A","shouldComputeTopN":true,"tags":{"aphost":"*","building":"$Building","floor":"$Floor","site":"$Site","type":"ap"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"APs by Traffic","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"decbytes","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":9,"w":12,"x":0,"y":8},"hiddenSeries":false,"id":8,"legend":{"avg":false,"current":false,"max":false,"min":false,"rightSide":true,"show":false,"total":true,"values":true},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"count","alias":"$tag_aphost","counterTop":"10","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.association","refId":"A","shouldComputeTopN":true,"tags":{"aphost":"*","building":"$Building","floor":"$Floor","site":"$Site","status":"success","type":"network"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"APs By Associations","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"short","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{},"breakPoint":"50%","cacheTimeout":null,"combine":{"label":"Others","threshold":0},"datasource":"OpenTSDB","fontSize":"80%","format":"short","gridPos":{"h":9,"w":12,"x":12,"y":8},"id":2,"interval":null,"legend":{"show":true,"values":true},"legendType":"Under graph","links":[],"maxDataPoints":3,"nullPointMode":"connected","options":{},"pieType":"pie","strokeWidth":1,"targets":[{"aggregator":"count","alias":"$tag_ssid_security","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.traffic","refId":"A","tags":{"building":"$Building","floor":"$Floor","site":"$Site","ssid_security":"*","type":"ssid"}}],"timeFrom":null,"timeShift":null,"title":"Security Distribution","type":"grafana-piechart-panel","valueName":"current"},{"aliasColors":{},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":9,"w":12,"x":0,"y":17},"hiddenSeries":false,"id":4,"legend":{"avg":false,"current":false,"max":false,"min":false,"rightSide":true,"show":false,"total":false,"values":false},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"avg","alias":"$tag_aphost","counterTop":"10","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.datarate","refId":"A","shouldComputeTopN":true,"tags":{"aphost":"*","building":"$Building","floor":"$Floor","site":"$Site","type":"ap"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"APs By Data Rate","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"decbytes","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}}],"refresh":"","schemaVersion":19,"style":"dark","tags":["OpenNMS"],"templating":{"list":[{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.datarate,site)","hide":0,"includeAll":true,"label":"Site","multi":false,"name":"Site","options":[],"query":"tag_values(clt.loc.datarate,site)","refresh":1,"regex":"","skipUrlSync":false,"sort":1,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.datarate,building,site=$Site)","hide":0,"includeAll":true,"label":"Building","multi":false,"name":"Building","options":[],"query":"tag_values(clt.loc.datarate,building,site=$Site)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.datarate,floor)","hide":0,"includeAll":true,"label":"Floor","multi":false,"name":"Floor","options":[],"query":"tag_values(clt.loc.datarate,floor)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"auto":false,"auto_count":30,"auto_min":"10s","current":{"text":"1hr","value":"1hr"},"hide":0,"label":null,"name":"Time","options":[{"selected":true,"text":"1hr","value":"1hr"},{"selected":false,"text":"2hr","value":"2hr"},{"selected":false,"text":"4hr","value":"4hr"},{"selected":false,"text":"8hr","value":"8hr"},{"selected":false,"text":"12hr","value":"12hr"}],"query":"1hr,2hr,4hr,8hr,12hr,","refresh":2,"skipUrlSync":false,"type":"interval"}]},"time":{"from":"now-90d","to":"now"},"timepicker":{"refresh_intervals":["5s","10s","30s","1m","5m","15m","30m","1h","2h","1d"]},"timezone":"","title":"AP DASHBOARD","uid":"pMMRvzhWz","version":3}
329	14	3	0	4	2020-01-21 14:40:03	1		{"annotations":{"list":[{"builtIn":1,"datasource":"-- Grafana --","enable":true,"hide":true,"iconColor":"rgba(0, 211, 255, 1)","name":"Annotations \\u0026 Alerts","type":"dashboard"}]},"editable":true,"gnetId":null,"graphTooltip":0,"id":14,"iteration":1579617582215,"links":[],"panels":[{"aliasColors":{},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":8,"w":12,"x":0,"y":0},"hiddenSeries":false,"id":10,"legend":{"avg":false,"current":false,"max":false,"min":false,"show":false,"total":false,"values":false},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"sum","alias":"$tag_aphost","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","metric":"ap.loc.bandwidth","refId":"A","tags":{"aphost":"*","building":"$Building","floor":"$Floor","site":"$Site"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"APs by Utilization","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"short","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":8,"w":12,"x":12,"y":0},"hiddenSeries":false,"id":6,"legend":{"avg":false,"current":false,"max":false,"min":false,"rightSide":true,"show":false,"total":true,"values":true},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"sum","alias":"$tag_aphost","counterTop":"10","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.traffic","refId":"A","shouldComputeTopN":true,"tags":{"aphost":"*","building":"$Building","floor":"$Floor","site":"$Site","type":"ap"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"APs by Traffic","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"decbytes","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":9,"w":12,"x":0,"y":8},"hiddenSeries":false,"id":8,"legend":{"avg":false,"current":false,"max":false,"min":false,"rightSide":true,"show":false,"total":true,"values":true},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"count","alias":"$tag_aphost","counterTop":"10","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.association","refId":"A","shouldComputeTopN":true,"tags":{"aphost":"*","building":"$Building","floor":"$Floor","site":"$Site","status":"success","type":"network"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"APs By Associations","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"short","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{},"breakPoint":"50%","cacheTimeout":null,"combine":{"label":"Others","threshold":0},"datasource":"OpenTSDB","fontSize":"80%","format":"short","gridPos":{"h":9,"w":12,"x":12,"y":8},"id":2,"interval":null,"legend":{"show":true,"values":true},"legendType":"Under graph","links":[],"maxDataPoints":3,"nullPointMode":"connected","options":{},"pieType":"pie","strokeWidth":1,"targets":[{"aggregator":"count","alias":"$tag_ssid_security","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.traffic","refId":"A","tags":{"building":"$Building","floor":"$Floor","site":"$Site","ssid_security":"*","type":"ssid"}}],"timeFrom":null,"timeShift":null,"title":"Security Distribution","type":"grafana-piechart-panel","valueName":"current"},{"aliasColors":{},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":9,"w":12,"x":0,"y":17},"hiddenSeries":false,"id":4,"legend":{"avg":false,"current":false,"max":false,"min":false,"rightSide":true,"show":false,"total":false,"values":false},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"avg","alias":"$tag_aphost","counterTop":"10","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.datarate","refId":"A","shouldComputeTopN":true,"tags":{"aphost":"*","building":"$Building","floor":"$Floor","site":"$Site","type":"ap"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"APs By Data Rate","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"decbytes","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}}],"refresh":"","schemaVersion":19,"style":"dark","tags":["OpenNMS"],"templating":{"list":[{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.datarate,site)","hide":0,"includeAll":true,"label":"Site","multi":false,"name":"Site","options":[],"query":"tag_values(clt.loc.datarate,site)","refresh":1,"regex":"","skipUrlSync":false,"sort":1,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.datarate,building,site=$Site)","hide":0,"includeAll":true,"label":"Building","multi":false,"name":"Building","options":[],"query":"tag_values(clt.loc.datarate,building,site=$Site)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.datarate,floor)","hide":0,"includeAll":true,"label":"Floor","multi":false,"name":"Floor","options":[],"query":"tag_values(clt.loc.datarate,floor)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"auto":false,"auto_count":30,"auto_min":"10s","current":{"text":"1hr","value":"1hr"},"hide":0,"label":null,"name":"Time","options":[{"selected":true,"text":"1hr","value":"1hr"},{"selected":false,"text":"2hr","value":"2hr"},{"selected":false,"text":"4hr","value":"4hr"},{"selected":false,"text":"8hr","value":"8hr"},{"selected":false,"text":"12hr","value":"12hr"}],"query":"1hr,2hr,4hr,8hr,12hr,","refresh":2,"skipUrlSync":false,"type":"interval"}]},"time":{"from":"now-90d","to":"now"},"timepicker":{"refresh_intervals":["5s","10s","30s","1m","5m","15m","30m","1h","2h","1d"]},"timezone":"","title":"AP DASHBOARD","uid":"pMMRvzhWz","version":4}
330	14	4	0	5	2020-01-21 14:40:06	1		{"annotations":{"list":[{"builtIn":1,"datasource":"-- Grafana --","enable":true,"hide":true,"iconColor":"rgba(0, 211, 255, 1)","name":"Annotations \\u0026 Alerts","type":"dashboard"}]},"editable":true,"gnetId":null,"graphTooltip":0,"id":14,"iteration":1579617582215,"links":[],"panels":[{"aliasColors":{},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":8,"w":12,"x":0,"y":0},"hiddenSeries":false,"id":10,"legend":{"avg":false,"current":false,"max":false,"min":false,"show":false,"total":false,"values":false},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"sum","alias":"$tag_aphost","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","metric":"ap.loc.bandwidth","refId":"A","tags":{"aphost":"*","building":"$Building","floor":"$Floor","site":"$Site"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"APs by Utilization","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"short","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":8,"w":12,"x":12,"y":0},"hiddenSeries":false,"id":6,"legend":{"avg":false,"current":false,"max":false,"min":false,"rightSide":true,"show":false,"total":true,"values":true},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"sum","alias":"$tag_aphost","counterTop":"10","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.traffic","refId":"A","shouldComputeTopN":true,"tags":{"aphost":"*","building":"$Building","floor":"$Floor","site":"$Site","type":"ap"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"APs by Traffic","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"decbytes","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":9,"w":12,"x":0,"y":8},"hiddenSeries":false,"id":8,"legend":{"avg":false,"current":false,"max":false,"min":false,"rightSide":true,"show":false,"total":true,"values":true},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"count","alias":"$tag_aphost","counterTop":"10","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.association","refId":"A","shouldComputeTopN":true,"tags":{"aphost":"*","building":"$Building","floor":"$Floor","site":"$Site","status":"success","type":"network"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"APs By Associations","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"short","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}},{"aliasColors":{},"breakPoint":"50%","cacheTimeout":null,"combine":{"label":"Others","threshold":0},"datasource":"OpenTSDB","fontSize":"80%","format":"short","gridPos":{"h":9,"w":12,"x":12,"y":8},"id":2,"interval":null,"legend":{"show":true,"values":true},"legendType":"Under graph","links":[],"maxDataPoints":3,"nullPointMode":"connected","options":{},"pieType":"pie","strokeWidth":1,"targets":[{"aggregator":"count","alias":"$tag_ssid_security","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.traffic","refId":"A","tags":{"building":"$Building","floor":"$Floor","site":"$Site","ssid_security":"*","type":"ssid"}}],"timeFrom":null,"timeShift":null,"title":"Security Distribution","type":"grafana-piechart-panel","valueName":"current"},{"aliasColors":{},"bars":true,"dashLength":10,"dashes":false,"datasource":"OpenTSDB","fill":1,"fillGradient":0,"gridPos":{"h":9,"w":12,"x":0,"y":17},"hiddenSeries":false,"id":4,"legend":{"avg":false,"current":false,"max":false,"min":false,"rightSide":true,"show":false,"total":false,"values":false},"lines":false,"linewidth":1,"nullPointMode":"null","options":{"dataLinks":[]},"percentage":false,"pointradius":2,"points":false,"renderer":"flot","seriesOverrides":[],"spaceLength":10,"stack":false,"steppedLine":false,"targets":[{"aggregator":"avg","alias":"$tag_aphost","counterTop":"10","currentTagKey":"","currentTagValue":"","downsampleAggregator":"avg","downsampleFillPolicy":"none","downsampleInterval":"","metric":"clt.loc.datarate","refId":"A","shouldComputeTopN":true,"tags":{"aphost":"*","building":"$Building","floor":"$Floor","site":"$Site","type":"ap"}}],"thresholds":[],"timeFrom":null,"timeRegions":[],"timeShift":null,"title":"APs By Data Rate","tooltip":{"shared":false,"sort":0,"value_type":"individual"},"type":"graph","xaxis":{"buckets":null,"mode":"series","name":null,"show":false,"values":["total"]},"yaxes":[{"format":"decbytes","label":null,"logBase":1,"max":null,"min":"0","show":true},{"format":"short","label":null,"logBase":1,"max":null,"min":null,"show":true}],"yaxis":{"align":false,"alignLevel":null}}],"refresh":"","schemaVersion":19,"style":"dark","tags":["OpenNMS"],"templating":{"list":[{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.datarate,site)","hide":0,"includeAll":true,"label":"Site","multi":false,"name":"Site","options":[],"query":"tag_values(clt.loc.datarate,site)","refresh":1,"regex":"","skipUrlSync":false,"sort":1,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.datarate,building,site=$Site)","hide":0,"includeAll":true,"label":"Building","multi":false,"name":"Building","options":[],"query":"tag_values(clt.loc.datarate,building,site=$Site)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"allValue":null,"current":{"text":"All","value":"$__all"},"datasource":"OpenTSDB","definition":"tag_values(clt.loc.datarate,floor)","hide":0,"includeAll":true,"label":"Floor","multi":false,"name":"Floor","options":[],"query":"tag_values(clt.loc.datarate,floor)","refresh":1,"regex":"","skipUrlSync":false,"sort":0,"tagValuesQuery":"","tags":[],"tagsQuery":"","type":"query","useTags":false},{"auto":false,"auto_count":30,"auto_min":"10s","current":{"text":"1hr","value":"1hr"},"hide":0,"label":null,"name":"Time","options":[{"selected":true,"text":"1hr","value":"1hr"},{"selected":false,"text":"2hr","value":"2hr"},{"selected":false,"text":"4hr","value":"4hr"},{"selected":false,"text":"8hr","value":"8hr"},{"selected":false,"text":"12hr","value":"12hr"}],"query":"1hr,2hr,4hr,8hr,12hr,","refresh":2,"skipUrlSync":false,"type":"interval"}]},"time":{"from":"now-90d","to":"now"},"timepicker":{"refresh_intervals":["5s","10s","30s","1m","5m","15m","30m","1h","2h","1d"]},"timezone":"","title":"AP DASHBOARD","uid":"pMMRvzhWz","version":5}
\.


--
-- Data for Name: data_source; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.data_source (id, org_id, version, type, name, access, url, password, "user", database, basic_auth, basic_auth_user, basic_auth_password, is_default, json_data, created, updated, with_credentials, secure_json_data, read_only) FROM stdin;
1	1	13	opentsdb	OpenTSDB	proxy	http://192.168.1.18:4242				f			t	{"keepCookies":[],"tsdbResolution":1,"tsdbVersion":1}	2019-09-07 18:27:16	2019-09-07 20:42:39	f	{}	f
\.


--
-- Data for Name: login_attempt; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.login_attempt (id, username, ip_address, created) FROM stdin;
\.


--
-- Data for Name: migration_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.migration_log (id, migration_id, sql, success, error, "timestamp") FROM stdin;
1	create migration_log table	CREATE TABLE IF NOT EXISTS "migration_log" (\n"id" SERIAL PRIMARY KEY  NOT NULL\n, "migration_id" VARCHAR(255) NOT NULL\n, "sql" TEXT NOT NULL\n, "success" BOOL NOT NULL\n, "error" TEXT NOT NULL\n, "timestamp" TIMESTAMP NOT NULL\n);	t		2019-09-07 17:13:45
2	create user table	CREATE TABLE IF NOT EXISTS "user" (\n"id" SERIAL PRIMARY KEY  NOT NULL\n, "version" INTEGER NOT NULL\n, "login" VARCHAR(190) NOT NULL\n, "email" VARCHAR(190) NOT NULL\n, "name" VARCHAR(255) NULL\n, "password" VARCHAR(255) NULL\n, "salt" VARCHAR(50) NULL\n, "rands" VARCHAR(50) NULL\n, "company" VARCHAR(255) NULL\n, "account_id" BIGINT NOT NULL\n, "is_admin" BOOL NOT NULL\n, "created" TIMESTAMP NOT NULL\n, "updated" TIMESTAMP NOT NULL\n);	t		2019-09-07 17:13:46
3	add unique index user.login	CREATE UNIQUE INDEX "UQE_user_login" ON "user" ("login");	t		2019-09-07 17:13:47
4	add unique index user.email	CREATE UNIQUE INDEX "UQE_user_email" ON "user" ("email");	t		2019-09-07 17:13:47
5	drop index UQE_user_login - v1	DROP INDEX "UQE_user_login"	t		2019-09-07 17:13:47
6	drop index UQE_user_email - v1	DROP INDEX "UQE_user_email"	t		2019-09-07 17:13:47
7	Rename table user to user_v1 - v1	ALTER TABLE "user" RENAME TO "user_v1"	t		2019-09-07 17:13:47
8	create user table v2	CREATE TABLE IF NOT EXISTS "user" (\n"id" SERIAL PRIMARY KEY  NOT NULL\n, "version" INTEGER NOT NULL\n, "login" VARCHAR(190) NOT NULL\n, "email" VARCHAR(190) NOT NULL\n, "name" VARCHAR(255) NULL\n, "password" VARCHAR(255) NULL\n, "salt" VARCHAR(50) NULL\n, "rands" VARCHAR(50) NULL\n, "company" VARCHAR(255) NULL\n, "org_id" BIGINT NOT NULL\n, "is_admin" BOOL NOT NULL\n, "email_verified" BOOL NULL\n, "theme" VARCHAR(255) NULL\n, "created" TIMESTAMP NOT NULL\n, "updated" TIMESTAMP NOT NULL\n);	t		2019-09-07 17:13:47
9	create index UQE_user_login - v2	CREATE UNIQUE INDEX "UQE_user_login" ON "user" ("login");	t		2019-09-07 17:13:48
10	create index UQE_user_email - v2	CREATE UNIQUE INDEX "UQE_user_email" ON "user" ("email");	t		2019-09-07 17:13:48
11	copy data_source v1 to v2	INSERT INTO "user" ("company"\n, "org_id"\n, "created"\n, "version"\n, "login"\n, "name"\n, "salt"\n, "rands"\n, "is_admin"\n, "updated"\n, "id"\n, "email"\n, "password") SELECT "company"\n, "account_id"\n, "created"\n, "version"\n, "login"\n, "name"\n, "salt"\n, "rands"\n, "is_admin"\n, "updated"\n, "id"\n, "email"\n, "password" FROM "user_v1"	t		2019-09-07 17:13:48
12	Drop old table user_v1	DROP TABLE IF EXISTS "user_v1"	t		2019-09-07 17:13:48
13	Add column help_flags1 to user table	alter table "user" ADD COLUMN "help_flags1" BIGINT NOT NULL DEFAULT 0 	t		2019-09-07 17:13:48
14	Update user table charset	ALTER TABLE "user" ALTER "login" TYPE VARCHAR(190), ALTER "email" TYPE VARCHAR(190), ALTER "name" TYPE VARCHAR(255), ALTER "password" TYPE VARCHAR(255), ALTER "salt" TYPE VARCHAR(50), ALTER "rands" TYPE VARCHAR(50), ALTER "company" TYPE VARCHAR(255), ALTER "theme" TYPE VARCHAR(255);	t		2019-09-07 17:13:49
15	Add last_seen_at column to user	alter table "user" ADD COLUMN "last_seen_at" TIMESTAMP NULL 	t		2019-09-07 17:13:49
16	Add missing user data	code migration	t		2019-09-07 17:13:49
17	create temp user table v1-7	CREATE TABLE IF NOT EXISTS "temp_user" (\n"id" SERIAL PRIMARY KEY  NOT NULL\n, "org_id" BIGINT NOT NULL\n, "version" INTEGER NOT NULL\n, "email" VARCHAR(190) NOT NULL\n, "name" VARCHAR(255) NULL\n, "role" VARCHAR(20) NULL\n, "code" VARCHAR(190) NOT NULL\n, "status" VARCHAR(20) NOT NULL\n, "invited_by_user_id" BIGINT NULL\n, "email_sent" BOOL NOT NULL\n, "email_sent_on" TIMESTAMP NULL\n, "remote_addr" VARCHAR(255) NULL\n, "created" TIMESTAMP NOT NULL\n, "updated" TIMESTAMP NOT NULL\n);	t		2019-09-07 17:13:49
18	create index IDX_temp_user_email - v1-7	CREATE INDEX "IDX_temp_user_email" ON "temp_user" ("email");	t		2019-09-07 17:13:49
19	create index IDX_temp_user_org_id - v1-7	CREATE INDEX "IDX_temp_user_org_id" ON "temp_user" ("org_id");	t		2019-09-07 17:13:49
20	create index IDX_temp_user_code - v1-7	CREATE INDEX "IDX_temp_user_code" ON "temp_user" ("code");	t		2019-09-07 17:13:50
21	create index IDX_temp_user_status - v1-7	CREATE INDEX "IDX_temp_user_status" ON "temp_user" ("status");	t		2019-09-07 17:13:50
22	Update temp_user table charset	ALTER TABLE "temp_user" ALTER "email" TYPE VARCHAR(190), ALTER "name" TYPE VARCHAR(255), ALTER "role" TYPE VARCHAR(20), ALTER "code" TYPE VARCHAR(190), ALTER "status" TYPE VARCHAR(20), ALTER "remote_addr" TYPE VARCHAR(255);	t		2019-09-07 17:13:50
23	create star table	CREATE TABLE IF NOT EXISTS "star" (\n"id" SERIAL PRIMARY KEY  NOT NULL\n, "user_id" BIGINT NOT NULL\n, "dashboard_id" BIGINT NOT NULL\n);	t		2019-09-07 17:13:50
24	add unique index star.user_id_dashboard_id	CREATE UNIQUE INDEX "UQE_star_user_id_dashboard_id" ON "star" ("user_id","dashboard_id");	t		2019-09-07 17:13:50
25	create org table v1	CREATE TABLE IF NOT EXISTS "org" (\n"id" SERIAL PRIMARY KEY  NOT NULL\n, "version" INTEGER NOT NULL\n, "name" VARCHAR(190) NOT NULL\n, "address1" VARCHAR(255) NULL\n, "address2" VARCHAR(255) NULL\n, "city" VARCHAR(255) NULL\n, "state" VARCHAR(255) NULL\n, "zip_code" VARCHAR(50) NULL\n, "country" VARCHAR(255) NULL\n, "billing_email" VARCHAR(255) NULL\n, "created" TIMESTAMP NOT NULL\n, "updated" TIMESTAMP NOT NULL\n);	t		2019-09-07 17:13:51
26	create index UQE_org_name - v1	CREATE UNIQUE INDEX "UQE_org_name" ON "org" ("name");	t		2019-09-07 17:13:51
27	create org_user table v1	CREATE TABLE IF NOT EXISTS "org_user" (\n"id" SERIAL PRIMARY KEY  NOT NULL\n, "org_id" BIGINT NOT NULL\n, "user_id" BIGINT NOT NULL\n, "role" VARCHAR(20) NOT NULL\n, "created" TIMESTAMP NOT NULL\n, "updated" TIMESTAMP NOT NULL\n);	t		2019-09-07 17:13:51
28	create index IDX_org_user_org_id - v1	CREATE INDEX "IDX_org_user_org_id" ON "org_user" ("org_id");	t		2019-09-07 17:13:52
29	create index UQE_org_user_org_id_user_id - v1	CREATE UNIQUE INDEX "UQE_org_user_org_id_user_id" ON "org_user" ("org_id","user_id");	t		2019-09-07 17:13:52
30	Update org table charset	ALTER TABLE "org" ALTER "name" TYPE VARCHAR(190), ALTER "address1" TYPE VARCHAR(255), ALTER "address2" TYPE VARCHAR(255), ALTER "city" TYPE VARCHAR(255), ALTER "state" TYPE VARCHAR(255), ALTER "zip_code" TYPE VARCHAR(50), ALTER "country" TYPE VARCHAR(255), ALTER "billing_email" TYPE VARCHAR(255);	t		2019-09-07 17:13:52
31	Update org_user table charset	ALTER TABLE "org_user" ALTER "role" TYPE VARCHAR(20);	t		2019-09-07 17:13:52
32	Migrate all Read Only Viewers to Viewers	UPDATE org_user SET role = 'Viewer' WHERE role = 'Read Only Editor'	t		2019-09-07 17:13:52
33	create dashboard table	CREATE TABLE IF NOT EXISTS "dashboard" (\n"id" SERIAL PRIMARY KEY  NOT NULL\n, "version" INTEGER NOT NULL\n, "slug" VARCHAR(189) NOT NULL\n, "title" VARCHAR(255) NOT NULL\n, "data" TEXT NOT NULL\n, "account_id" BIGINT NOT NULL\n, "created" TIMESTAMP NOT NULL\n, "updated" TIMESTAMP NOT NULL\n);	t		2019-09-07 17:13:52
34	add index dashboard.account_id	CREATE INDEX "IDX_dashboard_account_id" ON "dashboard" ("account_id");	t		2019-09-07 17:13:52
35	add unique index dashboard_account_id_slug	CREATE UNIQUE INDEX "UQE_dashboard_account_id_slug" ON "dashboard" ("account_id","slug");	t		2019-09-07 17:13:53
36	create dashboard_tag table	CREATE TABLE IF NOT EXISTS "dashboard_tag" (\n"id" SERIAL PRIMARY KEY  NOT NULL\n, "dashboard_id" BIGINT NOT NULL\n, "term" VARCHAR(50) NOT NULL\n);	t		2019-09-07 17:13:53
37	add unique index dashboard_tag.dasboard_id_term	CREATE UNIQUE INDEX "UQE_dashboard_tag_dashboard_id_term" ON "dashboard_tag" ("dashboard_id","term");	t		2019-09-07 17:13:53
38	drop index UQE_dashboard_tag_dashboard_id_term - v1	DROP INDEX "UQE_dashboard_tag_dashboard_id_term"	t		2019-09-07 17:13:53
39	Rename table dashboard to dashboard_v1 - v1	ALTER TABLE "dashboard" RENAME TO "dashboard_v1"	t		2019-09-07 17:13:53
40	create dashboard v2	CREATE TABLE IF NOT EXISTS "dashboard" (\n"id" SERIAL PRIMARY KEY  NOT NULL\n, "version" INTEGER NOT NULL\n, "slug" VARCHAR(189) NOT NULL\n, "title" VARCHAR(255) NOT NULL\n, "data" TEXT NOT NULL\n, "org_id" BIGINT NOT NULL\n, "created" TIMESTAMP NOT NULL\n, "updated" TIMESTAMP NOT NULL\n);	t		2019-09-07 17:13:53
41	create index IDX_dashboard_org_id - v2	CREATE INDEX "IDX_dashboard_org_id" ON "dashboard" ("org_id");	t		2019-09-07 17:13:54
42	create index UQE_dashboard_org_id_slug - v2	CREATE UNIQUE INDEX "UQE_dashboard_org_id_slug" ON "dashboard" ("org_id","slug");	t		2019-09-07 17:13:54
43	copy dashboard v1 to v2	INSERT INTO "dashboard" ("data"\n, "org_id"\n, "created"\n, "updated"\n, "id"\n, "version"\n, "slug"\n, "title") SELECT "data"\n, "account_id"\n, "created"\n, "updated"\n, "id"\n, "version"\n, "slug"\n, "title" FROM "dashboard_v1"	t		2019-09-07 17:13:54
44	drop table dashboard_v1	DROP TABLE IF EXISTS "dashboard_v1"	t		2019-09-07 17:13:54
45	alter dashboard.data to mediumtext v1	SELECT 0;	t		2019-09-07 17:13:54
46	Add column updated_by in dashboard - v2	alter table "dashboard" ADD COLUMN "updated_by" INTEGER NULL 	t		2019-09-07 17:13:54
47	Add column created_by in dashboard - v2	alter table "dashboard" ADD COLUMN "created_by" INTEGER NULL 	t		2019-09-07 17:13:54
48	Add column gnetId in dashboard	alter table "dashboard" ADD COLUMN "gnet_id" BIGINT NULL 	t		2019-09-07 17:13:54
49	Add index for gnetId in dashboard	CREATE INDEX "IDX_dashboard_gnet_id" ON "dashboard" ("gnet_id");	t		2019-09-07 17:13:54
50	Add column plugin_id in dashboard	alter table "dashboard" ADD COLUMN "plugin_id" VARCHAR(189) NULL 	t		2019-09-07 17:13:54
51	Add index for plugin_id in dashboard	CREATE INDEX "IDX_dashboard_org_id_plugin_id" ON "dashboard" ("org_id","plugin_id");	t		2019-09-07 17:13:54
52	Add index for dashboard_id in dashboard_tag	CREATE INDEX "IDX_dashboard_tag_dashboard_id" ON "dashboard_tag" ("dashboard_id");	t		2019-09-07 17:13:55
53	Update dashboard table charset	ALTER TABLE "dashboard" ALTER "slug" TYPE VARCHAR(189), ALTER "title" TYPE VARCHAR(255), ALTER "plugin_id" TYPE VARCHAR(189), ALTER "data" TYPE TEXT;	t		2019-09-07 17:13:55
54	Update dashboard_tag table charset	ALTER TABLE "dashboard_tag" ALTER "term" TYPE VARCHAR(50);	t		2019-09-07 17:13:55
55	Add column folder_id in dashboard	alter table "dashboard" ADD COLUMN "folder_id" BIGINT NOT NULL DEFAULT 0 	t		2019-09-07 17:13:55
56	Add column isFolder in dashboard	alter table "dashboard" ADD COLUMN "is_folder" BOOL NOT NULL DEFAULT FALSE 	t		2019-09-07 17:13:55
57	Add column has_acl in dashboard	alter table "dashboard" ADD COLUMN "has_acl" BOOL NOT NULL DEFAULT FALSE 	t		2019-09-07 17:13:57
58	Add column uid in dashboard	alter table "dashboard" ADD COLUMN "uid" VARCHAR(40) NULL 	t		2019-09-07 17:13:58
59	Update uid column values in dashboard	UPDATE dashboard SET uid=lpad('' || id,9,'0') WHERE uid IS NULL;	t		2019-09-07 17:13:58
60	Add unique index dashboard_org_id_uid	CREATE UNIQUE INDEX "UQE_dashboard_org_id_uid" ON "dashboard" ("org_id","uid");	t		2019-09-07 17:13:58
61	Remove unique index org_id_slug	DROP INDEX "UQE_dashboard_org_id_slug"	t		2019-09-07 17:13:59
62	Update dashboard title length	ALTER TABLE "dashboard" ALTER "title" TYPE VARCHAR(189);	t		2019-09-07 17:13:59
63	Add unique index for dashboard_org_id_title_folder_id	CREATE UNIQUE INDEX "UQE_dashboard_org_id_folder_id_title" ON "dashboard" ("org_id","folder_id","title");	t		2019-09-07 17:14:00
64	create dashboard_provisioning	CREATE TABLE IF NOT EXISTS "dashboard_provisioning" (\n"id" SERIAL PRIMARY KEY  NOT NULL\n, "dashboard_id" BIGINT NULL\n, "name" VARCHAR(150) NOT NULL\n, "external_id" TEXT NOT NULL\n, "updated" TIMESTAMP NOT NULL\n);	t		2019-09-07 17:14:01
65	Rename table dashboard_provisioning to dashboard_provisioning_tmp_qwerty - v1	ALTER TABLE "dashboard_provisioning" RENAME TO "dashboard_provisioning_tmp_qwerty"	t		2019-09-07 17:14:01
66	create dashboard_provisioning v2	CREATE TABLE IF NOT EXISTS "dashboard_provisioning" (\n"id" SERIAL PRIMARY KEY  NOT NULL\n, "dashboard_id" BIGINT NULL\n, "name" VARCHAR(150) NOT NULL\n, "external_id" TEXT NOT NULL\n, "updated" INTEGER NOT NULL DEFAULT 0\n);	t		2019-09-07 17:14:01
67	create index IDX_dashboard_provisioning_dashboard_id - v2	CREATE INDEX "IDX_dashboard_provisioning_dashboard_id" ON "dashboard_provisioning" ("dashboard_id");	t		2019-09-07 17:14:02
68	create index IDX_dashboard_provisioning_dashboard_id_name - v2	CREATE INDEX "IDX_dashboard_provisioning_dashboard_id_name" ON "dashboard_provisioning" ("dashboard_id","name");	t		2019-09-07 17:14:03
69	copy dashboard_provisioning v1 to v2	INSERT INTO "dashboard_provisioning" ("id"\n, "dashboard_id"\n, "name"\n, "external_id") SELECT "id"\n, "dashboard_id"\n, "name"\n, "external_id" FROM "dashboard_provisioning_tmp_qwerty"	t		2019-09-07 17:14:03
70	drop dashboard_provisioning_tmp_qwerty	DROP TABLE IF EXISTS "dashboard_provisioning_tmp_qwerty"	t		2019-09-07 17:14:03
71	Add check_sum column	alter table "dashboard_provisioning" ADD COLUMN "check_sum" VARCHAR(32) NULL 	t		2019-09-07 17:14:03
72	create data_source table	CREATE TABLE IF NOT EXISTS "data_source" (\n"id" SERIAL PRIMARY KEY  NOT NULL\n, "account_id" BIGINT NOT NULL\n, "version" INTEGER NOT NULL\n, "type" VARCHAR(255) NOT NULL\n, "name" VARCHAR(190) NOT NULL\n, "access" VARCHAR(255) NOT NULL\n, "url" VARCHAR(255) NOT NULL\n, "password" VARCHAR(255) NULL\n, "user" VARCHAR(255) NULL\n, "database" VARCHAR(255) NULL\n, "basic_auth" BOOL NOT NULL\n, "basic_auth_user" VARCHAR(255) NULL\n, "basic_auth_password" VARCHAR(255) NULL\n, "is_default" BOOL NOT NULL\n, "created" TIMESTAMP NOT NULL\n, "updated" TIMESTAMP NOT NULL\n);	t		2019-09-07 17:14:04
73	add index data_source.account_id	CREATE INDEX "IDX_data_source_account_id" ON "data_source" ("account_id");	t		2019-09-07 17:14:04
74	add unique index data_source.account_id_name	CREATE UNIQUE INDEX "UQE_data_source_account_id_name" ON "data_source" ("account_id","name");	t		2019-09-07 17:14:05
75	drop index IDX_data_source_account_id - v1	DROP INDEX "IDX_data_source_account_id"	t		2019-09-07 17:14:06
76	drop index UQE_data_source_account_id_name - v1	DROP INDEX "UQE_data_source_account_id_name"	t		2019-09-07 17:14:06
77	Rename table data_source to data_source_v1 - v1	ALTER TABLE "data_source" RENAME TO "data_source_v1"	t		2019-09-07 17:14:06
115	create index UQE_quota_org_id_user_id_target - v1	CREATE UNIQUE INDEX "UQE_quota_org_id_user_id_target" ON "quota" ("org_id","user_id","target");	t		2019-09-07 17:14:15
116	Update quota table charset	ALTER TABLE "quota" ALTER "target" TYPE VARCHAR(190);	t		2019-09-07 17:14:15
154	Add unique index alert_notification_org_id_uid	CREATE UNIQUE INDEX "UQE_alert_notification_org_id_uid" ON "alert_notification" ("org_id","uid");	t		2019-09-07 17:14:23
78	create data_source table v2	CREATE TABLE IF NOT EXISTS "data_source" (\n"id" SERIAL PRIMARY KEY  NOT NULL\n, "org_id" BIGINT NOT NULL\n, "version" INTEGER NOT NULL\n, "type" VARCHAR(255) NOT NULL\n, "name" VARCHAR(190) NOT NULL\n, "access" VARCHAR(255) NOT NULL\n, "url" VARCHAR(255) NOT NULL\n, "password" VARCHAR(255) NULL\n, "user" VARCHAR(255) NULL\n, "database" VARCHAR(255) NULL\n, "basic_auth" BOOL NOT NULL\n, "basic_auth_user" VARCHAR(255) NULL\n, "basic_auth_password" VARCHAR(255) NULL\n, "is_default" BOOL NOT NULL\n, "json_data" TEXT NULL\n, "created" TIMESTAMP NOT NULL\n, "updated" TIMESTAMP NOT NULL\n);	t		2019-09-07 17:14:06
79	create index IDX_data_source_org_id - v2	CREATE INDEX "IDX_data_source_org_id" ON "data_source" ("org_id");	t		2019-09-07 17:14:06
80	create index UQE_data_source_org_id_name - v2	CREATE UNIQUE INDEX "UQE_data_source_org_id_name" ON "data_source" ("org_id","name");	t		2019-09-07 17:14:07
81	copy data_source v1 to v2	INSERT INTO "data_source" ("org_id"\n, "version"\n, "basic_auth_password"\n, "updated"\n, "id"\n, "name"\n, "user"\n, "password"\n, "created"\n, "access"\n, "url"\n, "database"\n, "is_default"\n, "type"\n, "basic_auth"\n, "basic_auth_user") SELECT "account_id"\n, "version"\n, "basic_auth_password"\n, "updated"\n, "id"\n, "name"\n, "user"\n, "password"\n, "created"\n, "access"\n, "url"\n, "database"\n, "is_default"\n, "type"\n, "basic_auth"\n, "basic_auth_user" FROM "data_source_v1"	t		2019-09-07 17:14:07
82	Drop old table data_source_v1 #2	DROP TABLE IF EXISTS "data_source_v1"	t		2019-09-07 17:14:07
83	Add column with_credentials	alter table "data_source" ADD COLUMN "with_credentials" BOOL NOT NULL DEFAULT FALSE 	t		2019-09-07 17:14:07
84	Add secure json data column	alter table "data_source" ADD COLUMN "secure_json_data" TEXT NULL 	t		2019-09-07 17:14:08
85	Update data_source table charset	ALTER TABLE "data_source" ALTER "type" TYPE VARCHAR(255), ALTER "name" TYPE VARCHAR(190), ALTER "access" TYPE VARCHAR(255), ALTER "url" TYPE VARCHAR(255), ALTER "password" TYPE VARCHAR(255), ALTER "user" TYPE VARCHAR(255), ALTER "database" TYPE VARCHAR(255), ALTER "basic_auth_user" TYPE VARCHAR(255), ALTER "basic_auth_password" TYPE VARCHAR(255), ALTER "json_data" TYPE TEXT, ALTER "secure_json_data" TYPE TEXT;	t		2019-09-07 17:14:08
86	Update initial version to 1	UPDATE data_source SET version = 1 WHERE version = 0	t		2019-09-07 17:14:09
87	Add read_only data column	alter table "data_source" ADD COLUMN "read_only" BOOL NULL 	t		2019-09-07 17:14:09
88	Migrate logging ds to loki ds	UPDATE data_source SET type = 'loki' WHERE type = 'logging'	t		2019-09-07 17:14:09
89	Update json_data with nulls	UPDATE data_source SET json_data = '{}' WHERE json_data is null	t		2019-09-07 17:14:09
90	create api_key table	CREATE TABLE IF NOT EXISTS "api_key" (\n"id" SERIAL PRIMARY KEY  NOT NULL\n, "account_id" BIGINT NOT NULL\n, "name" VARCHAR(190) NOT NULL\n, "key" VARCHAR(64) NOT NULL\n, "role" VARCHAR(255) NOT NULL\n, "created" TIMESTAMP NOT NULL\n, "updated" TIMESTAMP NOT NULL\n);	t		2019-09-07 17:14:09
91	add index api_key.account_id	CREATE INDEX "IDX_api_key_account_id" ON "api_key" ("account_id");	t		2019-09-07 17:14:10
92	add index api_key.key	CREATE UNIQUE INDEX "UQE_api_key_key" ON "api_key" ("key");	t		2019-09-07 17:14:10
93	add index api_key.account_id_name	CREATE UNIQUE INDEX "UQE_api_key_account_id_name" ON "api_key" ("account_id","name");	t		2019-09-07 17:14:10
94	drop index IDX_api_key_account_id - v1	DROP INDEX "IDX_api_key_account_id"	t		2019-09-07 17:14:10
95	drop index UQE_api_key_key - v1	DROP INDEX "UQE_api_key_key"	t		2019-09-07 17:14:11
96	drop index UQE_api_key_account_id_name - v1	DROP INDEX "UQE_api_key_account_id_name"	t		2019-09-07 17:14:11
97	Rename table api_key to api_key_v1 - v1	ALTER TABLE "api_key" RENAME TO "api_key_v1"	t		2019-09-07 17:14:11
98	create api_key table v2	CREATE TABLE IF NOT EXISTS "api_key" (\n"id" SERIAL PRIMARY KEY  NOT NULL\n, "org_id" BIGINT NOT NULL\n, "name" VARCHAR(190) NOT NULL\n, "key" VARCHAR(190) NOT NULL\n, "role" VARCHAR(255) NOT NULL\n, "created" TIMESTAMP NOT NULL\n, "updated" TIMESTAMP NOT NULL\n);	t		2019-09-07 17:14:11
99	create index IDX_api_key_org_id - v2	CREATE INDEX "IDX_api_key_org_id" ON "api_key" ("org_id");	t		2019-09-07 17:14:12
100	create index UQE_api_key_key - v2	CREATE UNIQUE INDEX "UQE_api_key_key" ON "api_key" ("key");	t		2019-09-07 17:14:12
101	create index UQE_api_key_org_id_name - v2	CREATE UNIQUE INDEX "UQE_api_key_org_id_name" ON "api_key" ("org_id","name");	t		2019-09-07 17:14:12
102	copy api_key v1 to v2	INSERT INTO "api_key" ("name"\n, "key"\n, "role"\n, "created"\n, "updated"\n, "id"\n, "org_id") SELECT "name"\n, "key"\n, "role"\n, "created"\n, "updated"\n, "id"\n, "account_id" FROM "api_key_v1"	t		2019-09-07 17:14:12
103	Drop old table api_key_v1	DROP TABLE IF EXISTS "api_key_v1"	t		2019-09-07 17:14:12
104	Update api_key table charset	ALTER TABLE "api_key" ALTER "name" TYPE VARCHAR(190), ALTER "key" TYPE VARCHAR(190), ALTER "role" TYPE VARCHAR(255);	t		2019-09-07 17:14:12
105	create dashboard_snapshot table v4	CREATE TABLE IF NOT EXISTS "dashboard_snapshot" (\n"id" SERIAL PRIMARY KEY  NOT NULL\n, "name" VARCHAR(255) NOT NULL\n, "key" VARCHAR(190) NOT NULL\n, "dashboard" TEXT NOT NULL\n, "expires" TIMESTAMP NOT NULL\n, "created" TIMESTAMP NOT NULL\n, "updated" TIMESTAMP NOT NULL\n);	t		2019-09-07 17:14:13
106	drop table dashboard_snapshot_v4 #1	DROP TABLE IF EXISTS "dashboard_snapshot"	t		2019-09-07 17:14:13
107	create dashboard_snapshot table v5 #2	CREATE TABLE IF NOT EXISTS "dashboard_snapshot" (\n"id" SERIAL PRIMARY KEY  NOT NULL\n, "name" VARCHAR(255) NOT NULL\n, "key" VARCHAR(190) NOT NULL\n, "delete_key" VARCHAR(190) NOT NULL\n, "org_id" BIGINT NOT NULL\n, "user_id" BIGINT NOT NULL\n, "external" BOOL NOT NULL\n, "external_url" VARCHAR(255) NOT NULL\n, "dashboard" TEXT NOT NULL\n, "expires" TIMESTAMP NOT NULL\n, "created" TIMESTAMP NOT NULL\n, "updated" TIMESTAMP NOT NULL\n);	t		2019-09-07 17:14:13
108	create index UQE_dashboard_snapshot_key - v5	CREATE UNIQUE INDEX "UQE_dashboard_snapshot_key" ON "dashboard_snapshot" ("key");	t		2019-09-07 17:14:14
109	create index UQE_dashboard_snapshot_delete_key - v5	CREATE UNIQUE INDEX "UQE_dashboard_snapshot_delete_key" ON "dashboard_snapshot" ("delete_key");	t		2019-09-07 17:14:14
110	create index IDX_dashboard_snapshot_user_id - v5	CREATE INDEX "IDX_dashboard_snapshot_user_id" ON "dashboard_snapshot" ("user_id");	t		2019-09-07 17:14:14
111	alter dashboard_snapshot to mediumtext v2	SELECT 0;	t		2019-09-07 17:14:14
112	Update dashboard_snapshot table charset	ALTER TABLE "dashboard_snapshot" ALTER "name" TYPE VARCHAR(255), ALTER "key" TYPE VARCHAR(190), ALTER "delete_key" TYPE VARCHAR(190), ALTER "external_url" TYPE VARCHAR(255), ALTER "dashboard" TYPE TEXT;	t		2019-09-07 17:14:14
113	Add column external_delete_url to dashboard_snapshots table	alter table "dashboard_snapshot" ADD COLUMN "external_delete_url" VARCHAR(255) NULL 	t		2019-09-07 17:14:14
114	create quota table v1	CREATE TABLE IF NOT EXISTS "quota" (\n"id" SERIAL PRIMARY KEY  NOT NULL\n, "org_id" BIGINT NULL\n, "user_id" BIGINT NULL\n, "target" VARCHAR(190) NOT NULL\n, "limit" BIGINT NOT NULL\n, "created" TIMESTAMP NOT NULL\n, "updated" TIMESTAMP NOT NULL\n);	t		2019-09-07 17:14:14
155	Remove unique index org_id_name	DROP INDEX "UQE_alert_notification_org_id_name"	t		2019-09-07 17:14:23
117	create plugin_setting table	CREATE TABLE IF NOT EXISTS "plugin_setting" (\n"id" SERIAL PRIMARY KEY  NOT NULL\n, "org_id" BIGINT NULL\n, "plugin_id" VARCHAR(190) NOT NULL\n, "enabled" BOOL NOT NULL\n, "pinned" BOOL NOT NULL\n, "json_data" TEXT NULL\n, "secure_json_data" TEXT NULL\n, "created" TIMESTAMP NOT NULL\n, "updated" TIMESTAMP NOT NULL\n);	t		2019-09-07 17:14:15
118	create index UQE_plugin_setting_org_id_plugin_id - v1	CREATE UNIQUE INDEX "UQE_plugin_setting_org_id_plugin_id" ON "plugin_setting" ("org_id","plugin_id");	t		2019-09-07 17:14:15
119	Add column plugin_version to plugin_settings	alter table "plugin_setting" ADD COLUMN "plugin_version" VARCHAR(50) NULL 	t		2019-09-07 17:14:15
120	Update plugin_setting table charset	ALTER TABLE "plugin_setting" ALTER "plugin_id" TYPE VARCHAR(190), ALTER "json_data" TYPE TEXT, ALTER "secure_json_data" TYPE TEXT, ALTER "plugin_version" TYPE VARCHAR(50);	t		2019-09-07 17:14:16
121	create session table	CREATE TABLE IF NOT EXISTS "session" (\n"key" CHAR(16) PRIMARY KEY NOT NULL\n, "data" BYTEA NOT NULL\n, "expiry" INTEGER NOT NULL\n);	t		2019-09-07 17:14:16
122	Drop old table playlist table	DROP TABLE IF EXISTS "playlist"	t		2019-09-07 17:14:16
123	Drop old table playlist_item table	DROP TABLE IF EXISTS "playlist_item"	t		2019-09-07 17:14:16
124	create playlist table v2	CREATE TABLE IF NOT EXISTS "playlist" (\n"id" SERIAL PRIMARY KEY  NOT NULL\n, "name" VARCHAR(255) NOT NULL\n, "interval" VARCHAR(255) NOT NULL\n, "org_id" BIGINT NOT NULL\n);	t		2019-09-07 17:14:16
125	create playlist item table v2	CREATE TABLE IF NOT EXISTS "playlist_item" (\n"id" SERIAL PRIMARY KEY  NOT NULL\n, "playlist_id" BIGINT NOT NULL\n, "type" VARCHAR(255) NOT NULL\n, "value" TEXT NOT NULL\n, "title" TEXT NOT NULL\n, "order" INTEGER NOT NULL\n);	t		2019-09-07 17:14:17
126	Update playlist table charset	ALTER TABLE "playlist" ALTER "name" TYPE VARCHAR(255), ALTER "interval" TYPE VARCHAR(255);	t		2019-09-07 17:14:17
127	Update playlist_item table charset	ALTER TABLE "playlist_item" ALTER "type" TYPE VARCHAR(255), ALTER "value" TYPE TEXT, ALTER "title" TYPE TEXT;	t		2019-09-07 17:14:17
128	drop preferences table v2	DROP TABLE IF EXISTS "preferences"	t		2019-09-07 17:14:17
129	drop preferences table v3	DROP TABLE IF EXISTS "preferences"	t		2019-09-07 17:14:17
130	create preferences table v3	CREATE TABLE IF NOT EXISTS "preferences" (\n"id" SERIAL PRIMARY KEY  NOT NULL\n, "org_id" BIGINT NOT NULL\n, "user_id" BIGINT NOT NULL\n, "version" INTEGER NOT NULL\n, "home_dashboard_id" BIGINT NOT NULL\n, "timezone" VARCHAR(50) NOT NULL\n, "theme" VARCHAR(20) NOT NULL\n, "created" TIMESTAMP NOT NULL\n, "updated" TIMESTAMP NOT NULL\n);	t		2019-09-07 17:14:18
131	Update preferences table charset	ALTER TABLE "preferences" ALTER "timezone" TYPE VARCHAR(50), ALTER "theme" TYPE VARCHAR(20);	t		2019-09-07 17:14:18
132	Add column team_id in preferences	alter table "preferences" ADD COLUMN "team_id" BIGINT NULL 	t		2019-09-07 17:14:18
133	Update team_id column values in preferences	UPDATE preferences SET team_id=0 WHERE team_id IS NULL;	t		2019-09-07 17:14:18
134	create alert table v1	CREATE TABLE IF NOT EXISTS "alert" (\n"id" SERIAL PRIMARY KEY  NOT NULL\n, "version" BIGINT NOT NULL\n, "dashboard_id" BIGINT NOT NULL\n, "panel_id" BIGINT NOT NULL\n, "org_id" BIGINT NOT NULL\n, "name" VARCHAR(255) NOT NULL\n, "message" TEXT NOT NULL\n, "state" VARCHAR(190) NOT NULL\n, "settings" TEXT NOT NULL\n, "frequency" BIGINT NOT NULL\n, "handler" BIGINT NOT NULL\n, "severity" TEXT NOT NULL\n, "silenced" BOOL NOT NULL\n, "execution_error" TEXT NOT NULL\n, "eval_data" TEXT NULL\n, "eval_date" TIMESTAMP NULL\n, "new_state_date" TIMESTAMP NOT NULL\n, "state_changes" INTEGER NOT NULL\n, "created" TIMESTAMP NOT NULL\n, "updated" TIMESTAMP NOT NULL\n);	t		2019-09-07 17:14:18
135	add index alert org_id & id 	CREATE INDEX "IDX_alert_org_id_id" ON "alert" ("org_id","id");	t		2019-09-07 17:14:18
136	add index alert state	CREATE INDEX "IDX_alert_state" ON "alert" ("state");	t		2019-09-07 17:14:19
137	add index alert dashboard_id	CREATE INDEX "IDX_alert_dashboard_id" ON "alert" ("dashboard_id");	t		2019-09-07 17:14:19
138	create alert_notification table v1	CREATE TABLE IF NOT EXISTS "alert_notification" (\n"id" SERIAL PRIMARY KEY  NOT NULL\n, "org_id" BIGINT NOT NULL\n, "name" VARCHAR(190) NOT NULL\n, "type" VARCHAR(255) NOT NULL\n, "settings" TEXT NOT NULL\n, "created" TIMESTAMP NOT NULL\n, "updated" TIMESTAMP NOT NULL\n);	t		2019-09-07 17:14:19
139	Add column is_default	alter table "alert_notification" ADD COLUMN "is_default" BOOL NOT NULL DEFAULT FALSE 	t		2019-09-07 17:14:20
140	Add column frequency	alter table "alert_notification" ADD COLUMN "frequency" BIGINT NULL 	t		2019-09-07 17:14:20
141	Add column send_reminder	alter table "alert_notification" ADD COLUMN "send_reminder" BOOL NULL DEFAULT FALSE 	t		2019-09-07 17:14:20
142	Add column disable_resolve_message	alter table "alert_notification" ADD COLUMN "disable_resolve_message" BOOL NOT NULL DEFAULT FALSE 	t		2019-09-07 17:14:20
143	add index alert_notification org_id & name	CREATE UNIQUE INDEX "UQE_alert_notification_org_id_name" ON "alert_notification" ("org_id","name");	t		2019-09-07 17:14:21
144	Update alert table charset	ALTER TABLE "alert" ALTER "name" TYPE VARCHAR(255), ALTER "message" TYPE TEXT, ALTER "state" TYPE VARCHAR(190), ALTER "settings" TYPE TEXT, ALTER "severity" TYPE TEXT, ALTER "execution_error" TYPE TEXT, ALTER "eval_data" TYPE TEXT;	t		2019-09-07 17:14:21
145	Update alert_notification table charset	ALTER TABLE "alert_notification" ALTER "name" TYPE VARCHAR(190), ALTER "type" TYPE VARCHAR(255), ALTER "settings" TYPE TEXT;	t		2019-09-07 17:14:21
146	create notification_journal table v1	CREATE TABLE IF NOT EXISTS "alert_notification_journal" (\n"id" SERIAL PRIMARY KEY  NOT NULL\n, "org_id" BIGINT NOT NULL\n, "alert_id" BIGINT NOT NULL\n, "notifier_id" BIGINT NOT NULL\n, "sent_at" BIGINT NOT NULL\n, "success" BOOL NOT NULL\n);	t		2019-09-07 17:14:22
147	add index notification_journal org_id & alert_id & notifier_id	CREATE INDEX "IDX_alert_notification_journal_org_id_alert_id_notifier_id" ON "alert_notification_journal" ("org_id","alert_id","notifier_id");	t		2019-09-07 17:14:22
148	drop alert_notification_journal	DROP TABLE IF EXISTS "alert_notification_journal"	t		2019-09-07 17:14:22
149	create alert_notification_state table v1	CREATE TABLE IF NOT EXISTS "alert_notification_state" (\n"id" SERIAL PRIMARY KEY  NOT NULL\n, "org_id" BIGINT NOT NULL\n, "alert_id" BIGINT NOT NULL\n, "notifier_id" BIGINT NOT NULL\n, "state" VARCHAR(50) NOT NULL\n, "version" BIGINT NOT NULL\n, "updated_at" BIGINT NOT NULL\n, "alert_rule_state_updated_version" BIGINT NOT NULL\n);	t		2019-09-07 17:14:22
150	add index alert_notification_state org_id & alert_id & notifier_id	CREATE UNIQUE INDEX "UQE_alert_notification_state_org_id_alert_id_notifier_id" ON "alert_notification_state" ("org_id","alert_id","notifier_id");	t		2019-09-07 17:14:22
151	Add for to alert table	alter table "alert" ADD COLUMN "for" BIGINT NULL 	t		2019-09-07 17:14:22
152	Add column uid in alert_notification	alter table "alert_notification" ADD COLUMN "uid" VARCHAR(40) NULL 	t		2019-09-07 17:14:23
153	Update uid column values in alert_notification	UPDATE alert_notification SET uid=lpad('' || id,9,'0') WHERE uid IS NULL;	t		2019-09-07 17:14:23
156	Drop old annotation table v4	DROP TABLE IF EXISTS "annotation"	t		2019-09-07 17:14:23
157	create annotation table v5	CREATE TABLE IF NOT EXISTS "annotation" (\n"id" SERIAL PRIMARY KEY  NOT NULL\n, "org_id" BIGINT NOT NULL\n, "alert_id" BIGINT NULL\n, "user_id" BIGINT NULL\n, "dashboard_id" BIGINT NULL\n, "panel_id" BIGINT NULL\n, "category_id" BIGINT NULL\n, "type" VARCHAR(25) NOT NULL\n, "title" TEXT NOT NULL\n, "text" TEXT NOT NULL\n, "metric" VARCHAR(255) NULL\n, "prev_state" VARCHAR(25) NOT NULL\n, "new_state" VARCHAR(25) NOT NULL\n, "data" TEXT NOT NULL\n, "epoch" BIGINT NOT NULL\n);	t		2019-09-07 17:14:23
158	add index annotation 0 v3	CREATE INDEX "IDX_annotation_org_id_alert_id" ON "annotation" ("org_id","alert_id");	t		2019-09-07 17:14:23
159	add index annotation 1 v3	CREATE INDEX "IDX_annotation_org_id_type" ON "annotation" ("org_id","type");	t		2019-09-07 17:14:24
160	add index annotation 2 v3	CREATE INDEX "IDX_annotation_org_id_category_id" ON "annotation" ("org_id","category_id");	t		2019-09-07 17:14:24
161	add index annotation 3 v3	CREATE INDEX "IDX_annotation_org_id_dashboard_id_panel_id_epoch" ON "annotation" ("org_id","dashboard_id","panel_id","epoch");	t		2019-09-07 17:14:24
162	add index annotation 4 v3	CREATE INDEX "IDX_annotation_org_id_epoch" ON "annotation" ("org_id","epoch");	t		2019-09-07 17:14:24
163	Update annotation table charset	ALTER TABLE "annotation" ALTER "type" TYPE VARCHAR(25), ALTER "title" TYPE TEXT, ALTER "text" TYPE TEXT, ALTER "metric" TYPE VARCHAR(255), ALTER "prev_state" TYPE VARCHAR(25), ALTER "new_state" TYPE VARCHAR(25), ALTER "data" TYPE TEXT;	t		2019-09-07 17:14:24
164	Add column region_id to annotation table	alter table "annotation" ADD COLUMN "region_id" BIGINT NULL DEFAULT 0 	t		2019-09-07 17:14:24
165	Drop category_id index	DROP INDEX "IDX_annotation_org_id_category_id"	t		2019-09-07 17:14:25
166	Add column tags to annotation table	alter table "annotation" ADD COLUMN "tags" VARCHAR(500) NULL 	t		2019-09-07 17:14:25
167	Create annotation_tag table v2	CREATE TABLE IF NOT EXISTS "annotation_tag" (\n"annotation_id" BIGINT NOT NULL\n, "tag_id" BIGINT NOT NULL\n);	t		2019-09-07 17:14:25
168	Add unique index annotation_tag.annotation_id_tag_id	CREATE UNIQUE INDEX "UQE_annotation_tag_annotation_id_tag_id" ON "annotation_tag" ("annotation_id","tag_id");	t		2019-09-07 17:14:25
169	Update alert annotations and set TEXT to empty	UPDATE annotation SET TEXT = '' WHERE alert_id > 0	t		2019-09-07 17:14:26
170	Add created time to annotation table	alter table "annotation" ADD COLUMN "created" BIGINT NULL DEFAULT 0 	t		2019-09-07 17:14:26
171	Add updated time to annotation table	alter table "annotation" ADD COLUMN "updated" BIGINT NULL DEFAULT 0 	t		2019-09-07 17:14:27
172	Add index for created in annotation table	CREATE INDEX "IDX_annotation_org_id_created" ON "annotation" ("org_id","created");	t		2019-09-07 17:14:28
173	Add index for updated in annotation table	CREATE INDEX "IDX_annotation_org_id_updated" ON "annotation" ("org_id","updated");	t		2019-09-07 17:14:28
174	Convert existing annotations from seconds to milliseconds	UPDATE annotation SET epoch = (epoch*1000) where epoch < 9999999999	t		2019-09-07 17:14:29
175	create test_data table	CREATE TABLE IF NOT EXISTS "test_data" (\n"id" SERIAL PRIMARY KEY  NOT NULL\n, "metric1" VARCHAR(20) NULL\n, "metric2" VARCHAR(150) NULL\n, "value_big_int" BIGINT NULL\n, "value_double" DOUBLE PRECISION NULL\n, "value_float" REAL NULL\n, "value_int" INTEGER NULL\n, "time_epoch" BIGINT NOT NULL\n, "time_date_time" TIMESTAMP NOT NULL\n, "time_time_stamp" TIMESTAMP NOT NULL\n);	t		2019-09-07 17:14:29
176	create dashboard_version table v1	CREATE TABLE IF NOT EXISTS "dashboard_version" (\n"id" SERIAL PRIMARY KEY  NOT NULL\n, "dashboard_id" BIGINT NOT NULL\n, "parent_version" INTEGER NOT NULL\n, "restored_from" INTEGER NOT NULL\n, "version" INTEGER NOT NULL\n, "created" TIMESTAMP NOT NULL\n, "created_by" BIGINT NOT NULL\n, "message" TEXT NOT NULL\n, "data" TEXT NOT NULL\n);	t		2019-09-07 17:14:30
177	add index dashboard_version.dashboard_id	CREATE INDEX "IDX_dashboard_version_dashboard_id" ON "dashboard_version" ("dashboard_id");	t		2019-09-07 17:14:30
178	add unique index dashboard_version.dashboard_id and dashboard_version.version	CREATE UNIQUE INDEX "UQE_dashboard_version_dashboard_id_version" ON "dashboard_version" ("dashboard_id","version");	t		2019-09-07 17:14:31
179	Set dashboard version to 1 where 0	UPDATE dashboard SET version = 1 WHERE version = 0	t		2019-09-07 17:14:31
180	save existing dashboard data in dashboard_version table v1	INSERT INTO dashboard_version\n(\n\tdashboard_id,\n\tversion,\n\tparent_version,\n\trestored_from,\n\tcreated,\n\tcreated_by,\n\tmessage,\n\tdata\n)\nSELECT\n\tdashboard.id,\n\tdashboard.version,\n\tdashboard.version,\n\tdashboard.version,\n\tdashboard.updated,\n\tCOALESCE(dashboard.updated_by, -1),\n\t'',\n\tdashboard.data\nFROM dashboard;	t		2019-09-07 17:14:31
181	alter dashboard_version.data to mediumtext v1	SELECT 0;	t		2019-09-07 17:14:32
182	create team table	CREATE TABLE IF NOT EXISTS "team" (\n"id" SERIAL PRIMARY KEY  NOT NULL\n, "name" VARCHAR(190) NOT NULL\n, "org_id" BIGINT NOT NULL\n, "created" TIMESTAMP NOT NULL\n, "updated" TIMESTAMP NOT NULL\n);	t		2019-09-07 17:14:32
183	add index team.org_id	CREATE INDEX "IDX_team_org_id" ON "team" ("org_id");	t		2019-09-07 17:14:32
184	add unique index team_org_id_name	CREATE UNIQUE INDEX "UQE_team_org_id_name" ON "team" ("org_id","name");	t		2019-09-07 17:14:32
185	create team member table	CREATE TABLE IF NOT EXISTS "team_member" (\n"id" SERIAL PRIMARY KEY  NOT NULL\n, "org_id" BIGINT NOT NULL\n, "team_id" BIGINT NOT NULL\n, "user_id" BIGINT NOT NULL\n, "created" TIMESTAMP NOT NULL\n, "updated" TIMESTAMP NOT NULL\n);	t		2019-09-07 17:14:33
186	add index team_member.org_id	CREATE INDEX "IDX_team_member_org_id" ON "team_member" ("org_id");	t		2019-09-07 17:14:33
187	add unique index team_member_org_id_team_id_user_id	CREATE UNIQUE INDEX "UQE_team_member_org_id_team_id_user_id" ON "team_member" ("org_id","team_id","user_id");	t		2019-09-07 17:14:33
188	Add column email to team table	alter table "team" ADD COLUMN "email" VARCHAR(190) NULL 	t		2019-09-07 17:14:34
189	Add column external to team_member table	alter table "team_member" ADD COLUMN "external" BOOL NULL 	t		2019-09-07 17:14:34
190	Add column permission to team_member table	alter table "team_member" ADD COLUMN "permission" SMALLINT NULL 	t		2019-09-07 17:14:34
191	create dashboard acl table	CREATE TABLE IF NOT EXISTS "dashboard_acl" (\n"id" SERIAL PRIMARY KEY  NOT NULL\n, "org_id" BIGINT NOT NULL\n, "dashboard_id" BIGINT NOT NULL\n, "user_id" BIGINT NULL\n, "team_id" BIGINT NULL\n, "permission" SMALLINT NOT NULL DEFAULT 4\n, "role" VARCHAR(20) NULL\n, "created" TIMESTAMP NOT NULL\n, "updated" TIMESTAMP NOT NULL\n);	t		2019-09-07 17:14:34
192	add index dashboard_acl_dashboard_id	CREATE INDEX "IDX_dashboard_acl_dashboard_id" ON "dashboard_acl" ("dashboard_id");	t		2019-09-07 17:14:34
193	add unique index dashboard_acl_dashboard_id_user_id	CREATE UNIQUE INDEX "UQE_dashboard_acl_dashboard_id_user_id" ON "dashboard_acl" ("dashboard_id","user_id");	t		2019-09-07 17:14:34
194	add unique index dashboard_acl_dashboard_id_team_id	CREATE UNIQUE INDEX "UQE_dashboard_acl_dashboard_id_team_id" ON "dashboard_acl" ("dashboard_id","team_id");	t		2019-09-07 17:14:35
195	save default acl rules in dashboard_acl table	\nINSERT INTO dashboard_acl\n\t(\n\t\torg_id,\n\t\tdashboard_id,\n\t\tpermission,\n\t\trole,\n\t\tcreated,\n\t\tupdated\n\t)\n\tVALUES\n\t\t(-1,-1, 1,'Viewer','2017-06-20','2017-06-20'),\n\t\t(-1,-1, 2,'Editor','2017-06-20','2017-06-20')\n\t	t		2019-09-07 17:14:35
196	create tag table	CREATE TABLE IF NOT EXISTS "tag" (\n"id" SERIAL PRIMARY KEY  NOT NULL\n, "key" VARCHAR(100) NOT NULL\n, "value" VARCHAR(100) NOT NULL\n);	t		2019-09-07 17:14:35
197	add index tag.key_value	CREATE UNIQUE INDEX "UQE_tag_key_value" ON "tag" ("key","value");	t		2019-09-07 17:14:36
198	create login attempt table	CREATE TABLE IF NOT EXISTS "login_attempt" (\n"id" SERIAL PRIMARY KEY  NOT NULL\n, "username" VARCHAR(190) NOT NULL\n, "ip_address" VARCHAR(30) NOT NULL\n, "created" TIMESTAMP NOT NULL\n);	t		2019-09-07 17:14:36
199	add index login_attempt.username	CREATE INDEX "IDX_login_attempt_username" ON "login_attempt" ("username");	t		2019-09-07 17:14:36
200	drop index IDX_login_attempt_username - v1	DROP INDEX "IDX_login_attempt_username"	t		2019-09-07 17:14:37
201	Rename table login_attempt to login_attempt_tmp_qwerty - v1	ALTER TABLE "login_attempt" RENAME TO "login_attempt_tmp_qwerty"	t		2019-09-07 17:14:37
202	create login_attempt v2	CREATE TABLE IF NOT EXISTS "login_attempt" (\n"id" SERIAL PRIMARY KEY  NOT NULL\n, "username" VARCHAR(190) NOT NULL\n, "ip_address" VARCHAR(30) NOT NULL\n, "created" INTEGER NOT NULL DEFAULT 0\n);	t		2019-09-07 17:14:37
203	create index IDX_login_attempt_username - v2	CREATE INDEX "IDX_login_attempt_username" ON "login_attempt" ("username");	t		2019-09-07 17:14:37
204	copy login_attempt v1 to v2	INSERT INTO "login_attempt" ("id"\n, "username"\n, "ip_address") SELECT "id"\n, "username"\n, "ip_address" FROM "login_attempt_tmp_qwerty"	t		2019-09-07 17:14:38
205	drop login_attempt_tmp_qwerty	DROP TABLE IF EXISTS "login_attempt_tmp_qwerty"	t		2019-09-07 17:14:38
206	create user auth table	CREATE TABLE IF NOT EXISTS "user_auth" (\n"id" SERIAL PRIMARY KEY  NOT NULL\n, "user_id" BIGINT NOT NULL\n, "auth_module" VARCHAR(190) NOT NULL\n, "auth_id" VARCHAR(100) NOT NULL\n, "created" TIMESTAMP NOT NULL\n);	t		2019-09-07 17:14:38
207	create index IDX_user_auth_auth_module_auth_id - v1	CREATE INDEX "IDX_user_auth_auth_module_auth_id" ON "user_auth" ("auth_module","auth_id");	t		2019-09-07 17:14:38
208	alter user_auth.auth_id to length 190	ALTER TABLE user_auth ALTER COLUMN auth_id TYPE VARCHAR(190);	t		2019-09-07 17:14:39
209	Add OAuth access token to user_auth	alter table "user_auth" ADD COLUMN "o_auth_access_token" TEXT NULL 	t		2019-09-07 17:14:39
210	Add OAuth refresh token to user_auth	alter table "user_auth" ADD COLUMN "o_auth_refresh_token" TEXT NULL 	t		2019-09-07 17:14:39
211	Add OAuth token type to user_auth	alter table "user_auth" ADD COLUMN "o_auth_token_type" TEXT NULL 	t		2019-09-07 17:14:39
212	Add OAuth expiry to user_auth	alter table "user_auth" ADD COLUMN "o_auth_expiry" TIMESTAMP NULL 	t		2019-09-07 17:14:39
213	Add index to user_id column in user_auth	CREATE INDEX "IDX_user_auth_user_id" ON "user_auth" ("user_id");	t		2019-09-07 17:14:40
214	create server_lock table	CREATE TABLE IF NOT EXISTS "server_lock" (\n"id" SERIAL PRIMARY KEY  NOT NULL\n, "operation_uid" VARCHAR(100) NOT NULL\n, "version" BIGINT NOT NULL\n, "last_execution" BIGINT NOT NULL\n);	t		2019-09-07 17:14:40
215	add index server_lock.operation_uid	CREATE UNIQUE INDEX "UQE_server_lock_operation_uid" ON "server_lock" ("operation_uid");	t		2019-09-07 17:14:41
216	create user auth token table	CREATE TABLE IF NOT EXISTS "user_auth_token" (\n"id" SERIAL PRIMARY KEY  NOT NULL\n, "user_id" BIGINT NOT NULL\n, "auth_token" VARCHAR(100) NOT NULL\n, "prev_auth_token" VARCHAR(100) NOT NULL\n, "user_agent" VARCHAR(255) NOT NULL\n, "client_ip" VARCHAR(255) NOT NULL\n, "auth_token_seen" BOOL NOT NULL\n, "seen_at" INTEGER NULL\n, "rotated_at" INTEGER NOT NULL\n, "created_at" INTEGER NOT NULL\n, "updated_at" INTEGER NOT NULL\n);	t		2019-09-07 17:14:41
217	add unique index user_auth_token.auth_token	CREATE UNIQUE INDEX "UQE_user_auth_token_auth_token" ON "user_auth_token" ("auth_token");	t		2019-09-07 17:14:42
218	add unique index user_auth_token.prev_auth_token	CREATE UNIQUE INDEX "UQE_user_auth_token_prev_auth_token" ON "user_auth_token" ("prev_auth_token");	t		2019-09-07 17:14:42
219	create cache_data table	CREATE TABLE IF NOT EXISTS "cache_data" (\n"cache_key" VARCHAR(168) PRIMARY KEY NOT NULL\n, "data" BYTEA NOT NULL\n, "expires" INTEGER NOT NULL\n, "created_at" INTEGER NOT NULL\n);	t		2019-09-07 17:14:43
220	add unique index cache_data.cache_key	CREATE UNIQUE INDEX "UQE_cache_data_cache_key" ON "cache_data" ("cache_key");	t		2019-09-07 17:14:44
230	Add is_disabled column to user	alter table "user" ADD COLUMN "is_disabled" BOOL NOT NULL DEFAULT FALSE 	t		2019-09-29 07:38:26
231	Add expires to api_key table	alter table "api_key" ADD COLUMN "expires" BIGINT NULL 	t		2019-09-29 07:38:28
232	Create alert_rule_tag table v1	CREATE TABLE IF NOT EXISTS "alert_rule_tag" (\n"alert_id" BIGINT NOT NULL\n, "tag_id" BIGINT NOT NULL\n);	t		2019-09-29 07:38:28
233	Add unique index alert_rule_tag.alert_id_tag_id	CREATE UNIQUE INDEX "UQE_alert_rule_tag_alert_id_tag_id" ON "alert_rule_tag" ("alert_id","tag_id");	t		2019-09-29 07:38:28
234	Add epoch_end column	alter table "annotation" ADD COLUMN "epoch_end" BIGINT NOT NULL DEFAULT 0 	t		2019-09-29 07:38:28
235	Add index for epoch_end	CREATE INDEX "IDX_annotation_org_id_epoch_epoch_end" ON "annotation" ("org_id","epoch","epoch_end");	t		2019-09-29 07:38:30
236	Make epoch_end the same as epoch	UPDATE annotation SET epoch_end = epoch	t		2019-09-29 07:38:30
237	Move region to single row	code migration	t		2019-09-29 07:38:30
\.


--
-- Data for Name: org; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.org (id, version, name, address1, address2, city, state, zip_code, country, billing_email, created, updated) FROM stdin;
1	0	Main Org.							\N	2019-09-07 17:14:44	2019-09-07 17:14:44
\.


--
-- Data for Name: org_user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.org_user (id, org_id, user_id, role, created, updated) FROM stdin;
1	1	1	Admin	2019-09-07 17:14:44	2019-09-07 17:14:44
\.


--
-- Data for Name: playlist; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.playlist (id, name, "interval", org_id) FROM stdin;
\.


--
-- Data for Name: playlist_item; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.playlist_item (id, playlist_id, type, value, title, "order") FROM stdin;
\.


--
-- Data for Name: plugin_setting; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.plugin_setting (id, org_id, plugin_id, enabled, pinned, json_data, secure_json_data, created, updated, plugin_version) FROM stdin;
\.


--
-- Data for Name: preferences; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.preferences (id, org_id, user_id, version, home_dashboard_id, timezone, theme, created, updated, team_id) FROM stdin;
1	1	1	0	0		light	2020-01-09 13:20:19	2020-01-09 13:20:19	0
\.


--
-- Data for Name: quota; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quota (id, org_id, user_id, target, "limit", created, updated) FROM stdin;
\.


--
-- Data for Name: server_lock; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.server_lock (id, operation_uid, version, last_execution) FROM stdin;
34	delete old login attempts	5765	1579617581
1	cleanup expired auth tokens	86	1579615781
\.


--
-- Data for Name: session; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.session (key, data, expiry) FROM stdin;
\.


--
-- Data for Name: star; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.star (id, user_id, dashboard_id) FROM stdin;
\.


--
-- Data for Name: tag; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tag (id, key, value) FROM stdin;
\.


--
-- Data for Name: team; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.team (id, name, org_id, created, updated, email) FROM stdin;
\.


--
-- Data for Name: team_member; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.team_member (id, org_id, team_id, user_id, created, updated, external, permission) FROM stdin;
\.


--
-- Data for Name: temp_user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.temp_user (id, org_id, version, email, name, role, code, status, invited_by_user_id, email_sent, email_sent_on, remote_addr, created, updated) FROM stdin;
\.


--
-- Data for Name: test_data; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.test_data (id, metric1, metric2, value_big_int, value_double, value_float, value_int, time_epoch, time_date_time, time_time_stamp) FROM stdin;
\.


--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."user" (id, version, login, email, name, password, salt, rands, company, org_id, is_admin, email_verified, theme, created, updated, help_flags1, last_seen_at, is_disabled) FROM stdin;
1	0	admin	admin@localhost		3ee07f513fb4e6947e33f975638a85cf48ef790ae3ab3c91dbe29fcfbf29c243db39a10d544952c2c8b9681d8abb458dcfac	baHJC9sHaf	g3pf2iwyV4		1	t	f		2019-09-07 17:14:44	2019-09-07 17:14:44	0	2020-01-21 14:39:38	f
\.


--
-- Data for Name: user_auth; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_auth (id, user_id, auth_module, auth_id, created, o_auth_access_token, o_auth_refresh_token, o_auth_token_type, o_auth_expiry) FROM stdin;
\.


--
-- Data for Name: user_auth_token; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_auth_token (id, user_id, auth_token, prev_auth_token, user_agent, client_ip, auth_token_seen, seen_at, rotated_at, created_at, updated_at) FROM stdin;
46	1	68160b28e208a636483e5f0bb39fcf1c3512832be3f3181537582782b2968592	68160b28e208a636483e5f0bb39fcf1c3512832be3f3181537582782b2968592	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:72.0) Gecko/20100101 Firefox/72.0	192.168.1.235	t	1579615006	1579615004	1579615004	1579615004
45	1	c3645a6c5ec0722b3aa2db5579583ec65452ea1d12ddda087dd4772388723b53	5cc546923e6c74d9d95d9f55fb0479a2178746d8d818ad044fa4ca27ba29d3b1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36	192.168.1.121	t	1579617274	1579617274	1579594021	1579594021
47	1	88ddf566565f89b4eaab3d5103878f1391d529c8c50abe06ac054cde43b12110	88ddf566565f89b4eaab3d5103878f1391d529c8c50abe06ac054cde43b12110	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36	192.168.1.121	t	1579617425	1579617423	1579617423	1579617423
\.


--
-- Name: alert_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.alert_id_seq', 1, false);


--
-- Name: alert_notification_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.alert_notification_id_seq', 1, false);


--
-- Name: alert_notification_state_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.alert_notification_state_id_seq', 1, false);


--
-- Name: annotation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.annotation_id_seq', 1, false);


--
-- Name: api_key_id_seq1; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.api_key_id_seq1', 1, true);


--
-- Name: dashboard_acl_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.dashboard_acl_id_seq', 33, true);


--
-- Name: dashboard_id_seq1; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.dashboard_id_seq1', 16, true);


--
-- Name: dashboard_provisioning_id_seq1; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.dashboard_provisioning_id_seq1', 1, false);


--
-- Name: dashboard_snapshot_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.dashboard_snapshot_id_seq', 1, false);


--
-- Name: dashboard_tag_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.dashboard_tag_id_seq', 217, true);


--
-- Name: dashboard_version_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.dashboard_version_id_seq', 331, true);


--
-- Name: data_source_id_seq1; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.data_source_id_seq1', 1, true);


--
-- Name: login_attempt_id_seq1; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.login_attempt_id_seq1', 1, false);


--
-- Name: migration_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.migration_log_id_seq', 237, true);


--
-- Name: org_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.org_id_seq', 1, false);


--
-- Name: org_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.org_user_id_seq', 33, true);


--
-- Name: playlist_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.playlist_id_seq', 1, false);


--
-- Name: playlist_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.playlist_item_id_seq', 1, false);


--
-- Name: plugin_setting_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.plugin_setting_id_seq', 1, false);


--
-- Name: preferences_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.preferences_id_seq', 1, true);


--
-- Name: quota_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.quota_id_seq', 1, false);


--
-- Name: server_lock_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.server_lock_id_seq', 34, true);


--
-- Name: star_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.star_id_seq', 1, false);


--
-- Name: tag_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tag_id_seq', 1, false);


--
-- Name: team_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.team_id_seq', 1, false);


--
-- Name: team_member_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.team_member_id_seq', 1, false);


--
-- Name: temp_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.temp_user_id_seq', 1, false);


--
-- Name: test_data_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.test_data_id_seq', 1, false);


--
-- Name: user_auth_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_auth_id_seq', 1, false);


--
-- Name: user_auth_token_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_auth_token_id_seq', 47, true);


--
-- Name: user_id_seq1; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_id_seq1', 33, true);


--
-- Name: alert_notification alert_notification_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alert_notification
    ADD CONSTRAINT alert_notification_pkey PRIMARY KEY (id);


--
-- Name: alert_notification_state alert_notification_state_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alert_notification_state
    ADD CONSTRAINT alert_notification_state_pkey PRIMARY KEY (id);


--
-- Name: alert alert_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alert
    ADD CONSTRAINT alert_pkey PRIMARY KEY (id);


--
-- Name: annotation annotation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.annotation
    ADD CONSTRAINT annotation_pkey PRIMARY KEY (id);


--
-- Name: api_key api_key_pkey1; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_key
    ADD CONSTRAINT api_key_pkey1 PRIMARY KEY (id);


--
-- Name: cache_data cache_data_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cache_data
    ADD CONSTRAINT cache_data_pkey PRIMARY KEY (cache_key);


--
-- Name: dashboard_acl dashboard_acl_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dashboard_acl
    ADD CONSTRAINT dashboard_acl_pkey PRIMARY KEY (id);


--
-- Name: dashboard dashboard_pkey1; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dashboard
    ADD CONSTRAINT dashboard_pkey1 PRIMARY KEY (id);


--
-- Name: dashboard_provisioning dashboard_provisioning_pkey1; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dashboard_provisioning
    ADD CONSTRAINT dashboard_provisioning_pkey1 PRIMARY KEY (id);


--
-- Name: dashboard_snapshot dashboard_snapshot_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dashboard_snapshot
    ADD CONSTRAINT dashboard_snapshot_pkey PRIMARY KEY (id);


--
-- Name: dashboard_tag dashboard_tag_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dashboard_tag
    ADD CONSTRAINT dashboard_tag_pkey PRIMARY KEY (id);


--
-- Name: dashboard_version dashboard_version_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dashboard_version
    ADD CONSTRAINT dashboard_version_pkey PRIMARY KEY (id);


--
-- Name: data_source data_source_pkey1; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.data_source
    ADD CONSTRAINT data_source_pkey1 PRIMARY KEY (id);


--
-- Name: login_attempt login_attempt_pkey1; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.login_attempt
    ADD CONSTRAINT login_attempt_pkey1 PRIMARY KEY (id);


--
-- Name: migration_log migration_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.migration_log
    ADD CONSTRAINT migration_log_pkey PRIMARY KEY (id);


--
-- Name: org org_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.org
    ADD CONSTRAINT org_pkey PRIMARY KEY (id);


--
-- Name: org_user org_user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.org_user
    ADD CONSTRAINT org_user_pkey PRIMARY KEY (id);


--
-- Name: playlist_item playlist_item_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.playlist_item
    ADD CONSTRAINT playlist_item_pkey PRIMARY KEY (id);


--
-- Name: playlist playlist_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.playlist
    ADD CONSTRAINT playlist_pkey PRIMARY KEY (id);


--
-- Name: plugin_setting plugin_setting_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plugin_setting
    ADD CONSTRAINT plugin_setting_pkey PRIMARY KEY (id);


--
-- Name: preferences preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.preferences
    ADD CONSTRAINT preferences_pkey PRIMARY KEY (id);


--
-- Name: quota quota_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quota
    ADD CONSTRAINT quota_pkey PRIMARY KEY (id);


--
-- Name: server_lock server_lock_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.server_lock
    ADD CONSTRAINT server_lock_pkey PRIMARY KEY (id);


--
-- Name: session session_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.session
    ADD CONSTRAINT session_pkey PRIMARY KEY (key);


--
-- Name: star star_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.star
    ADD CONSTRAINT star_pkey PRIMARY KEY (id);


--
-- Name: tag tag_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tag
    ADD CONSTRAINT tag_pkey PRIMARY KEY (id);


--
-- Name: team_member team_member_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.team_member
    ADD CONSTRAINT team_member_pkey PRIMARY KEY (id);


--
-- Name: team team_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.team
    ADD CONSTRAINT team_pkey PRIMARY KEY (id);


--
-- Name: temp_user temp_user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.temp_user
    ADD CONSTRAINT temp_user_pkey PRIMARY KEY (id);


--
-- Name: test_data test_data_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_data
    ADD CONSTRAINT test_data_pkey PRIMARY KEY (id);


--
-- Name: user_auth user_auth_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_auth
    ADD CONSTRAINT user_auth_pkey PRIMARY KEY (id);


--
-- Name: user_auth_token user_auth_token_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_auth_token
    ADD CONSTRAINT user_auth_token_pkey PRIMARY KEY (id);


--
-- Name: user user_pkey1; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_pkey1 PRIMARY KEY (id);


--
-- Name: IDX_alert_dashboard_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_alert_dashboard_id" ON public.alert USING btree (dashboard_id);


--
-- Name: IDX_alert_org_id_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_alert_org_id_id" ON public.alert USING btree (org_id, id);


--
-- Name: IDX_alert_state; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_alert_state" ON public.alert USING btree (state);


--
-- Name: IDX_annotation_org_id_alert_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_annotation_org_id_alert_id" ON public.annotation USING btree (org_id, alert_id);


--
-- Name: IDX_annotation_org_id_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_annotation_org_id_created" ON public.annotation USING btree (org_id, created);


--
-- Name: IDX_annotation_org_id_dashboard_id_panel_id_epoch; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_annotation_org_id_dashboard_id_panel_id_epoch" ON public.annotation USING btree (org_id, dashboard_id, panel_id, epoch);


--
-- Name: IDX_annotation_org_id_epoch; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_annotation_org_id_epoch" ON public.annotation USING btree (org_id, epoch);


--
-- Name: IDX_annotation_org_id_epoch_epoch_end; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_annotation_org_id_epoch_epoch_end" ON public.annotation USING btree (org_id, epoch, epoch_end);


--
-- Name: IDX_annotation_org_id_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_annotation_org_id_type" ON public.annotation USING btree (org_id, type);


--
-- Name: IDX_annotation_org_id_updated; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_annotation_org_id_updated" ON public.annotation USING btree (org_id, updated);


--
-- Name: IDX_api_key_org_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_api_key_org_id" ON public.api_key USING btree (org_id);


--
-- Name: IDX_dashboard_acl_dashboard_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_dashboard_acl_dashboard_id" ON public.dashboard_acl USING btree (dashboard_id);


--
-- Name: IDX_dashboard_gnet_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_dashboard_gnet_id" ON public.dashboard USING btree (gnet_id);


--
-- Name: IDX_dashboard_org_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_dashboard_org_id" ON public.dashboard USING btree (org_id);


--
-- Name: IDX_dashboard_org_id_plugin_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_dashboard_org_id_plugin_id" ON public.dashboard USING btree (org_id, plugin_id);


--
-- Name: IDX_dashboard_provisioning_dashboard_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_dashboard_provisioning_dashboard_id" ON public.dashboard_provisioning USING btree (dashboard_id);


--
-- Name: IDX_dashboard_provisioning_dashboard_id_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_dashboard_provisioning_dashboard_id_name" ON public.dashboard_provisioning USING btree (dashboard_id, name);


--
-- Name: IDX_dashboard_snapshot_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_dashboard_snapshot_user_id" ON public.dashboard_snapshot USING btree (user_id);


--
-- Name: IDX_dashboard_tag_dashboard_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_dashboard_tag_dashboard_id" ON public.dashboard_tag USING btree (dashboard_id);


--
-- Name: IDX_dashboard_version_dashboard_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_dashboard_version_dashboard_id" ON public.dashboard_version USING btree (dashboard_id);


--
-- Name: IDX_data_source_org_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_data_source_org_id" ON public.data_source USING btree (org_id);


--
-- Name: IDX_login_attempt_username; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_login_attempt_username" ON public.login_attempt USING btree (username);


--
-- Name: IDX_org_user_org_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_org_user_org_id" ON public.org_user USING btree (org_id);


--
-- Name: IDX_team_member_org_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_team_member_org_id" ON public.team_member USING btree (org_id);


--
-- Name: IDX_team_org_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_team_org_id" ON public.team USING btree (org_id);


--
-- Name: IDX_temp_user_code; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_temp_user_code" ON public.temp_user USING btree (code);


--
-- Name: IDX_temp_user_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_temp_user_email" ON public.temp_user USING btree (email);


--
-- Name: IDX_temp_user_org_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_temp_user_org_id" ON public.temp_user USING btree (org_id);


--
-- Name: IDX_temp_user_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_temp_user_status" ON public.temp_user USING btree (status);


--
-- Name: IDX_user_auth_auth_module_auth_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_user_auth_auth_module_auth_id" ON public.user_auth USING btree (auth_module, auth_id);


--
-- Name: IDX_user_auth_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_user_auth_user_id" ON public.user_auth USING btree (user_id);


--
-- Name: UQE_alert_notification_org_id_uid; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_alert_notification_org_id_uid" ON public.alert_notification USING btree (org_id, uid);


--
-- Name: UQE_alert_notification_state_org_id_alert_id_notifier_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_alert_notification_state_org_id_alert_id_notifier_id" ON public.alert_notification_state USING btree (org_id, alert_id, notifier_id);


--
-- Name: UQE_alert_rule_tag_alert_id_tag_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_alert_rule_tag_alert_id_tag_id" ON public.alert_rule_tag USING btree (alert_id, tag_id);


--
-- Name: UQE_annotation_tag_annotation_id_tag_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_annotation_tag_annotation_id_tag_id" ON public.annotation_tag USING btree (annotation_id, tag_id);


--
-- Name: UQE_api_key_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_api_key_key" ON public.api_key USING btree (key);


--
-- Name: UQE_api_key_org_id_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_api_key_org_id_name" ON public.api_key USING btree (org_id, name);


--
-- Name: UQE_cache_data_cache_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_cache_data_cache_key" ON public.cache_data USING btree (cache_key);


--
-- Name: UQE_dashboard_acl_dashboard_id_team_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_dashboard_acl_dashboard_id_team_id" ON public.dashboard_acl USING btree (dashboard_id, team_id);


--
-- Name: UQE_dashboard_acl_dashboard_id_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_dashboard_acl_dashboard_id_user_id" ON public.dashboard_acl USING btree (dashboard_id, user_id);


--
-- Name: UQE_dashboard_org_id_folder_id_title; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_dashboard_org_id_folder_id_title" ON public.dashboard USING btree (org_id, folder_id, title);


--
-- Name: UQE_dashboard_org_id_uid; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_dashboard_org_id_uid" ON public.dashboard USING btree (org_id, uid);


--
-- Name: UQE_dashboard_snapshot_delete_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_dashboard_snapshot_delete_key" ON public.dashboard_snapshot USING btree (delete_key);


--
-- Name: UQE_dashboard_snapshot_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_dashboard_snapshot_key" ON public.dashboard_snapshot USING btree (key);


--
-- Name: UQE_dashboard_version_dashboard_id_version; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_dashboard_version_dashboard_id_version" ON public.dashboard_version USING btree (dashboard_id, version);


--
-- Name: UQE_data_source_org_id_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_data_source_org_id_name" ON public.data_source USING btree (org_id, name);


--
-- Name: UQE_org_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_org_name" ON public.org USING btree (name);


--
-- Name: UQE_org_user_org_id_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_org_user_org_id_user_id" ON public.org_user USING btree (org_id, user_id);


--
-- Name: UQE_plugin_setting_org_id_plugin_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_plugin_setting_org_id_plugin_id" ON public.plugin_setting USING btree (org_id, plugin_id);


--
-- Name: UQE_quota_org_id_user_id_target; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_quota_org_id_user_id_target" ON public.quota USING btree (org_id, user_id, target);


--
-- Name: UQE_server_lock_operation_uid; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_server_lock_operation_uid" ON public.server_lock USING btree (operation_uid);


--
-- Name: UQE_star_user_id_dashboard_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_star_user_id_dashboard_id" ON public.star USING btree (user_id, dashboard_id);


--
-- Name: UQE_tag_key_value; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_tag_key_value" ON public.tag USING btree (key, value);


--
-- Name: UQE_team_member_org_id_team_id_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_team_member_org_id_team_id_user_id" ON public.team_member USING btree (org_id, team_id, user_id);


--
-- Name: UQE_team_org_id_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_team_org_id_name" ON public.team USING btree (org_id, name);


--
-- Name: UQE_user_auth_token_auth_token; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_user_auth_token_auth_token" ON public.user_auth_token USING btree (auth_token);


--
-- Name: UQE_user_auth_token_prev_auth_token; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_user_auth_token_prev_auth_token" ON public.user_auth_token USING btree (prev_auth_token);


--
-- Name: UQE_user_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_user_email" ON public."user" USING btree (email);


--
-- Name: UQE_user_login; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "UQE_user_login" ON public."user" USING btree (login);


--
-- PostgreSQL database dump complete
--

