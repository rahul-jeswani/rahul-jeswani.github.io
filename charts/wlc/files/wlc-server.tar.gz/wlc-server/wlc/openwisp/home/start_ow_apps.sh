#!/bin/bash

cd /home/openwisp
set -a
. openwisp.int.env
. opennms.int.env
. reportdb.int.env
. topologydb.int.env
. grafana.int.env
. wlc.int.env

bash upd_local_settings.sh
bash ./create_dbs.sh
bash ./create_wlcdb.sh
#python3  /home/openwisp/manage.py makemigrations
python3  /home/openwisp/manage.py migrate
bash ./create_superuser.sh
bash ./addTables.sh
bash ./create_view.sh
bash ./create_org.sh
bash ./read_aps.sh &
bash ./start_node_exporter.sh &
python3  /home/openwisp/manage.py runserver --insecure --ipv6 [::]:8000
