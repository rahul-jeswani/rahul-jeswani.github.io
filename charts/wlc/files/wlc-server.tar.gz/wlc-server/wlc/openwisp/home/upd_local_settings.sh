#!/usr/bin/bash

cd /home/openwisp
sed \
	-e 's/OPENWISP_DBNAME/'$OPENWISP_DBNAME'/' \
	-e 's/OPENWISP_DBUSER/'$OPENWISP_DBUSER'/' \
	-e 's/OPENWISP_DBPASS/'$OPENWISP_DBPASS'/' \
	-e 's/OPENWISP_DBPORT/'$OPENWISP_DBPORT'/' \
	-e 's/OPENWISP_DBHOST/'$OPENWISP_DBHOST'/' \
    < local_settings.tmpl > local_settings.py
