#!/bin/bash
psql postgresql://$OPENWISP_DBUSER:$OPENWISP_DBPASS@$POSTGRES_HOST/$OPENWISP_DBNAME << EOF
drop view IF EXISTS config_analytics;

CREATE VIEW config_analytics as select cd.name as apname,cd.mac_address,cc.modified,cast(rv.serialized_data as json),rv.revision_id 
from config_device cd, config_config cc, config_config_templates cct, reversion_version rv 
where cd.id= cc.device_id and  cc.id=cct.config_id and rv.object_id = cast(cct.template_id as character) 
and rv.content_type_id=20 order by rv.revision_id DESC ;


ALTER VIEW config_analytics OWNER TO postgres;
EOF
