import os
import sys
import ldap
from django_auth_ldap.config import LDAPSearch, GroupOfNamesType
# Baseline configuration.
#AUTH_LDAP_SERVER_URI = 'ldap://ldap:389/'
#AUTH_LDAP_SERVER_URI = 'ldap://' + os.environ['LDAP_HOST'] + ':' + os.environ['LDAP_PORT'] + '/'
AUTH_LDAP_SERVER_URI = 'ldap://' + str(os.environ['LDAP_HOSTP1']) + ',' + 'ldap://' + str(os.environ['LDAP_HOSTP2'])

#AUTH_LDAP_BIND_DN = 'cn=admin,dc=rakuten,dc=com'
#AUTH_LDAP_BIND_PASSWORD = '1234567890'
AUTH_LDAP_BIND_DN = os.environ['LDAP_BIND_USER']
AUTH_LDAP_BIND_PASSWORD = str(os.environ['LDAP_BIND_PASS'])

#    'ou=users,dc=rakuten,dc=com',
AUTH_LDAP_USER_SEARCH = LDAPSearch(
    str(os.environ['LDAP_USER_SEARCH_DN']) + ',' + str(os.environ['LDAP_BASE_DN']),
    ldap.SCOPE_SUBTREE,
    '(' + str(os.environ['LDAP_USERID_ATTR']) + '=%(user)s)',
)
# Or:
# AUTH_LDAP_USER_DN_TEMPLATE = 'uid=%(user)s,ou=users,dc=rakuten,dc=com'

# Set up the basic group parameters.
#    'ou=groups,dc=rakuten,dc=com',
AUTH_LDAP_GROUP_SEARCH = LDAPSearch(
    str(os.environ['LDAP_GROUP_SEARCH_DN']) + ',' + str(os.environ['LDAP_BASE_DN']),
    ldap.SCOPE_SUBTREE,
    '(objectClass=groupOfNames)',
)
#AUTH_LDAP_GROUP_TYPE = GroupOfNamesType(name_attr='cn')
AUTH_LDAP_GROUP_TYPE = GroupOfNamesType(name_attr=str(os.environ['LDAP_GROUPTYPE_ATTR']))

# Simple group restrictions
#AUTH_LDAP_REQUIRE_GROUP = 'cn=is_superuser,ou=groups,dc=rakuten,dc=com'
#AUTH_LDAP_DENY_GROUP = 'cn=disabled,ou=groups,dc=rakuten,dc=com'

# Populate the Django user from the LDAP directory.
#AUTH_LDAP_USER_ATTR_MAP = {
#    'first_name': 'givenName',
#    'last_name': 'sn',
#    'email': 'mail',
#}
AUTH_LDAP_USER_ATTR_MAP = {
    'first_name': str(os.environ['LDAP_USER_FIRSTNAME_ATTR']),
    'last_name': str(os.environ['LDAP_USER_LASTNAME_ATTR']),
    'email': str(os.environ['LDAP_USER_EMAIL_ATTR']),
}

#AUTH_LDAP_USER_FLAGS_BY_GROUP = {
#    'is_active': 'cn=active,ou=groups,dc=rakuten,dc=com',
#    'is_staff': 'cn=staff,ou=groups,dc=rakuten,dc=com',
#    'is_superuser': 'cn=is_superuser,ou=groups,dc=rakuten,dc=com',
#}

su_dn = str(os.environ['LDAP_GROUPTYPE_ATTR']) + '=' + str(os.environ['LDAP_RMP_ADMIN_GROUP']) + ',' + str(os.environ['LDAP_GROUP_SEARCH_DN']) + ',' + str(os.environ['LDAP_BASE_DN'])

AUTH_LDAP_USER_FLAGS_BY_GROUP = {
    'is_active': su_dn,
    'is_staff': su_dn,
    'is_superuser': su_dn
}

# This is the default, but I like to be explicit.
AUTH_LDAP_ALWAYS_UPDATE_USER = True

# Use LDAP group membership to calculate group permissions.
AUTH_LDAP_FIND_GROUP_PERMS = True

# Cache distinguised names and group memberships for an hour to minimize
# LDAP traffic.
AUTH_LDAP_CACHE_TIMEOUT = 3600

# Keep ModelBackend around for per-user permissions and maybe a local
# superuser.
AUTHENTICATION_BACKENDS = (
    'django_auth_ldap.backend.LDAPBackend',
    'django.contrib.auth.backends.ModelBackend',
)

TESTING = sys.argv[1:2] == ['test']
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

DEBUG = False

#ALLOWED_HOSTS = ['*', 'wlc','opennms','localhost','openwisp']
ALLOWED_HOSTS = ['*']

#DATABASES = {
#    'default': {
#        'ENGINE': 'django.contrib.gis.db.backends.spatialite',
#        'NAME': 'openwisp-controller.db',
#    }
#}

SECRET_KEY = 'fn)t*+$)ugeyip6-#txyy$5wf2ervc0d2n#h)qb)y5@ly$t*@w'

INSTALLED_APPS = [
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'django.contrib.gis',
    # openwisp2 admin theme
    # (must be loaded here)
    'openwisp_utils.admin_theme',
    # all-auth
    'django.contrib.sites',
    'allauth',
    'allauth.account',
    'allauth.socialaccount',
    'django_extensions',
    # openwisp2 modules
    'openwisp_users',
    'openwisp_controller.pki',
    'openwisp_controller.config',
    'openwisp_controller.geo',
    # admin
    'django.contrib.admin',
    'django.forms',
    # other dependencies
    'sortedm2m',
    'reversion',
    'leaflet',
    # rest framework
    'rest_framework',
    'rest_framework_gis',
    # channels
    'channels',
    'rest_framework.authtoken',
    'rest_auth',
    'corsheaders'
]

EXTENDED_APPS = ('django_netjsonconfig', 'django_x509', 'django_loci',)

AUTH_USER_MODEL = 'openwisp_users.User'
SITE_ID = '1'

STATICFILES_FINDERS = [
    'django.contrib.staticfiles.finders.FileSystemFinder',
    'django.contrib.staticfiles.finders.AppDirectoriesFinder',
    'openwisp_utils.staticfiles.DependencyFinder',
]

MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'corsheaders.middleware.CorsMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'corsheaders.middleware.CorsPostCsrfMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

ROOT_URLCONF = 'urls'

CHANNEL_LAYERS = {
    'default': {
        'BACKEND': 'asgiref.inmemory.ChannelLayer',
        'ROUTING': 'openwisp_controller.geo.channels.routing.channel_routing',
    },
}

#TIME_ZONE = 'Asia/Tokyo'
TIME_ZONE = os.environ['TZ']
LANGUAGE_CODE = 'en-gb'
USE_TZ = False
USE_I18N = False
USE_L10N = False
STATIC_URL = '/static/'
MEDIA_URL = '/media/'
MEDIA_ROOT = '{0}/media/'.format(BASE_DIR)

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'OPTIONS': {
            'loaders': [
                'django.template.loaders.filesystem.Loader',
                'django.template.loaders.app_directories.Loader',
                'openwisp_utils.loaders.DependencyLoader',
            ],
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    }
]

FORM_RENDERER = 'django.forms.renderers.TemplatesSetting'

EMAIL_PORT = '1025'  # for testing purposes
LOGIN_REDIRECT_URL = 'admin:index'
ACCOUNT_LOGOUT_REDIRECT_URL = LOGIN_REDIRECT_URL

# during development only
EMAIL_BACKEND = 'django.core.mail.backends.console.EmailBackend'

REST_FRAMEWORK = {
    
    'DEFAULT_AUTHENTICATION_CLASSES': (
        'rest_framework.authentication.BasicAuthentication',
        'rest_framework.authentication.SessionAuthentication',
        'rest_framework.authentication.TokenAuthentication',
    )
}

CORS_ORIGIN_ALLOW_ALL = True
#X_FRAME_OPTIONS = 'ALLOW-FROM https://wlc:8990/'
#X_FRAME_OPTIONS = 'SAMEORIGIN'
X_FRAME_OPTIONS = 'ALLOWALL'

CORS_ORIGIN_WHITELIST = [
    "https://wlc:8990",
    "http://opennms:8980",
    "http://localhost:8000",
]

CSRF_TRUSTED_ORIGINS = [
	"wlc",
	"opennms",
	"wlcapp",
	".rakuten.co.jp"
]

CORS_URLS_REGEX = r'^/.*$'

CORS_ALLOW_METHODS = [
    'DELETE',
    'GET',
    'OPTIONS',
    'PATCH',
    'POST',
    'PUT',
]

# local settings must be imported before test runner otherwise they'll be ignored
try:
    from local_settings import *
except ImportError:
    pass
