from django.conf import settings
from django.conf.urls import include, url
from django.conf.urls.static import static
from django.contrib.staticfiles.urls import staticfiles_urlpatterns
from django.urls import reverse_lazy
from django.views.generic import RedirectView
from rest_framework import serializers, viewsets, routers
from openwisp_utils.admin_theme.admin import admin, openwisp_admin
from views import onmslogin
#from django.views.decorators.csrf import csrf_exempt
from openwisp_controller.config.models import Template, Config
from openwisp_controller.config.models import Device, Config
from openwisp_users.models import Organization
from openwisp_controller.config.models import TemplateTag
from openwisp_controller.config.models import TaggedTemplate
from views import tagtemplate
from views import speedtest
from django.views.decorators.csrf import csrf_exempt
#from django_netjsonconfig.base import cache
from django_netjsonconfig.base.base import BaseConfig
from django.db.models.signals import post_save
from django.dispatch import receiver
import psycopg2
import os



# Serializers define the Template API representation.
class TemplateSerializer(serializers.HyperlinkedModelSerializer):
    organization_id = serializers.CharField()
    class Meta:
        model = Template
        fields = ['name','backend', 'id', 'created', 'modified','config', 'vpn', 'type', 'default', 'auto_cert','organization_id']

# Serializers define the device API representation.
class DeviceSerializer(serializers.HyperlinkedModelSerializer):
    organization_id = serializers.CharField()
    class Meta:
        model = Device
        fields = ['id','name','mac_address', 'os','key','created', 'modified', 'model', 'notes','organization_id','system','last_ip','management_ip']

# Serializers define the Config API representation.
class ConfigSerializer(serializers.HyperlinkedModelSerializer):
    organization_id = serializers.CharField()
    device_id = serializers.CharField()
    class Meta:
        model = Config
        fields = ['id','backend', 'config','created','modified','status','organization_id','device_id']


# Serializers define the Organization API representation device.
class OrganizationSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = Organization
        fields = ['name','is_active', 'created','modified','slug','id']

# Serializers define the TemplateTag API representation device.
class TemplateTagSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = TemplateTag
        fields = ['name','slug','id']


# Serializers define the TaggedTemplate API representation device.
class TaggedTemplateSerializer(serializers.HyperlinkedModelSerializer):
    object_id = serializers.CharField()
    tag_id = serializers.CharField()
    content_type_id = serializers.CharField()
    class Meta:
        model = TaggedTemplate
        fields = ['object_id','tag_id','content_type_id']

# ViewSets define the TemplateView behavior.
class TemplateViewSet(viewsets.ModelViewSet):
    queryset = Template.objects.all()
    serializer_class = TemplateSerializer


# ViewSets define the DeviceView behavior device.
class DeviceViewSet(viewsets.ModelViewSet):
    queryset = Device.objects.all()
    serializer_class = DeviceSerializer

# ViewSets define the ConfigView behavior.
class ConfigViewSet(viewsets.ModelViewSet):
    queryset = Config.objects.all()
    serializer_class = ConfigSerializer    

# ViewSets define the OrganizationView behavior.
class OrganizationViewSet(viewsets.ModelViewSet):
    queryset = Organization.objects.all()
    serializer_class = OrganizationSerializer   

# ViewSets define the TemplateTagView behavior.
class TemplateTagViewSet(viewsets.ModelViewSet):
    queryset = TemplateTag.objects.all()
    serializer_class = TemplateTagSerializer   

# ViewSets define the TemplateTagView behavior.
class TaggedTemplateViewSet(viewsets.ModelViewSet):
    queryset = TaggedTemplate.objects.all()
    serializer_class = TaggedTemplateSerializer   


# Routers provide a way of automatically determining the URL conf.
router = routers.DefaultRouter()
router.register(r'Templates', TemplateViewSet)
router.register(r'Devices', DeviceViewSet)
router.register(r'Configs', ConfigViewSet)
router.register(r'Organizations', OrganizationViewSet)
router.register(r'TemplateTags', TemplateTagViewSet)
router.register(r'TaggedTemplates', TaggedTemplateViewSet)

openwisp_admin()

redirect_view = RedirectView.as_view(url=reverse_lazy('admin:index'))

urlpatterns = [
    url(r'^admin/', admin.site.urls),
    url(r'', include('openwisp_controller.urls')),
    url(r'^rest-auth/', include('rest_auth.urls')),
    url(r'^onmslogin/(?P<csrftoken>\w+)/(?P<sessionid>\w+)/(?P<expires>\w+)/(?P<max_age>\w+)/$', onmslogin),
    url(r'^tagtemplate/', tagtemplate),
    url(r'^speedtest/', speedtest),
    url(r'^$', redirect_view, name='index'),
    # Wire up our API using automatic URL routing.
    # Additionally, we include login URLs for the browsable API.    
    url(r'^', include(router.urls)),
#    url(r'^', csrf_exempt(include(router.urls))),
    url(r'^api-auth/', include('rest_framework.urls', namespace='rest_framework'))
]

urlpatterns += staticfiles_urlpatterns()
urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

if settings.DEBUG and 'debug_toolbar' in settings.INSTALLED_APPS:
    import debug_toolbar
    urlpatterns.append(url(r'^__debug__/', include(debug_toolbar.urls)))


# Track changes to Devices
@receiver(post_save)
def save_profile(sender, instance, **kwargs):
 """
 Invalidate the device checksum cache if the instance is a Device.
 If the instance is a template or a tagged template, then invalidate the checksum for all the Devices that have the template attached to them
 """
 try:
#   print("POSTSAVE Print instance.id = " + str(instance.id) + " type = " + str(type(instance)), flush=True)
   devices = [ ]
   if (isinstance(instance, Device)):
        devices.append(instance.id)
        check_remove_duplicate_ip(instance.id, instance.management_ip) 
   elif (isinstance(instance, Template)):
        devices = get_devices_bytemplate(instance.id)
   else:
        return
   for deviceid in devices: 
        BaseConfig.remove_checksum(str(deviceid))
 except Exception as e:
   print("post_save exception " + str(e) + " instance.id = " + str(instance.id) + " type = " + str(type(instance)) , flush=True)
   pass



def get_devices_bytemplate(template_id):
    deviceids = [ ]
    connection = None
    try:
        connection = psycopg2.connect(user=os.environ['OPENWISP_DBUSER'],
                              password=os.environ['OPENWISP_DBPASS'],
                              host=os.environ['OPENWISP_DBHOST'],
                              port=os.environ['OPENWISP_DBPORT'],
                              database=os.environ['OPENWISP_DBNAME'])
        cursor = connection.cursor()
        cursor.execute("SELECT device_id from config_config inner join config_config_templates on config_config.id = config_config_templates.config_id where config_config_templates.template_id='" + str(template_id) + "'")
        rows = cursor.fetchall()
        if rows:
            for row in rows:
                deviceids.append(row[0])
        return deviceids
    except Exception as error :
        print("get_devices_bytemplate failed with error " + str(error), flush=True)
        return deviceids

    finally:
        #closing database connection.
        if(connection):
            cursor.close()
            connection.close()

def check_remove_duplicate_ip(device_id, management_ip):
    connection = None
    try:
        connection = psycopg2.connect(user=os.environ['OPENWISP_DBUSER'],
                              password=os.environ['OPENWISP_DBPASS'],
                              host=os.environ['OPENWISP_DBHOST'],
                              port=os.environ['OPENWISP_DBPORT'],
                              database=os.environ['OPENWISP_DBNAME'])
        cursor = connection.cursor()
        update_mgmt_ip_query = "update config_device set management_ip='000.000.000.000' where management_ip=%s and id !=%s"
        cursor.execute(update_mgmt_ip_query, (management_ip, device_id))
        remove_ip_device_data = "delete from device_ip_data where device_ip = %s"
        cursor = connection.cursor()
        cursor.execute(remove_ip_device_data, (management_ip,)) 
        connection.commit()
    except Exception as error :
        print("check_remove_duplicate_ip failed with error " + str(error), flush=True)

    finally:
        #closing database connection.
        if(connection):
            cursor.close()
            connection.close()
