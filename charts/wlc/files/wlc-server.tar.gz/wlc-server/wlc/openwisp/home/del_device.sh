#!/bin/bash
psql postgresql://$OPENWISP_DBUSER:$OPENWISP_DBPASS@$POSTGRES_HOST/$OPENWISP_DBNAME << EOF
delete from config_device;
EOF
