#!/bin/bash

cp -r /home/openwisp.h/* /home/openwisp
chown -R openwisp:openwisp /home/openwisp/*
chmod -R go-w /home/openwisp/*
chmod -R -x /home/openwisp/*.*

[ -f /home/openwisp/branding/openwisp.css ] && cp /home/openwisp/branding/openwisp.css /usr/local/lib/python3.6/site-packages/openwisp_utils/admin_theme/static/admin/css/openwisp.css
[ -f /home/openwisp/branding/logo.svg ] && cp /home/openwisp/branding/logo.svg /usr/local/lib/python3.6/site-packages/openwisp_utils/admin_theme/static/ui/openwisp/images/logo.svg
[ -f /home/openwisp/branding/icon.png ] && cp /home/openwisp/branding/icon.png /usr/local/lib/python3.6/site-packages/openwisp_utils/admin_theme/static/ui/openwisp/images/favicon.png

[ -f /home/openwisp/openwisp_src_patch.tar ] && tar -xf /home/openwisp/openwisp_src_patch.tar -C /usr/local/lib/python3.6/

su openwisp -p /home/openwisp/start_ow_apps.sh

