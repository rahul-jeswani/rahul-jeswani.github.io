#!/bin/bash
export PGPASSWORD=$POSTGRES_PASSWORD
#on_logmsg="`date +'%Y-%m-%dT%H:%M:%SZ%z'`:Openwisp:`basename $0`"

function logmessage {
   echo "`date +'%Y-%m-%dT%H:%M:%S%Z%z'` $1 [OpenWISP: `basename $0`] $2"
}


count=$(psql -X -A -U ${OPENWISP_DBUSER} -d ${OPENWISP_DBNAME} -h ${POSTGRES_HOST} -t -c "select count(*) from openwisp_users_user where username='$OPENWISP_ADMIN_USER'")
if [ $count -eq 1 ]
then
    logmessage "info" "Admin user  ${OPENWISP_ADMIN_USER} is present."
#    logmessage "info" "Admin user  ${OPENWISP_ADMIN_USER} is present. Updating user"
#    echo "from openwisp_users.models import User; auser = User.objects.get(username='$OPENWISP_ADMIN_USER'); auser.set_password('$OPENWISP_ADMIN_PASS'); auser.is_superuser = True; auser.is_staff = True;" | python3 /home/openwisp/manage.py shell
else
    echo "from django.contrib.auth import get_user_model; User = get_user_model(); User.objects.create_superuser('$OPENWISP_ADMIN_USER', 'admin@test.com', '$OPENWISP_ADMIN_PASS')" | python3 /home/openwisp/manage.py shell
fi
