#!/bin/bash
. /home/openwisp/openwrt.env

(cat << EOF
from openwisp_controller.config.models import OrganizationConfigSettings as org_settings
from openwisp_users.models import Organization as org


org_defaults = {}

org_defaults.update({'is_active': True})
org_defaults.update({'name': "Rakuten"})
organization = org.objects.create(**org_defaults)

cfg_defaults = { }
cfg_defaults.update({'shared_secret': "$shared_secret"})
cfg_defaults.update({'registration_enabled': True})
cfg_defaults.update({'organization': organization})
cfg_settings = org_settings.objects.create(**cfg_defaults)
EOF
) | python3 /home/openwisp/manage.py shell
