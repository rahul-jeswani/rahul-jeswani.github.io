# RENAME THIS FILE TO local_settings.py IF YOU NEED TO CUSTOMIZE SOME SETTINGS
# BUT DO NOT COMMIT

DATABASES = {
    'default': {
         'ENGINE': 'django.contrib.gis.db.backends.postgis',
          'NAME': 'openwispdb',
          'USER': 'postgres',
         'PASSWORD': 'postgres',
         'HOST': 'database',
         'PORT': '5432'
 },
}
