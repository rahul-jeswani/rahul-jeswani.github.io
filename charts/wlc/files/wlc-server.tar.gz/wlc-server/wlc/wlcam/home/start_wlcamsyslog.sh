#!/bin/sh


function logmessage {
   echo "`date +'%Y-%m-%dT%H:%M:%S%Z%z'` $1 [WLC Alertmanager syslog App: `basename $0`] $2"
}


while [ true ]
do
        logmessage "info" "(re)Starting Alertmanager syslog"

	/bin/alertmanager-syslog -network=udp -syslog="${OPENNMS_IP}:10514"  -listen="127.0.0.1:10600" -host="localhost" -config=/home/wlcam/wlcamsyslog-config.yaml

        logmessage "error" "Alertmanager syslog exited"
    sleep 30
done
