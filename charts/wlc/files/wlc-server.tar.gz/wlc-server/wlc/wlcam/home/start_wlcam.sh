#!/bin/sh


/bin/alertmanager --config.file=/home/wlcam/wlcam.yml --storage.path=/prometheus/am
