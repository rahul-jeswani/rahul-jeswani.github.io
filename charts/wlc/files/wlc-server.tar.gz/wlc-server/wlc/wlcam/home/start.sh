#!/bin/sh

mkdir -p /home/wlcam
cp -r /home/wlcam.h/* /home/wlcam
chown -R nobody:nogroup /home/wlcam/*
chmod -R go-w /home/wlcam/*
chmod -R -x /home/wlcam/*.*

/bin/sh /home/wlcam/start_wlcamsyslog.sh &
/bin/sh /home/wlcam/start_wlcam.sh

